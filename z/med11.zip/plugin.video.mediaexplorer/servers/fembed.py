# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url, method="POST").data

    if "Video not found" in data:
        return ResolveError(0)

    data = jsontools.load_json(data)
    if data.get("success"):
        for video in data["data"]:
            url = video['file']

            itemlist.append(Video(url=url, res=video['label'], type=video['type']))
    else:
        # Falló por otro motivo
        return ResolveError(data["data"])

    return itemlist
