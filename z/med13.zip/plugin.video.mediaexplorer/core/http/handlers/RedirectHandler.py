# -*- coding: utf-8 -*-
from six.moves import urllib_request


class HTTPRedirectHandler(urllib_request.HTTPRedirectHandler):
    """
    Clase HTTPRedirechHandler modificada para no reenviar el header 'Authorization' cuando se redirecciona.
    """
    def __init__(self):
        pass

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if 'Authorization' in req.headers:
            req.headers.pop('Authorization')
        return urllib_request.HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)
