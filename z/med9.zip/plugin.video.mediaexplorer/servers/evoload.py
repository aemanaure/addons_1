# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    yield ResolveProgress(40, 0)
    data = httptools.downloadpage(item.url).data

    if "The video has been removed" in data:
        yield ResolveError(0)
        return

    ip = scrapertools.find_single_match(data, r"ip:'([^']+)'")
    csrf = scrapertools.find_single_match(data, r"_csrf:'([^']+)'")
    code = scrapertools.find_single_match(data, r"code:'([^']+)'")

    yield ResolveProgress(60, 4)
    post = {
        '_csrf': csrf,
        'ip': 'evo_' + ip,
        'code': code,
        'token': platformtools.show_recaptcha(item.url, '6Ldv2fYUAAAAALstHex35R1aDDYakYO85jt0ot-c', type='v3')
    }

    yield ResolveProgress(80, 1)
    response = jsontools.load_json(httptools.downloadpage(
        'https://evoload.io/EvoSecure',
        post=post
    ).data)

    itemlist.append(Video(url=response["src"]))

    yield itemlist
