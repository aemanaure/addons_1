﻿# -*- coding: utf-8 -*-

import re

from platformcode import config, logger
from core.item import Item
from core import httptools, scrapertools, servertools, jsontools, tmdb


host = 'https://zoowomaniacos.org/'

host_opts = host + 'alternativo3/server.php'


perpage = 22


def do_downloadpage(url, post=None, headers=None):
    data = httptools.downloadpage(url, post=post, headers=headers).data

    return data


def mainlist(item):
    return mainlist_pelis(item)

def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host_opts ))

    itemlist.append(item.clone( title = 'Las 1001 que hay que ver', action= 'list_all', url = host_opts,
                                post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': 'Las 1001', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''},
                                start = 0, search = '', pane = 'Las 1001', any = '', country = '',
                                ))

    itemlist.append(item.clone( title = 'Películas de culto', action= 'list_all', url = host_opts,
                                post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': 'Pel\xc3\xadcula de Culto', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''},
                                start = 0, search = '', pane = 'Pel\xc3\xadcula de Culto', any = '', country = '',
                                ))

    itemlist.append(item.clone( title = 'Versión original', action= 'list_all', url = host_opts,
                                post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': 'VO', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''},
                                start = 0, search = '', pane = 'VO', any = '', country = '',
                                ))

    itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por época', action = 'epocas', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por escritor', action = 'escritores' ))

    itemlist.append(item.clone( title = 'Por año', action = 'anios', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por país', action = 'paises', search_type = 'movie' ))

    # ~ itemlist.append(item.clone( title = 'Por dirección', action = 'directores' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    genres = [
       ('Abogados', 'Abogados'),
       ('Abusos sexuales', 'Abusos sexuales'),
       ('Acción', 'Acci\xc3\xb3n'),
       ('Adolescencia', 'Adolescencia'),
       ('Adopción', 'Adopci\xc3\xb3n'),
       ('Adulterio', 'Adulterio'),
       ('África', '\xc3\x81frica'),
       ('Ajedrez', 'Ajedrez'),
       ('Alcoholismo', 'Alcoholismo'),
       ('Alpinismo', 'Alpinismo'),
       ('Amistad', 'Amistad'),
       ('Amor', 'Amor'),
       ('Anarquismo', 'Anarquismo'),
       ('Animación', 'Animaci\xc3\xb3n'),
       ('Animación para Adultos', 'Animaci\xc3\xb3n para Adultos'),
       ('Animales', 'Animales'),
       ('Anime', 'Anime'),
       ('Antisemitismo - Pogromos', 'Antisemitismo - Pogromos'),
       ('Arañas', 'Ara\xc3\xb1as'),
       ('Arquitectura', 'Arquitectura'),
       ('Arte', 'Arte'),
       ('Artes Marciales', 'Artes marciales'),
       ('Artes Marciales (VosI)', 'Artes marciales VOSI'),
       ('Asesinos en Serie', 'Asesinos en serie'),
       ('Asia', 'Asia'),
       ('Atletismo', 'Atletismo'),
       ('Automovilismo', 'Automovilismo'),
       ('Aventura', 'Aventura'),
       ('Aventura Espacial', 'Aventura espacial'),
       ('Aventuras Marinas', 'Aventuras marinas'),
       ('Aves y Pájaros', 'Aves / P\xc3\xa1jaros'),
       ('Aviación', 'Aviaci\xc3\xb3n'),
       ('Aviones', 'Aviones'),
       ('Baile', 'Baile'),
       ('Ballet', 'Ballet'),
       ('Baloncesto', 'Baloncesto'),
       ('Bandas y Pandillas callejeras', 'Bandas/Pandillas callejeras'),
       ('Basada en Hechos Reales', 'Basada en hechos reales'),
       ('Basada en Obra Literaria', 'Basada en obra literaria'),
       ('Béisbol', 'B\xc3\xa9isbol'),
       ('Bélica', 'B\xc3\xa9lica'),
       ('Biblia', 'Biblia'),
       ('Bibliotecas', 'Bibliotecas'),
       ('Bicicletas', 'Bicicletas'),
       ('Biografía - Biopic', 'Biograf\xc3\xada - Biopic'),
       ('Blaxploitation', 'Blaxploitation'),
       ('Bodas', 'Bodas'),
       ('Bomberos', 'Bomberos'),
       ('Boxeo', 'Boxeo'),
       ('Brujería', 'Brujer\xc3\xada'),
       ('Buddy Film', 'Buddy Film'),
       ('Capa y Espada', 'Capa y espada'),
       ('Casas Encantadas', 'Casas encantadas'),
       ('Catástrofe Medioambiental', 'Cat\xc3\xa1strofe medioambiental'),
       ('Catástrofes', 'Cat\xc3\xa1strofes'),
       ('Categoría III', 'Categor\xc3\xada III'),
       ('Caza', 'Caza'),
       ('Celos', 'Celos'),
       ('Ciencia', 'Ciencia'),
       ('Ciencia Ficción', 'Ciencia ficci\xc3\xb3n'),
       ('Cine Dentro del Cine', 'Cine dentro del Cine'),
       ('Cine Épico', 'Cine \xc3\xa9pico'),
       ('Cine Experimental', 'Cine experimental'),
       ('Cine Familiar', 'Cine familiar'),
       ('Cine Independiente', 'Cine independiente'),
       ('Cine Independiente Usa', 'Cine independiente USA'),
       ('Cine Mondo', 'Cine Mondo'),
       ('Cine Mudo', 'Cine mudo'),
       ('Cine Negro', 'Cine negro'),
       ('Cine Político', 'Cine pol\xc3\xadtico'),
       ('Cine Quinqui', 'Cine Quinqui'),
       ('Cine Social', 'Cine social'),
       ('Cinema Novo Brasileño', 'Cinema novo brasile\xc3\xb1o'),
       ('Circo', 'Circo'),
       ('Cocaina', 'Cocaina'),
       ('Cocina', 'Cocina'),
       ('Colegio', 'Colegio'),
       ('Colonialismo', 'Colonialismo'),
       ('Comedia', 'Comedia'),
       ('Comedia Absurda', 'Comedia absurda'),
       ('Comedia de Terror', 'Comedia de terror'),
       ('Comedia Dramática', 'Comedia dram\xc3\xa1tica'),
       ('Comedia Juvenil', 'Comedia juvenil'),
       ('Comedia Negra', 'Comedia Negra'),
       ('Comedia Romántica', 'Comedia rom\xc3\xa1ntica'),
       ('Comedia Sofisticada', 'Comedia sofisticada'),
       ('Comic', 'Comic'),
       ('Comuna de París', 'Comuna de Par\xc3\xads'),
       ('Comunismo', 'Comunismo'),
       ('Condición de la Mujer', 'Condici\xc3\xb3n de la mujer'),
       ('Corrientes Cinematográficas', 'Corrientes Cinematogr\xc3\xa1ficas'),
       ('Corrupción', 'Corrupci\xc3\xb3n'),
       ('Cortometraje', 'Cortometraje'),
       ('Crimen', 'Crimen'),
       ('Cuentos', 'Cuentos'),
       ('Cyberpunk', 'Cyberpunk'),
       ('DC Comics', 'DC Comics'),
       ('Deportes', 'Deportes'),
       ('Desordenes Alimenticios', 'Desordenes alimenticios'),
       ('Destape', 'Destape'),
       ('Dinosaurios', 'Dinosaurios'),
       ('Discapacidad', 'Discapacidad'),
       ('Distopsias', 'Distop\xc3\xadas'),
       ('Documental', 'Documental'),
       ('Documental Científico', 'Documental cient\xc3\xadfico'),
       ('Documental de Cine', 'Documental de Cine'),
       ('Documental Deportivo', 'Documental deportivo'),
       ('Documental sobre Cine', 'Documental sobre cine'),
       ('Documental sobre Historia', 'Documental sobre Historia'),
       ('Documental sobre Música', 'Documental sobre m\xc3\xbasica'),
       ('Dogma', 'Dogma'),
       ('Drama', 'Drama'),
       ('Drama Carcelario', 'Drama carcelario'),
       ('Drama de Época', 'Drama de \xc3\xa9poca'),
       ('Drama Judicial', 'Drama Judicial'),
       ('Drama Psicológico', 'Drama psicol\xc3\xb3gico'),
       ('Drama Romántico', 'Drama rom\xc3\xa1ntico'),
       ('Drama Social', 'Drama social'),
       ('Drama Sureño', 'Drama sure\xc3\xb1o'),
       ('Drogas', 'Drogas'),
       ('Edad Media', 'Edad Media'),
       ('Educación', 'Educaci\xc3\xb3n'),
       ('Ejército', 'Ej\xc3\xa9rcito'),
       ('Enfermedad', 'Enfermedad'),
       ('Enfermedad Mental', 'Enfermedad mental'),
       ('Enseanza', 'Ense\xc3\xb1anza'),
       ('Epidemia', 'Epidemia'),
       ('Erótico', 'Er\xc3\xb3tico'),
       ('Esclavitud', 'Esclavitud'),
       ('Espada y Brujería', 'Espada y brujer\xc3\xada'),
       ('Espionaje', 'Espionaje'),
       ('Expresionismo Alemán', 'Expresionismo Alem\xc3\xa1n'),
       ('Extraterrestres', 'Extraterrestres'),
       ('Falso Documental', 'Falso documental'),
       ('Familia', 'Familia'),
       ('Fantasía', 'Fantas\xc3\xada'),
       ('Fantasmas', 'Fantasmas'),
       ('Fantástico', 'Fant\xc3\xa1stico'),
       ('Fascismo', 'Fascismo'),
       ('Feminismo', 'Feminismo'),
       ('Fin del Mundo', 'Fin del mundo'),
       ('Flamenco', 'Flamenco'),
       ('Foreign', 'Foreign'),
       ('Fotografía', 'Fotograf\xc3\xada'),
       ('Free Cinema', 'Free cinema'),
       ('Fútbol', 'F\xc3\xbatbol'),
       ('Fútbol Americano', 'F\xc3\xbatbol americano'),
       ('Futuro Postapocalíptico', 'Futuro postapocal\xc3\xadptico'),
       ('Gangsters', 'Gangsters'),
       ('Gatos', 'Gatos'),
       ('Giallo', 'Giallo'),
       ('Gore', 'Gore'),
       ('Gran Depresión', 'Gran Depresi\xc3\xb3n'),
       ('Guerra', 'Guerra'),
       ('Hackers', 'Hackers'),
       ('Heroína', 'Hero\xc3\xadna'),
       ('Hip Hop', 'Hip Hop'),
       ('Hipnosis', 'Hipnosis'),
       ('Historia', 'Historia'),
       ('Historias Cruzadas', 'Historias cruzadas'),
       ('Holocausto', 'Holocausto'),
       ('Holocausto Nuclear', 'Holocausto nuclear'),
       ('Hombres Lobo', 'Hombres lobo'),
       ('Homosexualidad', 'Homosexualidad'),
       ('India', 'India'),
       ('Infancia', 'Infancia'),
       ('Infantil', 'Infantil'),
       ('Informática y Ordenadores', 'Inform\xc3\xa1tica y ordenadores'),
       ('Inmigración', 'Inmigraci\xc3\xb3n'),
       ('Insectos', 'Insectos'),
       ('Internet', 'Internet'),
       ('Intriga', 'Intriga'),
       ('J-Horror', 'J-Horror'),
       ('Japón Feudal', 'Jap\xc3\xb3n feudal'),
       ('Jazz', 'Jazz'),
       ('Juego', 'Juego'),
       ('Juegos Olímpicos', 'Juegos ol\xc3\xadmpicos'),
       ('Juicios', 'Juicios'),
       ('Lgtb', 'LGTB'),
       ('Literatura', 'Literatura'),
       ('Lobos', 'Lobos'),
       ('Lucha Libre', 'Lucha libre'),
       ('Lucha Obrera', 'Lucha obrera'),
       ('Mafia', 'Mafia'),
       ('Magia', 'Magia'),
       ('Marginación Social', 'Marginaci\xc3\xb3n social'),
       ('Marionetas', 'Marionetas'),
       ('Marques de Sade', 'Marques de Sade'),
       ('Matemáticas', 'Matem\xc3\xa1ticas'),
       ('Matrimonio', 'Matrimonio'),
       ('Medicina', 'Medicina'),
       ('Medio Ambiente', 'Medio ambiente'),
       ('Mediometraje', 'Mediometraje'),
       ('Melodrama', 'Melodrama'),
       ('Memoria Histórica', 'Memoria Hist\xc3\xb3rica'),
       ('Misterio', 'Misterio'),
       ('Mitología', 'Mitolog\xc3\xada'),
       ('Mitos y Leyendas', 'Mitos y leyendas'),
       ('Mixtape', 'Mixtape'),
       ('Moda', 'Moda'),
       ('Monstruos', 'Monstruos'),
       ('Muerte', 'Muerte'),
       ('Mumblecore', 'Mumblecore'),
       ('Mumblegore', 'Mumblegore'),
       ('Música', 'M\xc3\xbasica'),
       ('Musical', 'Musical'),
       ('Naturaleza', 'Naturaleza'),
       ('Navidad', 'Navidad'),
       ('Nazismo', 'Nazismo'),
       ('Neo-Noir', 'Neo-noir'),
       ('Neorrealismo', 'Neorrealismo'),
       ('Ninjas', 'Ninjas'),
       ('Nouvelle Vague', 'Nouvelle Vague'),
       ('Nueva Ola Checa', 'Nueva Ola Checa'),
       ('Oceanía', 'Ocean\xc3\xada'),
       ('Ópera', '\xc3\x93pera'),
       ('Orígenes del Cine', 'Or\xc3\xadgenes del cine'),
       ('Ozploitation', 'Ozploitation'),
       ('Pandemias', 'Pandemias'),
       ('Parodia', 'Parodia'),
       ('Película de Episodios', 'Pel\xc3\xadcula de episodios'),
       ('Película de la Televisión', 'Pel\xc3\xadcula de la televisi\xc3\xb3n'),
       ('Película de Tv', 'Pel\xc3\xadcula de TV'),
       ('Pena de Muerte', 'Pena de muerte'),
       ('Peplum', 'Peplum'),
       ('Periodismo', 'Periodismo'),
       ('Perros', 'Perros'),
       ('Pesca', 'Pesca'),
       ('Pintura', 'Pintura'),
       ('Piratas', 'Piratas'),
       ('Pobreza', 'Pobreza'),
       ('Poesía', 'Poes\xc3\xada'),
       ('Policíaco', 'Polic\xc3\xadaco'),
       ('Política', 'Pol\xc3\xadtica'),
       ('Pornografía', 'Pornograf\xc3\xada'),
       ('Posesiones y Exorcismos', 'Posesiones/Exorcismos'),
       ('Posguerra Española', 'Posguerra espa\xc3\xb1ola'),
       ('Prehistoria', 'Prehistoria'),
       ('Propaganda', 'Propaganda'),
       ('Prostitución', 'Prostituci\xc3\xb3n'),
       ('Psique', 'Psique'),
       ('Racismo', 'Racismo'),
       ('Realismo Mágico', 'Realismo m\xc3\xa1gico'),
       ('Realismo Poético Francés', 'Realismo po\xc3\xa9tico franc\xc3\xa9s'),
       ('Religión', 'Religi\xc3\xb3n'),
       ('Remake', 'Remake'),
       ('Retrospecter', 'Retrospecter'),
       ('Revoluciones', 'Revoluciones'),
       ('Road movie', 'Road movie'),
       ('Robos y Atracos', 'Robos / Atracos'),
       ('Robots', 'Robots'),
       ('Roedores', 'Roedores'),
       ('Romance', 'Romance'),
       ('Rugby', 'Rugby'),
       ('Samuráis', 'Samur\xc3\xa1is'),
       ('Sátira', 'S\xc3\xa1tira'),
       ('Screwball', 'Screwball'),
       ('Sectas', 'Sectas'),
       ('Secuela', 'Secuela'),
       ('Secuestros y Desapariciones', 'Secuestros/Desapariciones'),
       ('Serie B', 'Serie B'),
       ('Serpientes', 'Serpientes'),
       ('Sexualidad', 'Sexualidad'),
       ('Sida', 'SIDA'),
       ('Simios', 'Simios'),
       ('Skateboarding', 'Skateboarding'),
       ('Slasher', 'Slasher'),
       ('Sobrenatural', 'Sobrenatural'),
       ('Spaghetti Western', 'Spaghetti Western'),
       ('Stop Motion', 'Stop motion'),
       ('Superhéroes', 'Superh\xc3\xa9roes'),
       ('Supervivencia', 'Supervivencia'),
       ('Surrealismo', 'Surrealismo'),
       ('Suspense', 'Suspense'),
       ('Teatro', 'Teatro'),
       ('Telefilm', 'Telefilm'),
       ('Televisión', 'Televisi\xc3\xb3n'),
       ('Tendencia Regional', 'Tendencia Regional'),
       ('Terror', 'Terror'),
       ('Terrorismo', 'Terrorismo'),
       ('Thriller', 'Thriller'),
       ('Thriller Futurista', 'Thriller futurista'),
       ('Thriller Psicológico', 'Thriller psicol\xc3\xb3gico'),
       ('Timos y Estafas', 'Timos y estafas'),
       ('Toros', 'Toros'),
       ('Trabajo y empleo', 'Trabajo/empleo'),
       ('Tráfico de Drogas', 'Tr\xc3\xa1fico de drogas'),
       ('Traición', 'Traici\xc3\xb3n'),
       ('Transexualidad y Transgénero', 'Transexualidad / Transg\xc3\xa9nero'),
       ('Trash', 'Trash'),
       ('Trenes y Metros', 'Trenes / Metros'),
       ('Troma', 'Troma'),
       ('Vampiros', 'Vampiros'),
       ('Vejez', 'Vejez'),
       ('Venganza', 'Venganza'),
       ('Veteranos de Guerra', 'Veteranos de guerra'),
       ('Viajes en el Tiempo', 'Viajes en el tiempo'),
       ('Vida Rural', 'Vida rural'),
       ('Vida Rural Norteamérica', 'Vida rural (Norteam\xc3\xa9rica)'),
       ('Videojuegos', 'Videojuegos'),
       ('Violación', 'Violaci\xc3\xb3n'),
       ('Western', 'Western'),
       ('Western Crepuscular', 'Western crepuscular'),
       ('Western Futurista', 'Western futurista'),
       ('Yakuza & Triada', 'Yakuza &amp; Triada'),
       ('Zombies', 'Zombies')
       ]

    descartar_xxx = config.get_setting('descartar_xxx', default=False)

    for genero in genres:
        title = genero[0]
        genre = genero[1]

        if descartar_xxx:
            if title == 'Animación para Adultos': continue
            elif title == 'Erótico': continue
            elif title == 'Pornografía': continue

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': str(genre), 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}

        itemlist.append(item.clone( title = title, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = genre, any = '', country = '' ))

    return itemlist


def epocas(item):
    logger.info()
    itemlist = []

    epochs = [
       ('Años 10', 'A\xc3\xb1os 10'),
       ('Años 1900', 'A\xc3\xb1os 1900'),
       ('Años 20', 'A\xc3\xb1os 20'),
       ('Años 30', 'A\xc3\xb1os 30'),
       ('Años 40', 'A\xc3\xb1os 40'),
       ('Años 50', 'A\xc3\xb1os 50'),
       ('Años 60', 'A\xc3\xb1os 60'),
       ('Años 70', 'A\xc3\xb1os 70'),
       ('Años 80', 'A\xc3\xb1os 80'),
       ('Años 90', 'A\xc3\xb1os 90'),
       ('Antigua Grecia', 'Antigua Grecia'),
       ('Antigua Roma', 'Antigua Roma'),
       ('Antiguo Egipto', 'Antiguo Egipto'),
       ('Crisis Económica 2008', 'Crisis econ\xc3\xb3mica 2008'),
       ('Guerra Chino Japonesa (II)', 'Guerra Chino-Japonesa (II)'),
       ('Guerra Civil Española', 'Guerra Civil Espa\xc3\xb1ola'),
       ('Guerra de Corea', 'Guerra de Corea'),
       ('Guerra de Independencia Americana', 'Guerra de independencia americana'),
       ('Guerra de Iraq', 'Guerra de Iraq'),
       ('Guerra de la Indepencia Española', 'Guerra de la Indepencia Espa\xc3\xb1ola'),
       ('Guerra de Secesión', 'Guerra de Secesi\xc3\xb3n'),
       ('Guerra de Vietnam', 'Guerra de Vietnam'),
       ('Guerra del Golfo', 'Guerra del Golfo'),
       ('Guerra Fría', 'Guerra Fr\xc3\xada'),
       ('Historia de España', 'Historia de Espa\xc3\xb1a'),
       ('I Guerra Mundial', 'I Guerra Mundial'),
       ('II Guerra Mundial', 'II Guerra Mundial'),
       ('Revolución Cubana', 'Revoluci\xc3\xb3n Cubana'),
       ('Revolución Cultural China', 'Revoluci\xc3\xb3n cultural china'),
       ('Revolución Francesa', 'Revoluci\xc3\xb3n Francesa'),
       ('Revolución Mexicana', 'Revoluci\xc3\xb3n Mexicana'),
       ('Revolución Rusa', 'Revoluci\xc3\xb3n Rusa'),
       ('Siglo XII', 'Siglo XII'),
       ('Siglo XIII', 'Siglo XIII'),
       ('Siglo XIV', 'Siglo XIV'),
       ('Siglo XV', 'Siglo XV'),
       ('Siglo XVI', 'Siglo XVI'),
       ('Siglo XVII', 'Siglo XVII'),
       ('Siglo XVIII', 'Siglo XVIII'),
       ('Siglo XIX', 'Siglo XIX')
       ]

    for epoch in epochs:
        title = epoch[0]
        epoca = epoch[1]

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': str(epoca), 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}

        itemlist.append(item.clone( title = title, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = epoca, any = '', country = '' ))

    return itemlist


def escritores(item):
    logger.info()
    itemlist = []

    writers = [
       ('Alberto Moravia', 'Alberto Moravia'),
       ('Alejandro Dumas', 'Alejandro Dumas'),
       ('Benito Pérez Galdós', 'Benito P\xc3\xa9rez Gald\xc3\xb3s'),
       ('Charles Dickens', 'Charles Dickens'),
       ('Clásicos Literarios', 'Cl\xc3\xa1sicos literarios'),
       ('David H. Lawrence', 'David H. Lawrence'),
       ('Dostoievski', 'Dostoievski'),
       ('Émile Zola', '\xc3\x89mile Zola'),
       ('George Orwell', 'George Orwell'),
       ('Graham Greene', 'Graham Greene'),
       ('Pio Baroja', 'Pio Baroja'),
       ('Ray Bradbury', 'Ray Bradbury'),
       ('Shakespeare', 'Shakespeare'),
       ('Tennessee Williams', 'Tennessee Williams'),
       ('Thomas Mann', 'Thomas Mann')
	   ]

    for x in writers:
        title = x[0]
        writer = x[1]

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': str(writer), 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}

        itemlist.append(item.clone( title = title, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = writer, any = '', country = '' ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []

    from datetime import datetime
    current_year = int(datetime.today().year)

    for x in range(current_year, 1902, -1):
        any = str(x)

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': '', 'search[value]': '', 'searchPanes[a4][0]': str(any), 'searchPanes[a6][0]': ''}

        itemlist.append(item.clone( title = any, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = '', any = any, country = '' ))

    return itemlist


def paises(item):
    logger.info()
    itemlist = []

    countries = [
       ('Afganistan', 'Afganistan'),
       ('Albania', 'Albania'),
       ('Alemania', 'Alemania'),
       ('Alemania (Alemania del Oeste RFA)', 'Alemania #Alemania_del_Oeste #RFA'),
       ('Alemania RFA', 'Alemania #RFA'),
       ('Alemania del Este (RDA)', 'Alemania del Este (RDA)'),
       ('Alemania del Oeste', 'Alemania del Oeste'),
       ('Alemania del Oeste (RFA)', 'Alemania del Oeste (RFA)'),
       ('Alemania del Oeste / RFA', 'Alemania del Oeste / RFA'),
       ('Alemania del Oeste / RFA /  Francia', 'Alemania del Oeste / RFA /  Francia'),
       ('Alemania del Oeste RFA', 'Alemania del Oeste #RFA'),
       ('Alemania del Oeste RFA Alemania', 'Alemania del Oeste #RFA #Alemania'),
       ('Alemania del Oeste RFA', 'Alemania del Oeste RFA'),
       ('Alemania Oriental', 'Alemania Oriental'),
       ('Alemania Oriental (RDA)', 'Alemania Oriental (RDA)'),
       ('Alemania Oriental (RFA)', 'Alemania Oriental (RFA)'),
       ('Alemania del Oeste (Alemania RDA)', 'Alemania_del_Oeste #Alemania #RDA'),
       ('Alemania, Austria', 'Alemania, Austria'),
       ('Angola', 'Angola'),
       ('AR / ES', 'AR. ES. '),
       ('Argelia', 'Argelia'),
       ('Argentina', 'Argentina'),
       ('Argentina, France', 'Argentina, France'),
       ('Argentina, France, Netherlands, Spain', 'Argentina, France, Netherlands, Spain'),
       ('Argentina, Spain, France', 'Argentina, Spain, France'),
       ('Australia', 'Australia'),
       ('Austri', 'Austri'),
       ('Austria', 'Austria'),
       ('Austria, France, Germany', 'Austria, France, Germany'),
       ('Austria, Germany', 'Austria, Germany'),
       ('Austria, Japan', 'Austria, Japan'),
       ('Austrtalia', 'Austrtalia'),
       ('Bangladesh', 'Bangladesh'),
       ('Bélgica', 'B\xc3\xa9lgica'),
       ('Belgium', 'Belgium'),
       ('Belgium, France, Italy', 'Belgium, France, Italy'),
       ('Belgium, France, Luxembourg', 'Belgium, France, Luxembourg'),
       ('Belgium, Luxembourg, France', 'Belgium, Luxembourg, France'),
       ('Benín', 'Ben\xc3\xadn'),
       ('Bolivia', 'Bolivia'),
       ('Bolivia, Japan, Usa', 'Bolivia, Japan, USA'),
       ('Bolivia, Spain', 'Bolivia, Spain'),
       ('Bosnia', 'Bosnia'),
       ('Bosnia and Herzegovina, France, Slovenia, Italy', 'Bosnia and Herzegovina, France, Slovenia, Italy'),
       ('Bosnia y Herzegovina', 'Bosnia y Herzegovina'),
       ('Brasil', 'Brasil'),
       ('Brazil', 'Brazil'),
       ('Brazil, Canada', 'Brazil, Canada'),
       ('Brazil, Cuba, Portugal', 'Brazil, Cuba, Portugal'),
       ('Brazil, Usa', 'Brazil, USA'),
       ('Bulgaria', 'Bulgaria'),
       ('Burkina Faso', 'Burkina Faso'),
       ('Burkina Faso, Switzerland, France', 'Burkina Faso, Switzerland, France'),
       ('Bután', 'But\xc3\xa1n'),
       ('Camboya', 'Camboya'),
       ('Canada', 'Canada'),
       ('Canada, Brazil, Japan', 'Canada, Brazil, Japan'),
       ('Canada, Croatia, Bosnia and Herzegovina, Slovenia, Serbia and Montenegro, Usa', 'Canada, Croatia, Bosnia and Herzegovina, Slovenia, Serbia and Montenegro, USA'),
       ('Canada, France', 'Canada, France'),
       ('Canada, India', 'Canada, India'),
       ('Canada, South Africa', 'Canada, South Africa'),
       ('Canada, UK', 'Canada, UK'),
       ('Canada, USA', 'Canada, USA'),
       ('Canada, USA, India, UK', 'Canada, USA, India, UK'),
       ('Catalunya', 'Catalunya'),
       ('Chad', 'Chad'),
       ('Checislovaquia', 'Checislovaquia'),
       ('Checoslovaqia', 'Checoslovaqia'),
       ('Checoslovaquia ', 'Checoslovaquia '),
       ('Chile', 'Chile'),
       ('China', 'China'),
       ('Colombia', 'Colombia'),
       ('Colombia, France', 'Colombia, France'),
       ('Corea (SK KS)', 'Corea #SK #KS'),
       ('Corea del Norte', 'Corea del Norte (si, del Norte)'),
       ('Corea del Sur', 'Corea del Sur'),
       ('Corea del Sur (SK CS KS)', 'Corea_del_Sur #SK #CS #KS'),
       ('Costa de Marfil', 'Costa de Marfil'),
       ('Costa Rica', 'Costa Rica'),
       ('Croacia', 'Croacia'),
       ('Cuba', 'Cuba'),
       ('Cuba, Mexico, Spain, Usa', 'Cuba, Mexico, Spain, USA'),
       ('Cuba, Spain', 'Cuba, Spain'),
       ('Cuba, Spain, West Germany', 'Cuba, Spain, West Germany'),
       ('Czech Republic', 'Czech Republic'),
       ('Czech Republic, France, UK', 'Czech Republic, France, UK'),
       ('Czech Republic, Germany', 'Czech Republic, Germany'),
       ('Czech Republic, Slovakia', 'Czech Republic, Slovakia'),
       ('Czechoslovakia', 'Czechoslovakia'),
       ('Czechoslovakia, Switzerland, UK, West Germany', 'Czechoslovakia, Switzerland, UK, West Germany'),
       ('Czechoslovakia, West Germany', 'Czechoslovakia, West Germany'),
       ('Denmark', 'Denmark'),
       ('Denmark, Germany', 'Denmark, Germany'),
       ('Denmark, Indonesia, Finland, Norway, UK, Israel, France, USA, Germany, Netherlands, Taiwan', 'Denmark, Indonesia, Finland, Norway, UK, Israel, France, USA, Germany, Netherlands, Taiwan'),
       ('Denmark, Italy, Sweden, Austria, France', 'Denmark, Italy, Sweden, Austria, France'),
       ('Denmark, Sweden, Netherlands, France, Germany, UK, Italy', 'Denmark, Sweden, Netherlands, France, Germany, UK, Italy'),
       ('Denmark, Sweden, Norway, UK', 'Denmark, Sweden, Norway, UK'),
       ('Denmark, UK', 'Denmark, UK'),
       ('Dinamarca', 'Dinamarca'),
       ('Ecuador', 'Ecuador'),
       ('Egipto', 'Egipto'),
       ('El Salvador', 'El Salvador'),
       ('Eslovaquia', 'Eslovaquia'),
       ('Eslovenia', 'Eslovenia'),
       ('Esp', 'ESP'),
       ('España', 'Espa\xc3\xb1a'),
       ('Estados Unidos', 'Estados Unidos'),
       ('Estonia', 'Estonia'),
       ('Estonia, Finland, Sweden, France', 'Estonia, Finland, Sweden, France'),
       ('Ethiopia, France, Germany, Norway, Qatar', 'Ethiopia, France, Germany, Norway, Qatar'),
       ('Etiopía', 'Etiop\xc3\xada'),
       ('Euskadi / País Vasco', 'Euskadi / Pa\xc3\xads Vasco'),
       ('Euskal Herria', 'Euskal Herria'),
       ('Fancia', 'Fancia'),
       ('Federal Republic of Yugoslavia, France, Germany, Austria, Greece', 'Federal Republic of Yugoslavia, France, Germany, Austria, Greece'),
       ('Filipinas', 'Filipinas'),
       ('Finland', 'Finland'),
       ('Finland, Norway, France, Sweden', 'Finland, Norway, France, Sweden'),
       ('Finland, Sweden', 'Finland, Sweden'),
       ('Finlandia', 'Finlandia'),
       ('FR. IT. ES.', 'FR. IT. ES. '),
       ('France', 'France'),
       ('France, Belgium', 'France, Belgium'),
       ('France, Belgium, Canada, UK, Latvia', 'France, Belgium, Canada, UK, Latvia'),
       ('France, Belgium, Ireland', 'France, Belgium, Ireland'),
       ('France, Belgium, Spain', 'France, Belgium, Spain'),
       ('France, Brazil, Italy', 'France, Brazil, Italy'),
       ('France, Canada', 'France, Canada'),
       ('France, Finland', 'France, Finland'),
       ('France, Germany, Belgium', 'France, Germany, Belgium'),
       ('France, Germany, Italy, Canada', 'France, Germany, Italy, Canada'),
       ('France, Italy', 'France, Italy'),
       ('France, Italy, Algeria', 'France, Italy, Algeria'),
       ('France, Italy, Spain', 'France, Italy, Spain'),
       ('France, Italy, UK', 'France, Italy, UK'),
       ('France, Italy, West Germany', 'France, Italy, West Germany'),
       ('France, Japan', 'France, Japan'),
       ('France, Lebanon', 'France, Lebanon'),
       ('France, Romania, Gabon', 'France, Romania, Gabon'),
       ('France, Spain', 'France, Spain'),
       ('France, Switzerland, West Germany, UK, Hungary', 'France, Switzerland, West Germany, UK, Hungary'),
       ('France, Usa', 'France, USA'),
       ('France, West Germany', 'France, West Germany'),
       ('Francés', 'Franc\xc3\xa9s'),
       ('Francia', 'Francia'),
       ('Francia, Alemania', 'Francia, Alemania'),
       ('Francia, Bélgica, Republica del Congo', 'Francia, B\xc3\xa9lgica, Republica del Congo'),
       ('Francia, Italia', 'Francia, Italia'),
       ('Francia, Italia, Turquía', 'Francia, Italia, Turqu\xc3\xada'),
       ('Francia, Mexico', 'Francia, Mexico'),
       ('Francia, Suecia', 'Francia, Suecia'),
       ('Galicia', 'Galicia'),
       ('Gamonal', 'Gamonal'),
       ('Georgia', 'Georgia'),
       ('Germany', 'Germany'),
       ('Germany, Austria', 'Germany, Austria'),
       ('Germany, Denmark, Taiwan', 'Germany, Denmark, Taiwan'),
       ('Germany, France, Austria, UK', 'Germany, France, Austria, UK'),
       ('Germany, Turkey', 'Germany, Turkey'),
       ('Gibraltar', 'Gibraltar'),
       ('Grecia', 'Grecia'),
       ('Greece', 'Greece'),
       ('Greece, France, Canada, Usa', 'Greece, France, Canada, USA'),
       ('Greece, France, Italy', 'Greece, France, Italy'),
       ('Greece, France, Italy, Germany, UK, Federal Republic of Yugoslavia, Bosnia and Herzegovina, Albania, Romania', 'Greece, France, Italy, Germany, UK, Federal Republic of Yugoslavia, Bosnia and Herzegovina, Albania, Romania'),
       ('Greece, Germany, Cyprus', 'Greece, Germany, Cyprus'),
       ('Greece, Ireland, Netherlands, UK, France', 'Greece, Ireland, Netherlands, UK, France'),
       ('Guatemala', 'Guatemala'),
       ('Guatemala, France', 'Guatemala, France'),
       ('HK (Hong Kong)', 'HK #Hong_Kong'),
       ('Holanda', 'Holanda'),
       ('Holanda #Paises_Bajos', 'Holanda #Paises_Bajos'),
       ('Holanda Paises Bajos', 'Holanda Paises Bajos'),
       ('Hong Kong', 'Hong Kong'),
       ('Hong Kong (HK)', 'Hong Kong #HK'),
       ('Hong Kong, China', 'Hong Kong, China'),
       ('Hong Kong, Japan, South Korea', 'Hong Kong, Japan, South Korea'),
       ('Hong Kong', 'Hong Kong)'),
       ('Hong Kong #HK', 'Hong_Kong #HK'),
       ('Hong-Kong', 'Hong-Kong'),
       ('Hong-Kong / HK', 'Hong-Kong / HK'),
       ('Honk_Kong', 'Honk_Kong'),
       ('Hungary', 'Hungary'),
       ('Hungary, France, Germany, Switzerland, Usa', 'Hungary, France, Germany, Switzerland, USA'),
       ('Hungary, Germany, Switzerland', 'Hungary, Germany, Switzerland'),
       ('Hungary, Italy, Germany, France', 'Hungary, Italy, Germany, France'),
       ('Hungary, Soviet Union', 'Hungary, Soviet Union'),
       ('Hungria', 'Hungria'),
       ('India', 'India'),
       ('India, Canada', 'India, Canada'),
       ('Indonesia', 'Indonesia'),
       ('Irak', 'Irak'),
       ('Iran', 'Iran'),
       ('Iran, France', 'Iran, France'),
       ('Iran, Italy, Japan', 'Iran, Italy, Japan'),
       ('Iraq', 'Iraq'),
       ('Ireland, Denmark, Belgium, Luxembourg, France', 'Ireland, Denmark, Belgium, Luxembourg, France'),
       ('Ireland, USA', 'Ireland, USA'),
       ('Irlanda', 'Irlanda'),
       ('Islandia', 'Islandia'),
       ('Israel', 'Israel'),
       ('Israel, Australia', 'Israel, Australia'),
       ('ITA', 'ITA'),
       ('Itaila', 'Itaila'),
       ('Italia', 'Italia'),
       ('Italia / España / Alemania', 'Italia / Espa\xc3\xb1a / Alemania'),
       ('Italia / España / Alemania del Oeste', 'Italia / Espa\xc3\xb1a / Alemania del Oeste'),
       ('Italia, Francia', 'Italia, Francia'),
       ('Italy', 'Italy'),
       ('Italy, Canada', 'Italy, Canada'),
       ('Italy, France', 'Italy, France'),
       ('Italy, France, Spain', 'Italy, France, Spain'),
       ('Italy, France, UK, Switzerland', 'Italy, France, UK, Switzerland'),
       ('Italy, Germany, Switzerland', 'Italy, Germany, Switzerland'),
       ('Italy, Russia, France, Portugal', 'Italy, Russia, France, Portugal'),
       ('Italy, Spain', 'Italy, Spain'),
       ('Italy, Usa', 'Italy, USA'),
       ('Italy, West Germany', 'Italy, West Germany'),
       ('Jamaica', 'Jamaica'),
       ('Japan', 'Japan'),
       ('Japan, UK', 'Japan, UK'),
       ('Japón', 'Jap\xc3\xb3n'),
       ('Japóo', 'Jap\xc3\xb3o'),
       ('Jordania', 'Jordania'),
       ('K', 'K'),
       ('Kazajstán', 'Kazajst\xc3\xa1n'),
       ('Kenia', 'Kenia'),
       ('Kirguistán', 'Kirguist\xc3\xa1n'),
       ('Korea', 'Korea'),
       ('Korea del Sur', 'Korea del Sur'),
       ('Korea del Sur (SK KS)', 'Korea del Sur #SK #KS'),
       ('KR.', 'KR. '),
       ('KS, Corea del Sur', 'KS, Corea del Sur'),
       ('Letonia', 'Letonia'),
       ('Líbano', 'L\xc3\xadbano'),
       ('Liberia', 'Liberia'),
       ('Libia', 'Libia'),
       ('Liechtenstein', 'Liechtenstein'),
       ('Lituania', 'Lituania'),
       ('Macedonia', 'Macedonia'),
       ('Malasia', 'Malasia'),
       ('Mali', 'Mali'),
       ('Mali, Usa, France', 'Mali, USA, France'),
       ('Marruecos', 'Marruecos'),
       ('Mauritania', 'Mauritania'),
       ('México', 'M\xc3\xa9xico'),
       ('Mexico, Canada', 'Mexico, Canada'),
       ('Mexico, Cuba, Spain', 'Mexico, Cuba, Spain'),
       ('Mexico, France, Netherlands, Germany', 'Mexico, France, Netherlands, Germany'),
       ('Mexico, Germany', 'Mexico, Germany'),
       ('Mexico, Spain', 'Mexico, Spain'),
       ('Mexico, Spain, USA, UK', 'Mexico, Spain, USA, UK'),
       ('Mexico, Usa', 'Mexico, USA'),
       ('Mongolia', 'Mongolia'),
       ('Nepal', 'Nepal'),
       ('Netherlands', 'Netherlands'),
       ('Netherlands, France, Finland, Sweden', 'Netherlands, France, Finland, Sweden'),
       ('New Zealand', 'New Zealand'),
       ('Nicaragua', 'Nicaragua'),
       ('Nigeria', 'Nigeria'),
       ('Noruega', 'Noruega'),
       ('Norway', 'Norway'),
       ('Norway, Iceland', 'Norway, Iceland'),
       ('Nuena Zelanda (NZ)', 'Nuena Zelanda #NZ'),
       ('Nueva Zelanda', 'Nueva Zelanda'),
       ('Nueva Zelanda / Corea del Norte', 'Nueva Zelanda / Corea del Norte'),
       ('Países Bajos', 'Pa\xc3\xadses Bajos'),
       ('Países Bajos (Holanda)', 'Pa\xc3\xadses Bajos (Holanda)'),
       ('Países Bajos, Holanda, Netherlands', 'Pa\xc3\xadses Bajos, Holanda, Netherlands'),
       ('Palestina', 'Palestina'),
       ('Palestine, Israel, France, Netherlands', 'Palestine, Israel, France, Netherlands'),
       ('Panamá', 'Panam\xc3\xa1'),
       ('Paquistan', 'Paquistan'),
       ('Paraguay', 'Paraguay'),
       ('Peru', 'Peru'),
       ('Poland', 'Poland'),
       ('Poland, France', 'Poland, France'),
       ('Poland, Portugal, France, UK', 'Poland, Portugal, France, UK'),
       ('Polonia', 'Polonia'),
       ('Polonia / Francia', 'Polonia / Francia'),
       ('Portugal', 'Portugal'),
       ('Portugal, France', 'Portugal, France'),
       ('Puerto Rico', 'Puerto Rico'),
       ('RDA', 'RDA'),
       ('RDA / Alemania', 'RDA / Alemania'),
       ('RDA (Alemania del Este)', 'RDA #Alemania del Este'),
       ('Reino Unido', 'Reino Unido'),
       ('Reino Unido (UK)', 'Reino Unido ; UK'),
       ('Reino Unido / UK', 'Reino Unido / UK'),
       ('Reino Unido / UK - Francia', 'Reino Unido / UK - Francia'),
       ('Reino Unido, UK', 'Reino Unido, UK'),
       ('Reino Unido; UK', 'Reino Unido; UK'),
       ('Rep. Dominicana', 'Rep. Dominicana'),
       ('República Checa', 'Rep\xc3\xbablica Checa'),
       ('República del Congo', 'Rep\xc3\xbablica del Congo'),
       ('República Dominicana', 'Rep\xc3\xbablica Dominicana'),
       ('República Checa (Checoslovaquia)', 'Rep\xc3\xbablica_Checa #Checoslovaquia'),
       ('RFA', 'RFA'),
       ('RFA / Alemania', 'RFA / Alemania'),
       ('Romania', 'Romania'),
       ('Romania, France', 'Romania, France'),
       ('Romania, France, Belgium', 'Romania, France, Belgium'),
       ('Romania, Poland', 'Romania, Poland'),
       ('Romania, Usa, Italy, Poland, France', 'Romania, USA, Italy, Poland, France'),
       ('Ruanda', 'Ruanda'),
       ('Rumanía', 'Ruman\xc3\xada'),
       ('Rusia', 'Rusia'),
       ('Rusia Japón', 'Rusia #Jap\xc3\xb3n'),
       ('Russia', 'Russia'),
       ('Saudi Arabia, Netherlands, Germany, Jordan, United Arab Emirates, USA', 'Saudi Arabia, Netherlands, Germany, Jordan, United Arab Emirates, USA'),
       ('Senegal', 'Senegal'),
       ('Serbia', 'Serbia'),
       ('Serbia y Montenegro', 'Serbia y Montenegro'),
       ('Serbia, France', 'Serbia, France'),
       ('Singapur', 'Singapur'),
       ('Siria', 'Siria'),
       ('SK (Corea del Sur)', 'SK, Corea del Sur'),
       ('South Korea', 'South Korea'),
       ('South Korea, Germany', 'South Korea, Germany'),
       ('South Korea, Japan', 'South Korea, Japan'),
       ('Soviet Union', 'Soviet Union'),
       ('Spain', 'Spain'),
       ('Spain, Argentina', 'Spain, Argentina'),
       ('Spain, Denmark, Sweden, France, Germany, Switzerland', 'Spain, Denmark, Sweden, France, Germany, Switzerland'), ('Spain, France', 'Spain, France'),
       ('Spain, France, Bolivia, UK', 'Spain, France, Bolivia, UK'),
       ('Spain, Italy', 'Spain, Italy'),
       ('Spain, Mexico', 'Spain, Mexico'),
       ('Sri Lanka', 'Sri Lanka'),
       ('Sudáfrica', 'Sud\xc3\xa1frica'),
       ('Sudáfrica, Marruecos, Guinea, Senegal', 'Sud\xc3\xa1frica, Marruecos, Guinea, Senegal'),
       ('Sudán', 'Sud\xc3\xa1n'),
       ('Suecia', 'Suecia'),
       ('Suecia, Polonia, Francia', 'Suecia / Polonia / Francia'),
       ('Suiza', 'Suiza'),
       ('Sweden', 'Sweden'),
       ('Sweden, Denmark', 'Sweden, Denmark'),
       ('Sweden, Denmark, Italy', 'Sweden, Denmark, Italy'),
       ('Sweden, Denmark, Norway', 'Sweden, Denmark, Norway'),
       ('Sweden, France', 'Sweden, France'),
       ('Sweden, Norway', 'Sweden, Norway'),
       ('Sweden, UK, Finland', 'Sweden, UK, Finland'),
       ('Switzerland, France', 'Switzerland, France'),
       ('Switzerland, France, Poland', 'Switzerland, France, Poland'),
       ('Switzerland, Hungary, France, Germany, Iran, Tunisia, UK', 'Switzerland, Hungary, France, Germany, Iran, Tunisia, UK'),
       ('Tailandia', 'Tailandia'),
       ('Taiwan', 'Taiwan'),
       ('Taiwan, China, Hong Kong, France', 'Taiwan, China, Hong Kong, France'),
       ('Taiwan, Hong Kong', 'Taiwan, Hong Kong'),
       ('Taiwan, Japan', 'Taiwan, Japan'),
       ('Tajikistan', 'Tajikistan'),
       ('Túnez', 'T\xc3\xbanez'),
       ('Turquía', 'Turqu\xc3\xada'),
       ('Ucrania', 'Ucrania'),
       ('Uganda', 'Uganda'),
       ('UK', 'UK'),
       ('UK, Denmark, Norway', 'UK, Denmark, Norway'),
       ('UK, France, Ireland, Usa', 'UK, FRANCE, IRELAND, USA'),
       ('UK, France, West Germany', 'UK, France, West Germany'),
       ('UK, Hungary', 'UK, Hungary'),
       ('UK, Ireland', 'UK, Ireland'),
       ('UK, Netherlands', 'UK, Netherlands'),
       ('UK, Reino Unido', 'UK, Reino Unido'),
       ('UK, Reino Unido, United Kingdom', 'UK, Reino Unido, United Kingdom'),
       ('UK, Romania, Germany', 'UK, Romania, Germany'),
       ('UK, South Korea, Usa', 'UK, South Korea, USA'),
       ('UK, USA', 'UK, USA'),
       ('UK, USA, Australia, Japan', 'UK, USA, Australia, Japan'),
       ('UK, USA, Japan', 'UK, USA, Japan'),
       ('Unión  Soviética', 'Uni\xc3\xb3n  Sovi\xc3\xa9tica'),
       ('Unión Soviética', 'Uni\xc3\xb3n Sovi\xc3\xa9tica'),
       ('Unión Soviética (URSS)', 'Uni\xc3\xb3n Sovi\xc3\xa9tica (URSS)'),
       ('Unión Soviética URSS', 'Union Sovietica URSS'),
       ('Unión Soviética, URSS', 'Uni\xc3\xb3n Sovi\xc3\xa9tica, URSS'),
       ('Unión Soviética (URSS Rusia)', 'Uni\xc3\xb3n_Sovi\xc3\xa9tica #URSS #Rusia'),
       ('URSS', 'URSS'),
       ('URSS, Itlaia', 'URSS / Itlaia'),
       ('URSS, Rusia', 'URSS / Rusia'),
       ('URSS (Rusia)', 'URSS #Rusia'),
       ('Uruguay', 'Uruguay'),
       ('US', 'US'),
       ('US.', 'US. '),
       ('USA', 'USA'),
       ('USA, India, / Sudáfrica', 'USA / India / Sud\xc3\xa1frica'),
       ('USA, Argentina', 'USA, Argentina'),
       ('USA, Canada', 'USA, Canada'),
       ('USA, France', 'USA, France'),
       ('USA, France, Germany', 'USA, France, Germany'),
       ('USA, Italy', 'USA, Italy'),
       ('USA, Mexico', 'USA, Mexico'),
       ('USA, Netherlands', 'USA, Netherlands'),
       ('USA, Switzerland, UK', 'USA, Switzerland, UK'),
       ('USA, UK', 'USA, UK'),
       ('USA, West Germany', 'USA, West Germany'),
       ('Venezuela', 'Venezuela'),
       ('Vietnam', 'Vietnam'),
       ('West Germany', 'West Germany'),
       ('West Germany, France', 'West Germany, France'),
       ('West Germany, France, Soviet Union, Switzerland', 'West Germany, France, Soviet Union, Switzerland'),
       ('West Germany, Hungary, Austria', 'West Germany, Hungary, Austria'),
       ('Yugoslavia', 'Yugoslavia'),
       ('Zimbabwe', 'Zimbabwe')
	   ]

    for x in countries:
        title = x[0]
        country = x[1]

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': '', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': str(country)}

        itemlist.append(item.clone( title = title, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = '', any = '', country = country ))

    return itemlist


def directores(item):
    logger.info()
    itemlist = []

    directors = [
       ('A. Edward Sutherland', ''),
       ('A.F. Erickson', ''),
       ('Aaron Aites', ''),
       ('Aaron Burns', ''),
       ('Aaron Dormer', ''),
       ('Aaron Hann', ''),
       ('Aaron Katz', ''),
       ('Aaron Lipstadt', ''),
       ('Aaron Moorhead', ''),
       ('Aaron Norris', ''),
       ('Aaron Springer', ''),
       ('Aarón Fernández Lesur', ''),
       ('Aarón Soto', ''),
       ('Abbas Fahdel', ''),
       ('Abbas Kiarostami', ''),
       ('Abby Berlin', ''),
       ('Abd Al Malik', ''),
       ('Abdellatif Kechiche', ''),
       ('Abderrahmane Sissako', ''),
       ('Abe Levitow', ''),
       ('Abel Amador', ''),
       ('Abel Ferrara', ''),
       ('Abel Gance', ''),
       ('Abner Benaim', ''),
       ('Abraham Polonsky', ''),
       ('Abram Room', ''),
       ('Achero Mañas', ''),
       ('Achim von Borries', ''),
       ('Ad Schaumer', ''),
       ('Adam B. Stein', ''),
       ('Adam Brooks', ''),
       ('Adam Davidson', ''),
       ('Adam Elliot', ''),
       ('Adam Mason', ''),
       ('Adam Nimoy', ''),
       ('Adam Rehmeier', ''),
       ('Adam Rifkin', ''),
       ('Adam Snyder', ''),
       ('Adam Somner', ''),
       ('Adam Wingard', ''),
       ('Adele Cannon', ''),
       ('Adil El Arbi', ''),
       ('Aditya Assarat', ''),
       ('Aditya Chopra', ''),
       ('Adolf Zika', ''),
       ('Adolfo Aristarain', ''),
       ('Adolfo Arrieta', ''),
       ('Adolfo Padovan', ''),
       ('Adoor Gopalakrishnan', ''),
       ('Adrian Grunberg', ''),
       ('Adrian Hoven', ''),
       ('Adrian Lyne', ''),
       ('Adrian Maben', ''),
       ('Adrian Pryce-Jones', ''),
       ('Adrian Shergold', ''),
       ('Adrian Wood', ''),
       ('Adriana Bravo', ''),
       ('Adriana Casasola', ''),
       ('Adriana Vior', ''),
       ('Adrienne Hamalian-Mangine', ''),
       ('Adrià García', ''),
       ('Adrián Biniez', ''),
       ('...', '')
       ]

    for x in directors:
        title = x[0]
        director = x[1]

        post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': str(director), 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}

        itemlist.append(item.clone( title = title, action = 'list_all', url = host_opts,
                                    post = post, start = 0, search = '', pane = director, any = '', country = '' ))

    return itemlist


def list_all(item): 
    logger.info()
    itemlist = []

    if not item.start: item.start = 0
    if not item.tex_search: item.tex_search = ''
    if not item.pane: item.pane = ''
    if not item.any: item.any = ''
    if not item.country: item.country = ''

    start = str(item.start)
    pane = str(item.pane)
    search = str(item.tex_search)
    any = str(item.any)
    country = str(item.country)

    if not item.post:
       post = {'start': start, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': pane, 'search[value]': search, 'searchPanes[a4][0]': any, 'searchPanes[a6][0]': country}
    else:
       post = item.post

    data = do_downloadpage(item.url, post = post)

    jdata = jsontools.load(data)

    for elem in jdata['data']:
        title_alt = elem.get('a2', '')

        try:
            title = title_alt.split('-')[0].strip()
            title_alt = title_alt.split('-')[1].strip()
        except:
            title = title_alt

        direccion = elem.get('a3', '0')

        titulo = title + ' - ' + direccion

        _id = elem.get('a1', '0')

        year = elem.get('a4', '0')
        if not year: year = '-'

        thumb = '%swp/wp-content/uploads/%s' % (host[:-1], elem.get('a8', ''))

        plot = elem.get('a100', '')

        itemlist.append(item.clone( action='findvideos', _id=_id, title=titulo, thumbnail=thumb,
                                    contentType='movie', contentTitle=title, contentTitleAlt = title_alt, infoLabels={'year': year, 'plot': plot} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
       if len(itemlist) == perpage:
           start = int(start) + perpage

           post = {'start': start, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': pane, 'search[value]': search, 'searchPanes[a4][0]': any, 'searchPanes[a6][0]': country}

           itemlist.append(item.clone (url = item.url, post = post, start = start, pane = pane, search = search, any = any, country = country,
                                       title = 'Siguientes ...', action = 'list_all', text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    IDIOMAS = {
            'es': 'Esp',
            'ar': 'Lat',
            'co': 'Lat',
            'cl': 'Lat',
            'pe': 'Lat',
            'mx': 'Lat',
            'en': 'Ing',
            'gb': 'Ing',
            'vose': 'Vose',
            'vo': 'VO',
            'it': 'IT',
            'de': 'DE',
            'fr': 'FR',
            'jp': 'JP',
            'td': 'RO',
            'se': 'SE',
            'br': 'BR',
            'ru': 'RU',
            'kr': 'KR',
            'pt': 'PT',
            'cn': 'HK',
            'pl': 'PL',
            'in': 'IN',
            'tr': 'TR',
            'nl': 'NL'
            }

    det_url = 'https://proyectox.yoyatengoabuela.com/testplayer.php?id=' + item._id

    data = do_downloadpage(det_url)

    matches = scrapertools.find_multiple_matches(data, '<div id="option-(.*?)".*?src="(.*?)"')

    i = 0

    for opt, lnk in matches:
        if i > 0:
             if not item._id == '19997': # the_puppet_masters
                 if lnk == 'https://ok.ru/videoembed/1683045747235':
                    i += 1
                    continue
                 elif lnk == 'https://ok.ru/videoembed/332656282246':
                    i += 1
                    continue

        servidor = servertools.get_server_from_url(lnk)
        servidor = servertools.corregir_servidor(servidor)

        lnk = servertools.normalize_url(servidor, lnk)

        patron = '<a class="options" href="#option-' + str(opt) + '">.*?/flags/(.*?).png'
 
        lngs = scrapertools.find_multiple_matches(data, patron)

        other = ''

        try:
            if len(lngs) > 1:
                other = str(lngs[i])
                other = IDIOMAS.get(other, other)
        except:
            pass

        lang = scrapertools.find_single_match(data, patron)

        lang = IDIOMAS.get(lang, lang)

        if lang == other: other = ''
        else:
           if other:
               lang = other
               other = ''

        if lang == '': lang = '?'

        itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, title = '', url = lnk, language = lang, other = other ))

        i += 1

    return itemlist


def _las1001(item):
    logger.info()

    item.url = host_opts
    item.post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': 'Las 1001', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}
    item.start = 0
    item.search = ''
    item.pane = 'Las 1001'
    item.any = ''
    item.country = ''

    return list_all(item)

def _culto(item):
    logger.info()

    item.url = host_opts
    item.post = {'start': 0, 'length': perpage, 'metodo': 'ObtenerListaTotal', 'searchPanes[a5][0]': 'Pel\xc3\xadcula de Culto', 'search[value]': '', 'searchPanes[a4][0]': '', 'searchPanes[a6][0]': ''}
    item.start = 0
    item.search = ''
    item.pane = 'Pel\xc3\xadcula de Culto'
    item.any = ''
    item.country = ''

    return list_all(item)


def search(item, texto):
    logger.info()
    try:
        item.tex_search = texto
        item.url = host_opts
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
