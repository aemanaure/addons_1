# -*- coding: utf-8 -*-

import re, base64

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, jsontools, filetools, downloadtools, scrapertools, tmdb
from os import remove
import unicodedata
import random
import sys
import filecmp
import os, time, traceback

if sys.version_info[0] < 3: PY3 = False
else: PY3 = True

source = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
host = scrapertools.find_single_match(source, r'<host>([^<]+)<')
host_tvshow = 'https://gitlab.com/stiletto1/s/-/raw/main/s' # scrapertools.find_single_match(source, r'<host>([^<]+)<')

try:
    actu_xml = os.path.join(config.get_data_path(), 'actu.xml')
    act2_xml = os.path.join(config.get_data_path(), 'act2.xml')
    last_xml = os.path.join(config.get_data_path(), 'last.xml')
    las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
    
    if os.path.exists(actu_xml) == False:
        dat1 = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml', timeout=2).data
        filetools.write(actu_xml, dat1, mode="w")

    if os.path.exists(act2_xml) == False:
        dat3 = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml', timeout=2).data
        filetools.write(act2_xml, dat3, mode="w")

    if os.path.exists(last_xml) == False:
        dat2 = httptools.downloadpage(host, timeout=2).data
        filetools.write(last_xml, dat2, mode="w")

    dat0 = httptools.downloadpage(host, timeout=2).data 
    filetools.write(las0_xml, dat0, mode="w")
except:
    None

perpage = 25

def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'all', text_color = 'yellow' ))
    itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis', text_color = 'deepskyblue' ))
    itemlist.append(item.clone( title = 'Series', action = 'mainlist_series', text_color = 'hotpink' ))
    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        kudos = scrapertools.find_single_match(data, r'<kudos>([^<]+)<')
        if kudos:
            itemlist.append(item.clone( title = '[B]KUDOS: %s[/B]' % kudos, action = 'mainlist', text_color = 'coral' ))
    except:
        None

    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        active = scrapertools.find_single_match(data, r'<active>([^<]+)<')
        actu_xml = os.path.join(config.get_data_path(), 'actu.xml')
        last_xml = os.path.join(config.get_data_path(), 'last.xml')
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        if active == "0" and os.path.exists(actu_xml) == True and os.path.exists(last_xml) == True and os.path.exists(las0_xml) == True:
            itemlist.append(item.clone( title = 'Últimas añadidas', action = 'last', search_type = 'movie' ))
    except:
        None

    itemlist.append(item.clone( title = 'Cine destacado', action = 'selection', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Cine de culto', action = 'selection', search_type = 'movie' ))
    
    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        kudos = scrapertools.find_single_match(data, r'<kudos>([^<]+)<')
        if kudos:
            itemlist.append(item.clone( title = 'Por sagas', action = 'sagas', search_type = 'movie' ))
    except:
        None

    itemlist.append(item.clone( title = 'Por calidad', action = 'calidad', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Por géneros', action = 'generos', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Por años', action = 'anios', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Por letra (A - Z)', action = 'alfabeto', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Selección aleatoria', action = 'movies', search_type = 'movie' ))
    
    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/act.wishlist').data
        active = scrapertools.find_single_match(data, r'<active>([^<]+)<')
        if active == "0":
            itemlist.append(item.clone( title = "Wishlist", action = 'wishlist', search_type = 'movie' ))
    except:
        None

    return itemlist
    
    
def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar serie ...', action = 'search', search_type = 'tvshow', text_color = 'hotpink' ))

    itemlist.append(item.clone( title = 'Últimos capítulos añadidos', action = 'last_tvshow', search_type = 'tvshow' ))

    itemlist.append(item.clone( title = 'Por géneros', action = 'generos', search_type = 'tvshow' ))
    
    itemlist.append(item.clone( title = 'Por años', action = 'anios', search_type = 'tvshow' ))
    
    itemlist.append(item.clone( title = 'Por letra (A - Z)', action = 'alfabeto', search_type = 'tvshow' ))
    
    '''try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/act.wishlist').data
        active = scrapertools.find_single_match(data, r'<active>([^<]+)<')
        if active == "0":
            itemlist.append(item.clone( title = "Wishlist", action = 'wishlist', search_type = 'tvshow' ))
    except:
        None'''

    return itemlist
    
    
def wishlist(item):
    logger.info()
    itemlist = []
    
    url = 'https://raw.githubusercontent.com/pepemebe/mag/main/wishlist.xml'
    data = httptools.downloadpage(url).data
    
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)
    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'
    
    for tit, calidades, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, patron):

        title = normalizar(tit)
        cals = qualities(calidades)

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()

        itemlist.append(item.clone(
            title=title,
            tit=tit,
            type='movie',
            languages='Esp',
            lab=tit,
            qualities=cal0, #[*cals], #cals,
            uris=cals,
            thumbnail=poster,
            plot=plot,
            fanart=fanart,
            infoLabels={'year': year, 'plot': plot},
            contentTitle=title,
            contentType='movie',
            action='findvideos'
        ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def last(item):
    logger.info()
    itemlist = []
    auxlist = set()

    try:
        actu_xml = os.path.join(config.get_data_path(), 'actu.xml')
        act2_xml = os.path.join(config.get_data_path(), 'act2.xml')
        last_xml = os.path.join(config.get_data_path(), 'last.xml')
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
    
        diff = filecmp.cmp(las0_xml, last_xml, shallow=False)
        
        if diff == False:
            data = filetools.read(last_xml, mode="r")
            filetools.write(actu_xml, data, mode="w")

            data = filetools.read(las0_xml, mode="r")
            filetools.write(last_xml, data, mode="w")
    except:
        None

    try:
        actu_xml = os.path.join(config.get_data_path(), 'actu.xml')
        dat1 = filetools.read(actu_xml, mode="r")
    except:
        ur1 = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml'
        dat1 = httptools.downloadpage(ur1).data

    dat1 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat1)
    patro1 = r'<title>([^<]+)</'
    
    for tit in scrapertools.find_multiple_matches(dat1, patro1):
        title = normalizar(tit)
        if not title in auxlist:
            auxlist.add(title)

    try:
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        dat2 = filetools.read(las0_xml, mode="r")
    except:
        ur0 = host
        dat2 = httptools.downloadpage(ur0).data

    dat2 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat2)
    patro2 = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

    for tit, calidades, poster, fanart, year, plot in scrapertools.find_multiple_matches(dat2, patro2):

        title = normalizar(tit)
        cals = qualities(calidades)

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()

        if not title in auxlist:
            itemlist.append(item.clone(
                title=title,
                tit=tit,
                type='movie',
                languages='Esp',
                lab=tit,
                qualities=cal0, #[*cals], #cals,
                uris=cals,
                thumbnail=poster,
                plot=plot,
                fanart=fanart,
                infoLabels={'year': year, 'plot': plot},
                contentTitle=title,
                contentType='movie',
                action='findvideos'
            ))
    
    if len(itemlist) == 0:
        logger.info()
        itemlist = []
        auxlist = set()

        try:
            act2_xml = os.path.join(config.get_data_path(), 'act2.xml')
            dat1 = filetools.read(act2_xml, mode="r")
        except:
            ur1 = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml'
            dat1 = httptools.downloadpage(ur1).data

        dat1 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat1)
        patro1 = r'<title>([^<]+)</'
        
        for tit in scrapertools.find_multiple_matches(dat1, patro1):
            title = normalizar(tit)
            if not title in auxlist:
                auxlist.add(title)

        try:
            las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
            dat2 = filetools.read(las0_xml, mode="r")
        except:
            ur0 = host
            dat2 = httptools.downloadpage(ur0).data

        dat2 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat2)
        patro2 = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
                 r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

        for tit, calidades, poster, fanart, year, plot in scrapertools.find_multiple_matches(dat2, patro2):

            title = normalizar(tit)
            cals = qualities(calidades)

            #if PY3 == False:
            x = cals.keys()
            cal0 = []
            for it in x:
                cal0.append(it)
            '''else:
                cal0 = [*cals]'''
            cal0.reverse()

            if not title in auxlist:
                itemlist.append(item.clone(
                    title=title,
                    tit=tit,
                    type='movie',
                    languages='Esp',
                    lab=tit,
                    qualities=cal0, #[*cals], #cals,
                    uris=cals,
                    thumbnail=poster,
                    plot=plot,
                    fanart=fanart,
                    infoLabels={'year': year, 'plot': plot},
                    contentTitle=title,
                    contentType='movie',
                    action='findvideos'
                ))

    else:
        data = filetools.read(actu_xml, mode="r")
        filetools.write(act2_xml, data, mode="w")

    tmdb.set_infoLabels(itemlist)

    return itemlist


def last_tvshow(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage('https://pastebin.com/raw/xK0fNXET').data
    #data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'[0-9]+,([^,]+),([^,]+),([^\n]+)\n'

    for tit, temp, epi in scrapertools.find_multiple_matches(data, patron):

        title = normalizar(tit)
        temp = temp.strip().split(' ')[0].strip()
        
        if 'final' in epi.lower() or 'completa' in epi.lower():
            leg = ' -Completa-'
        else:
            leg = ''
        epi = epi.strip().split(' ')[1].strip()
        if not epi:
            epi = 'Temporada Completa'

        itemlist.append(item.clone(
            title='[COLOR=hotpink][%sx%s][/COLOR] %s[COLOR=hotpink] %s[/COLOR]' % (temp, epi, title, leg),
            tit=tit,
            type='tvshow',
            languages='Esp',
            query=tit,
            lab='last_tvs',
            qualities=None, # cal0, #[*cals], #cals,
            #uris=cals,
            #thumbnail=poster,
            #plot=plot,
            #fanart=fanart,
            #infoLabels={'year': year, 'plot': plot},
            contentTitle=title,
            contentType='tvshow',
            contentSerieName=title,
            action='search_tvshow'
        ))

    tmdb.set_infoLabels(itemlist)

    return itemlist # sorted(itemlist, key=lambda i: i.title)


def movies(item):
    logger.info()
    itemlist = []

    alea = "LA" if item.title == "Selección aleatoria" else "NO"

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        data = filetools.read(las0_xml, mode="r")
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

    matches = re.compile(patron, re.DOTALL).findall(data)

    num_matches = len(matches)
    desde = item.page * perpage
    hasta = desde + perpage

    if alea == "LA":
        match = matches
    else:
        match = matches[desde:hasta]
    
    for tit, calidades, poster, fanart, year, plot in match:
        
        title = normalizar(tit)
        cals = qualities(calidades)

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals['SD'] = cals['MicroHD'] #cals = 'SD'
            del cals['MicroHD'] 

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()

        if 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'
        
        if 'LA CENICIENTA. TRILOGIA' in tit:
            year = 'VARIOS'

        if alea == "LA":
            item.alea = "LA"
            if 'MARVEL' in tit or 'STAR WARS' in tit:
                title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                        tit else title.split(' -')[1].strip()
            if 'DEADPOOL' in tit and ':' in tit:
                title = title.split(': ')[1].strip()
            if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                title = title.split(': ')[1].strip()

        itemlist.append(item.clone(
            title=title,
            title2=title if not '¿' or not '¡' in tit else '00000000' + title,
            contentTitle=title,
            contentType='movie',
            lab=tit,
            thumbnail=poster,
            plot=plot,
            fanart=fanart,
            languages='Esp',
            infoLabels={'year': year, 'plot': plot},
            qualities=cal0, #[*cals], #cals,
            uris=cals,
            action='findvideos'
        ))

    tmdb.set_infoLabels(itemlist)

    if num_matches > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='movies',
            text_color='coral'
        ))

    return random.sample(itemlist, k = 10) if item.alea == "LA" else sorted(itemlist, key=lambda i: i.title2) 


def qualities(calidades):

    if not '&gt;' in calidades:
        cal1 = scrapertools.find_single_match(calidades, r'hd>([^<]+)</')
        cal2 = scrapertools.find_single_match(calidades, r'<fullhd>([^<]+)</')
        cal3 = scrapertools.find_single_match(calidades, r'<tresd>([^<]+)</')
        cal4 = scrapertools.find_single_match(calidades, r'<cuatrok>([^<]+)<')
    else:
        cal1 = scrapertools.find_single_match(calidades, r'hd&gt;([^&]+)&lt;/')
        cal2 = scrapertools.find_single_match(calidades, r'&lt;fullhd&gt;([^&]+)&lt;/')
        cal3 = scrapertools.find_single_match(calidades, r'&lt;tresd&gt;([^&]+)&lt;/')
        cal4 = scrapertools.find_single_match(calidades, r'&lt;cuatrok&gt;([^&]+)&lt;')

    cals = {}

    if cal1 != 'NA':
        cals['MicroHD'] = cal1
    if cal2 != 'NA':
        #cal2 = 'FullHD'
        cals['FullHD'] = cal2
        #if cal1 == 'MicroHD':
            #cals = cal2 + ', ' + cal1
    if cal3 != 'NA':
        #cal3 = '3D'
        cals['3D'] = cal3
        #if cal2 == 'FullHD':
            #cals = cal3 + ', ' + cal2
        #if cal1 == 'MicroHD':
            #cals = cals + ', ' + cal1
    if cal4 != 'NA':
        #cal4 = '4K'
        cals['4K'] = cal4
        #if cal3 == '3D':
            #cals = cal4 + ', ' + cal3
        #if cal2 == 'FullHD':
            #cals = cals + ', ' + cal2
        #if cal1 == 'MicroHD':
            #cals = cals + ', ' + cal1

    return cals


def normalizar(t):

    t = re.sub(r"0N", "ON", t)
    t = re.sub(r" PANTER", " PANTHER", t)

    if t == 'BABY':
        t = 'BABY (DEL TEMOR AL AMOR)'
    elif t == 'DESTINO FATAL II':
        t = 'DESTINO FINAL II'
    elif t == 'DESTINO FINAL V':
        t = 'DESTINO FINAL V (5)'
    elif t == 'ERASE UNA VEZ DEADPOOL':
        t = 'ÉRASE UNA VEZ UN DEADPOOL'
    elif t == 'OLD BOY':
        t = 'OLDBOY'
    elif t == 'WONDER':
        t = 'WONDER (EXTRAORDINARIO)'
    
    if "(SD)" in t or "( sd)" in t or "( sd )" in t or "( 1994 )" in t:
        t = re.sub(r"\(SD\)|\( sd\)|\( sd \)|\( 1994 \)", "", t)
    t = re.sub(r"&amp;", "AND", t)

    if PY3 == False:
        t = re.sub(r"Á", "A", t)
        t = re.sub(r"É", "E", t)
        t = re.sub(r"Í", "I", t)
        t = re.sub(r"Ó", "O", t)
        t = re.sub(r"Ú", "U", t)

    if PY3 == False:
        t = re.sub(r"á", "a", t)
        t = re.sub(r"é", "e", t)
        t = re.sub(r"í", "i", t)
        t = re.sub(r"ó", "o", t)
        t = re.sub(r"ú", "u", t)

    t = t.strip().title()

    if PY3 == False:
        t = re.sub(r"ÑA", "ña", t)
        t = re.sub(r"ÑE", "ñe", t)
        t = re.sub(r"ÑI", "ñi", t)
        t = re.sub(r"ÑO", "ño", t)
        t = re.sub(r"ÑU", "ñu", t)

        t = re.sub(r"ñA", "ña", t)
        t = re.sub(r"ñE", "ñe", t)
        t = re.sub(r"ñI", "ñi", t)
        t = re.sub(r"ñO", "ño", t)
        t = re.sub(r"ñU", "ñu", t)

    '''if PY3 == False:
        try:
            t = bytes.decode(t.lower())
        except:
            None'''

    #return ''.join((c for c in unicodedata.normalize('NFD', t.title()) if unicodedata.category(c) != 'Mn'))
    
    return t


def generos(item):
    logger.info()
    itemlist = []

    if item.search_type == 'tvshow':
        generos = {
            'Accion': 'Acción',
            'Animacion': 'Animación',
            'Aventuras': 'Aventuras',
            'Belico': 'Bélico',
            'Ciencia': 'Ciencia ficción',
            'Comedia': 'Comedia',
            'Documental': 'Documental',
            'Drama': 'Drama',
            'Fantastico': 'Fantástico',
            'Infantil': 'Infantil',
            'Intriga': 'Intriga',
            'Musical': 'Musical',
            'Romance': 'Romance',
            'Terror': 'Terror',
            'Thriller': 'Thriller',
            'Western': 'Western',
            }
        act = 'search_tvshow' # 'year_saga_search'
    else:
        generos = {
            'Accion': 'Acción',
            'Infantil': 'Animación y Familiar',
            'Aventura': 'Aventura',
            'Belico': 'Bélico',
            'Ciencia Ficcion': 'Ciencia ficción',
            'Comedia': 'Comedia',
            'Drama': 'Drama',
            'Fantastico': 'Fantástico',
            'Intriga': 'Intriga',
            'Musical': 'Musical',
            'Romance': 'Romance',
            'Terror': 'Terror',
            'Thriller': 'Thriller'
            }
        act = 'year_saga_search'

    for gen in sorted(generos):
        itemlist.append(item.clone( title=generos[gen], query=gen, lab='g', action=act ))

    return sorted(itemlist, key=lambda i: i.title)


def alfabeto(item):
    logger.info()
    itemlist = []

    if item.search_type == 'tvshow':
        act = 'search_tvshow'
    else:
        act = 'year_saga_search'

    for letra in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        if letra == '#':
            let = r"{0,1,2,3,4,5,6,7,8,9}"
        else:
            let = letra

        itemlist.append(item.clone( title=letra, query=let, lab='a', action=act ))

    return itemlist


def calidad(item):
    logger.info()
    itemlist = []
    aux = set()

    calidad = {
        'cuatrok': '4K',
        'tresd': '3D',
        'fullhd': 'FullHD',
        'microhd': 'MicroHD',
        'sd': 'SD'
        }

    for cal in sorted(calidad):
        if cal == 'sd':
            level = 5
        elif cal == 'microhd':
            level = 4
        elif cal == 'fullhd':
            level = 3
        elif cal == 'tresd':
            level = 2
        elif cal == 'cuatrok':
            level = 1
        
        if not cal in aux:
            aux.add(cal)
            itemlist.append(item.clone(title=calidad[cal], query=calidad[cal], qualities=calidad[cal], 
                                       level=level, lab='c', action='year_saga_search'))

    return sorted(itemlist, key=lambda i: i.level)


def year_saga_search(item):
    logger.info()
    itemlist = []
    aux = set()

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        data = filetools.read(las0_xml, mode="r")
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0

    if item.lab == 's':
        urs = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/cor'
        dats = httptools.downloadpage(urs).data

        for s in scrapertools.find_multiple_matches(dats, r" '(.*?)',"):
            aux.add(s)
    
    for tit, calidades, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        tit2 = normalizar(tit)
        item.query = normalizar(item.query)
        cals = qualities(calidades)

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals['SD'] = cals['MicroHD'] #cals = 'SD'
            del cals['MicroHD'] 

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()

        y = 0

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        elif 'LA SIRENITA ( TRILOGIA )' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA SIRENITA ( TRILOGIA )')
            year = 'VARIOS'
        
        if item.lab == 's':
            for s in aux:
                if s in tit:
                    genre = genre + ' Saga'
        if 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'

        if item.lab == 's':
            if 'Saga' in genre:
                item.query = re.sub(r"\s", "", item.query)
                tit2 = re.sub(r"\s", "", tit2)
                if item.query.lower() in tit2.lower():
                    y += 1
                    ilist += 1
                    if  desde < ilist <= hasta:
                        if 'MARVEL' in tit or 'STAR WARS' in tit:
                            if item.label == 'SPIDER-MAN':
                                y = year.upper()
                            else:
                                if PY3 == False:
                                    y = None
                                else:
                                    y = y
                        elif 'CLASICOS DE DISNEY' in tit:
                            y = tit
                        else:
                            y = year.upper()

                        itemlist.append(item.clone(
                            title=title,
                            type='movie',
                            contentTitle=title,
                            contentType='movie',
                            lab=tit,
                            y=y,
                            thumbnail=poster,
                            plot=plot,
                            fanart=fanart,
                            languages='Esp',
                            infoLabels={'year': year, 'plot': plot},
                            qualities=cal0, #[*cals], #cals,
                            uris=cals,
                            action='findvideos'
                        ))

        elif item.lab == 'y':
            if item.query.upper() == year.upper():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        title2=title if not '¿' or not '¡' in tit else '00000000' + title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cal0, #[*cals], #cals,
                        uris=cals,
                        action='findvideos'
                    ))

        elif item.lab == 'g':
            if PY3 == True:
                genre = ''.join((c for c in unicodedata.normalize('NFD', genre.title()) if unicodedata.category(c) != 'Mn'))
            if normalizar(item.query).lower() in normalizar(genre).lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cal0, #[*cals], #cals,
                        uris=cals,
                        action='findvideos'
                    ))

        elif item.lab == 'a':
            if title[0].lower() in item.query.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cal0, #[*cals], #cals,
                        uris=cals,
                        action='findvideos'
                    ))

        elif item.lab == 'c':
            #if item.query.lower() in cals.lower():
            cali = {}
            for cal in cals:
                if item.query.lower() in cal.lower():
                    cali[item.query] = cals[cal]
                    ilist += 1
                    if  desde < ilist <= hasta:
                        itemlist.append(item.clone(
                            title=title,
                            type='movie',
                            contentTitle=title,
                            contentType='movie',
                            lab=tit,
                            cal=item.query,
                            thumbnail=poster,
                            plot=plot,
                            fanart=fanart,
                            languages='Esp',
                            infoLabels={'year': year, 'plot': plot},
                            qualities=item.qualities,
                            uris=cali,
                            action='findvideos'
                        ))

        else:
            if normalizar(item.query).lower() in title.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cal0, #[*cals], #cals,
                        uris=cals,
                        action='findvideos'
                    ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            y='Zzzzzzzzzzzz',
            page=next_page,
            action='year_saga_search',
            text_color='coral'
        ))

    if item.lab == 's':
        '''if PY3 == False:
            return sorted(itemlist, key=lambda i: i.y)
        else:'''
        return sorted(itemlist, key=lambda i: i.y) #itemlist
    elif item.lab == 'y':
        return sorted(itemlist, key=lambda i: i.title2)
    else:
        return itemlist


def search_tvshow(item):
    logger.info()
    itemlist = []
    #aux = set()

    if not item.page: item.page = 0

    url = host_tvshow
    data = httptools.downloadpage(url).data
    #data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<title>([^<]+)</.*?<info>([^<]+)</.*?<year>([^<]+)</.*?<genre>([^<]+)</.*?' \
             '<thumb>([^<]+)</.*?<fanart>([^<]+)</.*?<seasons>(.*?)</seasons>'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, plot, year, genre, poster, fanart, seas in matches:

        title = normalizar(tit)
        #tit2 = normalizar(tit)
        item.query = normalizar(item.query)
        #cals = qualities(calidades)

        if item.lab == 'last_tvs':
            title = re.sub(r"\'|:|-|\.", "", title)
            item.query = re.sub(r"\'|:|-|\.", "", item.query)
            if item.query.lower().strip() == title.lower().strip():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='tvshow',
                        contentSerieName=title,
                        contentType='tvshow',
                        #lab=tit,
                        #cal=item.query,
                        seas=seas,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=None, # item.qualities,
                        #uris=cali,
                        action='seasons'
                    ))

                if len(itemlist) == 1:
                    #platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')
                    item.seas = seas
                    #item.season = season
                    item.page = 0
                    item.contentType = 'season'
                    #item.contentSeason = season
                    itemlist = seasons(item)
                    return itemlist

        elif item.lab == 'a':
            if title[0].lower() in item.query.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='tvshow',
                        contentSerieName=title,
                        contentType='tvshow',
                        #lab=tit,
                        seas=seas,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=None, #cal0, #[*cals], #cals,
                        #uris=cals,
                        action='seasons'
                    ))

        elif item.lab == 'y':
            if item.query.upper() == year.upper():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        title2=title, # if not '¿' or not '¡' in tit else '00000000' + title,
                        type='tvshow',
                        contentSerieName=title,
                        contentType='tvshow',
                        #lab=tit,
                        seas=seas,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=None, #cal0, #[*cals], #cals,
                        #uris=cals,
                        action='seasons'
                    ))

        elif item.lab == 'g':
            if PY3 == True:
                genre = ''.join((c for c in unicodedata.normalize('NFD', genre.title()) if unicodedata.category(c) != 'Mn'))
            if normalizar(item.query).lower() in normalizar(genre).lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='tvshow',
                        contentSerieName=title,
                        contentType='tvshow',
                        #lab=tit,
                        seas=seas,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=None, #cal0, #[*cals], #cals,
                        #uris=cals,
                        action='seasons'
                    ))

        else:
            if normalizar(item.query).lower() in title.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='tvshow',
                        contentSerieName=title,
                        contentType='tvshow',
                        #lab=tit,
                        seas=seas,
                        thumbnail=poster,
                        plot=plot,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=None, #cal0, #[*cals], #cals,
                        #uris=cals,
                        action='seasons'
                    ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            #title2='Zzzzzzzzzzzz',
            #y='Zzzzzzzzzzzz',
            page=next_page,
            action='search_tvshow',
            text_color='coral'
        ))

    return itemlist


def seasons(item):
    logger.info()
    itemlist = []

    data = item.seas
    patron = r'<season.id="([\d]+)"(.*?)</season>'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for season, data_post in matches:
        title='Temporada %s' % season

        if len(matches) == 1:
            platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')
            item.data_post = data_post
            item.season = season
            item.page = 0
            item.contentType = 'season'
            item.contentSeason = season
            itemlist = episodes(item)
            return itemlist

        itemlist.append(item.clone( action='episodes', data_post=data_post, title=title, season=season, 
                                    thumbnail=item.thumbnail, page = 0, contentType = 'season', 
                                    contentSeason = season, text_color='tan' ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def episodes(item):
    logger.info()
    itemlist = []

    data = item.data_post

    patron = r'<episode.id="\d+".name="([^"]+)".*?link="([0-9a-fA-F]{40})"'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for num_epi, url in matches:
        if ' A ' in num_epi:
            try:
                cap = num_epi.split(' ')[0].strip()
                if str(cap) + ' A ' in num_epi:
                    try:
                        cap_fi = num_epi.split(' A ')[1].strip()
                        clean_cap_fi = cap_fi.split(' ')[0].strip()
                        num_epi = re.sub(r"%s A %s" % (str(cap), str(clean_cap_fi)), r"%s AL %s" % (str(cap), str(clean_cap_fi)), num_epi)
                    except:
                        None
            except:
                None

        if normalizar(item.contentSerieName).lower() == 'lupin' and item.season == '2':
            num_epi = re.sub(r'1 AL 3', '4 AL 5 EMPEZAR POR EL QUINTO CAPITULO DESPUES YA ORDEN NORMAL', num_epi)
            num_epi = re.sub(r'EMPEZAR POR EL CAPITULO 5 DESPUES YA ORDEN NORMAL', '1 AL 3 EMPEZAR POR EL QUINTO CAPITULO DESPUES YA ORDEN NORMAL', num_epi)
        
        if ' AL ' in num_epi:
            try:
                num_epi_0 = num_epi.split(' AL ')[0].strip()
                num_epi_1 = num_epi.split(' AL ')[1].strip()

                if ' ' or '[A-Z]' in num_epi_0:
                    num_epi_0 = re.sub(r" |[A-Z]|\(.*?\)", "", num_epi_0)
                if ' ' or '[A-Z]' in num_epi_1:
                    num_epi_1 = re.sub(r" |[A-Z]|\(.*?\)", "", num_epi_1)
            except:
                None

        if ' AL ' in num_epi and num_epi_0 != '' and num_epi_1 != '':
            
            multi_epi = num_epi
            multi_episodes = range(int(num_epi_0), int(num_epi_1) + 1)
            
            for n in multi_episodes:
                if normalizar(item.contentSerieName).lower() == 'lupin' and item.season == '2':
                    num_epi = '%s[COLOR=coral] [Del %s][/COLOR]' % (str(n), multi_epi.lower())
                else:
                    num_epi = '%s[COLOR=coral] [Episodios del %s][/COLOR]' % (str(n), multi_epi)
                url = url

                itemlist.append(item.clone(action='findvideos', url=url, title=item.season + 'x' + num_epi, contentType='episode', 
                                    contentSeason = item.contentSeason, contentEpisodeNumber = n, 
                                    thumbnail=item.thumbnail, qualiteies=None ))

        else:
            num_epi_0 = num_epi.split(' ')[0].strip()
            itemlist.append(item.clone( action='findvideos', url=url, title=item.season + 'x' + normalizar(num_epi), contentType='episode', 
                                    contentSeason = item.contentSeason, contentEpisodeNumber = num_epi_0, 
                                    thumbnail=item.thumbnail, qualiteies=None ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def search_com(item):
    logger.info()
    itemlist = []

    url = host_tvshow
    data = httptools.downloadpage(url).data

    patron = r'<title>([^<]+)</.*?<info>([^<]+)</.*?<year>([^<]+)</.*?<genre>([^<]+)</.*?' \
             '<thumb>([^<]+)</.*?<fanart>([^<]+)</.*?<seasons>(.*?)</seasons>'
    matches = scrapertools.find_multiple_matches(data, patron)
    
    for tit, plot, year, genre, poster, fanart, seas in matches:

        title = normalizar(tit)

        if normalizar(item.query).lower() in title.lower():
            itemlist.append(item.clone(
                title=title + '[COLOR=hotpink] -Serie-[/COLOR]',
                type='tvshow',
                contentSerieName=title,
                contentType='tvshow',
                #lab=tit,
                seas=seas,
                thumbnail=poster,
                plot=plot,
                fanart=fanart,
                languages='Esp',
                infoLabels={'year': year, 'plot': plot},
                qualities=None, #cal0, #[*cals], #cals,
                #uris=cals,
                action='seasons'
            ))

    url = host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)
    
    for tit, calidades, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        tit2 = normalizar(tit)
        item.query = normalizar(item.query)
        cals = qualities(calidades)

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals['SD'] = cals['MicroHD'] #cals = 'SD'
            del cals['MicroHD'] 

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()

        #y = 0

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        elif 'LA SIRENITA ( TRILOGIA )' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA SIRENITA ( TRILOGIA )')
            year = 'VARIOS'
        
        '''if item.lab == 's':
            for s in aux:
                if s in tit:
                    genre = genre + ' Saga' '''
        if 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'
        
        if normalizar(item.query).lower() in title.lower():
            itemlist.append(item.clone(
                title=title + '[COLOR=deepskyblue] -Película-[/COLOR]',
                type='movie',
                contentTitle=title,
                contentType='movie',
                lab=tit,
                thumbnail=poster,
                plot=plot,
                fanart=fanart,
                languages='Esp',
                infoLabels={'year': year, 'plot': plot},
                qualities=cal0, #[*cals], #cals,
                uris=cals,
                action='findvideos'
            ))

    tmdb.set_infoLabels(itemlist)

    return sorted(itemlist, key=lambda i: i.title)


def search(item, query):
    logger.info()
    
    try:
        item.query = query
        if item.search_type == 'tvshow':
            return search_tvshow(item)
        elif item.search_type == 'movie':
            return year_saga_search(item)
        else:
            return search_com(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def selection(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    if item.title == 'Cine destacado':
        item.com = 'Estreno'
    elif item.title == 'Cine de culto':
        item.com = 'Culto'
    
    try:
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        data = filetools.read(las0_xml, mode="r")
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, calidades, poster, fanart, year, extra, plot in matches:
        if 'TYLER RAKE 2' in tit:
            extra = 'NA'
        if normalizar(item.com).lower() in normalizar(extra).lower() or item.com == 'last':
            ilist += 1
            if  desde < ilist <= hasta:
                title = normalizar(tit)

                cals = qualities(calidades)

                if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
                    cals['SD'] = cals['MicroHD'] #cals = 'SD'
                    del cals['MicroHD'] 

                #if PY3 == False:
                x = cals.keys()
                cal0 = []
                for it in x:
                    cal0.append(it)
                '''else:
                    cal0 = [*cals]'''
                cal0.reverse()

                if 'MARVEL' in tit or 'STAR WARS' in tit:
                    title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
                elif 'DEADPOOL' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()
                elif 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()

                total = scrapertools.find_single_match(calidades, r'hd>([^<]+)</')
                if total == '1' or total == '+1':
                    new = 'nueva'
                else:
                    new = 'nuevas'

                itemlist.append(item.clone(
                    title=title,
                    title2=title if not '¿' or not '¡' in tit else '00000000' + title,
                    type='movie',
                    contentTitle=title,
                    contentType='movie',
                    lab=tit,
                    last='NO',
                    thumbnail=poster,
                    plot=plot,
                    fanart=fanart,
                    languages='Esp',
                    infoLabels={'year': year, 'plot': plot},
                    qualities=cal0, #[*cals], #cals,
                    uris=cals,
                    action='findvideos'
                ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='selection',
            text_color='coral'
        ))

    return sorted(itemlist, key=lambda i: i.title2)


def sagas(item):
    logger.info()
    itemlist = []

    url = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/sag'
    data = httptools.downloadpage(url).data

    for s in scrapertools.find_multiple_matches(data, r" '(.*?)',"):
        r = s
        r = re.sub(r"\.\.\.", "", r)
        if r == 'SPIDER-MAN':
            r = 'SPIDER'
        
        itemlist.append(item.clone(
            title=s,
            label=s,
            query=r,
            lab='s',
            action='year_saga_search'
        ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []
    aux = set()

    if item.search_type == 'tvshow':
        data = httptools.downloadpage(host_tvshow).data
        data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)

        patron = r'<year>([^<]+)</'
        act = 'search_tvshow'
    else:
        try:
            las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
            data = filetools.read(las0_xml, mode="r")
        except:
            url = host
            data = httptools.downloadpage(url).data
        '''url = host
        data = httptools.downloadpage(url).data'''
        data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)

        patron = r'<date>([^<]+)</'
        act = 'year_saga_search'

    for year in scrapertools.find_multiple_matches(data, patron):
        year = year.upper()
        if year == '1019':
            year = '1917'
        elif year == '1950 - 2007':
            year = 'VARIOS'
        elif year == '2031':
            year = '2013'
        
        if not year in aux:
            aux.add(year)
            itemlist.append(item.clone(
                label=year,
                title=year,
                query=year,
                lab='y',
                action=act
            ))

    return sorted(itemlist, key=lambda i: i.label, reverse=True)


def findvideos(item):
    logger.info()
    itemlist = []

    #if item.search_type == 'tvshow':
    if not item.uris:
        
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + item.url,
                title='',
                level=0,
                #quality=cal,
                language='Esp',
                type='server',
                server='torrent'
            ))

    else:
        for cal in item.uris:
            url = item.uris[cal]
            if 'CLASICOS DE DISNEY' in item.lab or 'EL REY LEON 2' in item.lab or 'EL REY LEON 3' in item.lab:
                title = 'SD'
                #del cals['MicroHD'] 
            else:
                title = cal
            
            if cal == 'SD':
                level = 5
            elif cal == 'MicroHD':
                level = 4
            elif cal == 'FullHD':
                level = 3
            elif cal == '3D':
                level = 2
            elif cal == '4K':
                level = 1
        
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + url,
                title=title, #'',
                level=level,
                quality=cal,
                language='Esp',
                type='server',
                server='torrent'
            ))

    '''try:
        las0_xml = os.path.join(config.get_data_path(), 'las0.xml')
        data = filetools.read(las0_xml, mode="r")
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|\(|\)|\¿|\?|<b>|\s{2}|&nbsp;", "", data)
    item.lab =re.sub(r"\(|\)|\¿|\?", "", item.lab)

    patron = r'<item.*?<title>%s</.*?tle>(.*?)<thumb' % item.lab

    cal = scrapertools.find_single_match(data, patron)

    matches = re.compile(r'<([^<]+)>([^<]+)</', re.DOTALL).findall(cal)
    
    for calidad, url in matches:
        if calidad == 'microhd':
            calidad = 'MicroHD'
            level = 4
        elif calidad == 'fullhd':
            calidad = 'FullHD'
            level = 3
        elif calidad == 'tresd':
            calidad = '3D'
            level = 2
        elif calidad == 'cuatrok':
            calidad = '4K'
            level = 1
        
        if 'CLASICOS DE DISNEY' in item.lab or 'EL REY LEON 2' in item.lab or 'EL REY LEON 3' in item.lab:
            cal = 'SD'
            level = 5
        else:
            cal = calidad
        
        if item.cal:
            if url != 'NA' and item.cal.lower() == calidad.lower():
                itemlist.append(item.clone(
                    action="play",
                    url='magnet:?xt=urn:btih:' + url,
                    title='',
                    level=level,
                    quality=cal,
                    language='Esp',
                    type='server',
                    server='torrent'
            ))

        elif url != 'NA':
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + url,
                title='',
                level=level,
                quality=cal,
                language='Esp',
                type='server',
                server='torrent'
            ))'''

    return sorted(itemlist, key=lambda i: i.level) # itemlist #

