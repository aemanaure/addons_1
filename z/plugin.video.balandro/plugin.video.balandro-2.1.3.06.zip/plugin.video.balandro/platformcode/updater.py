# -*- coding: utf-8 -*-

import os, time, traceback

from platformcode import config, logger, platformtools
from core import httptools, jsontools, filetools, downloadtools, scrapertools


def check_addon_updates(verbose=False, force=False):
    logger.info()

    color_alert = config.get_setting('notification_alert_color', default='red')
    color_infor = config.get_setting('notification_infor_color', default='pink')
    color_adver = config.get_setting('notification_adver_color', default='violet')
    color_avis  = config.get_setting('notification_avis_color', default='yellow')
    color_exec  = config.get_setting('notification_exec_color', default='cyan')

    get_last_chrome_list()
    
    ADDON_UPDATES_JSON = 'https://raw.githubusercontent.com/balandro-tk/addon_updates/main/updates-v2.1.0.json'
    ADDON_UPDATES_ZIP  = 'https://raw.githubusercontent.com/balandro-tk/addon_updates/main/updates-v2.1.0.zip'
    ADDON_UPDATES_MOD_JSON = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/upd/upd_mod_fix.json'
    ADDON_UPDATES_MOD_ZIP  = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/upd/upd_mod_fix.zip'

    try:
        last_fix_json = os.path.join(config.get_runtime_path(), 'last_fix.json')
        last_fix_mod = os.path.join(config.get_runtime_path(), 'last_fix_mod.json')

        if force:
            if os.path.exists(last_fix_mod):
                os.remove(last_fix_mod)
            if os.path.exists(last_fix_json):
                os.remove(last_fix_json)

        data = httptools.downloadpage(ADDON_UPDATES_JSON, timeout=2).data
        data_mod = httptools.downloadpage(ADDON_UPDATES_MOD_JSON, timeout=2).data
        if data == '':
            logger.info('No se encuentra addon_updates')
            if verbose:
                platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]No se encuentra addon_updates[/COLOR][/B]' % color_alert)
            return False

        data = jsontools.load(data)
        data_mod = jsontools.load(data_mod)
        if 'addon_version' not in data or 'fix_version' not in data:
            if os.path.exists(last_fix_mod):
                lastfixmod = jsontools.load(filetools.read(last_fix_mod))
                if lastfixmod['mod_version'] == data_mod['mod_version']:
                    logger.info('Sin Fix actualizaciones pdtes.')
                    if verbose:
                        platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]Sin Fix actualizaciones pdtes.[/COLOR][/B]' % color_adver)
                    return False
                else:
                    ADDON_UPDATES_ZIP = ADDON_UPDATES_MOD_ZIP
            else:
                ADDON_UPDATES_ZIP = ADDON_UPDATES_MOD_ZIP

        current_version = config.get_addon_version(with_fix=False)
        if current_version < data['addon_version']:
            if os.path.exists(last_fix_mod):
                lastfixmod = jsontools.load(filetools.read(last_fix_mod))
                if lastfixmod['mod_version'] == data_mod['mod_version']:
                    logger.info('Versión Incorrecta NO se actualizan Fixes para la versión %s' % current_version)
                    if verbose:
                        platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]Versión incorrecta NO se actualizan Fixes[/COLOR][/B]' % color_alert)
                    return False
                else:
                    ADDON_UPDATES_ZIP = ADDON_UPDATES_MOD_ZIP
            else:
                ADDON_UPDATES_ZIP = ADDON_UPDATES_MOD_ZIP
        
        if current_version < data_mod['addon_version']:
            if os.path.exists(last_fix_mod):
                os.remove(last_fix_mod)
            logger.info('Versión Incorrecta NO se actualizan Mods para la versión %s' % current_version)
                    
            if verbose:
                platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]Versión incorrecta NO se actualizan Mods[/COLOR][/B]' % color_alert)
                        
            return False
            
        if os.path.exists(last_fix_json) and os.path.exists(last_fix_mod):
            lastfix = jsontools.load(filetools.read(last_fix_json))
            lastfixmod = jsontools.load(filetools.read(last_fix_mod))
            if lastfix['addon_version'] == data['addon_version'] and lastfix['fix_version'] == data['fix_version'] and lastfixmod['mod_version'] == data_mod['mod_version']:
                logger.info('Está actualizado. Versión %s.fix%d mod%d' % (current_version, data['fix_version'], data_mod['mod_version']))

                if verbose:
                    tex1 = '[B][COLOR %s]Actualizado: %s.fix%d mod%d[/COLOR][/B]' % (color_adver, current_version, data['fix_version'], data_mod['mod_version'])
                    platformtools.dialog_notification(config.__addon_name, tex1)

                return False

        if os.path.exists(last_fix_json) and os.path.exists(last_fix_mod):
            lastfix = jsontools.load(filetools.read(last_fix_json))
            lastfixmod = jsontools.load(filetools.read(last_fix_mod))
            if lastfix['addon_version'] == data['addon_version'] and lastfix['fix_version'] == data['fix_version']:
                
                if lastfixmod['mod_version'] < data_mod['mod_version'] and current_version == data_mod['addon_version']:
                    ADDON_UPDATES_ZIP = ADDON_UPDATES_MOD_ZIP
                elif current_version < data_mod['addon_version']:
                    logger.info('Versión Incorrecta NO se actualizan Mods para la versión %s' % current_version)
                    
                    if verbose:
                        platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]Versión incorrecta NO se actualizan Mods[/COLOR][/B]' % color_alert)
                        
                    return False
                    
                else:
                    logger.info('Está actualizado. Versión %s.fix%d mod%d' % (current_version, data['fix_version'], data_mod['mod_version']))
                    
                    if verbose:
                        tex1 = '[B][COLOR %s]Actualizado: %s.fix%d mod%d[/COLOR][/B]' % (color_adver, current_version, data['fix_version'], lastfixmod['mod_version'])
                        platformtools.dialog_notification(config.__addon_name, tex1)

                    return False
                    
        localfilename = os.path.join(config.get_data_path(), 'temp_updates.zip')
        if os.path.exists(localfilename): os.remove(localfilename)

        down_stats = downloadtools.do_download(ADDON_UPDATES_ZIP, config.get_data_path(), 'temp_updates.zip', silent=True, resume=False)
        if down_stats['downloadStatus'] != 2:
            logger.info('No se pudo descargar la actualización')
            if verbose:
                platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]No se pudo descargar la actualización[/COLOR][/B]' % color_alert)

            return False

        try:
            import zipfile
            dir = zipfile.ZipFile(localfilename,'r')
            dir.extractall(config.get_runtime_path())
            dir.close()
        except:
            import xbmc
            xbmc.executebuiltin('Extract("%s", "%s")' % (localfilename, config.get_runtime_path()))
            time.sleep(2)

        os.remove(localfilename)

        if ADDON_UPDATES_ZIP == ADDON_UPDATES_MOD_ZIP:
            filetools.write(last_fix_mod, jsontools.dump(data_mod))
            if data_mod['mod_version'] == 0:
                data_mod['mod_version'] = ''
            logger.info('Mod actualizado: %s mod%s' %  (current_version, data_mod['mod_version']))

            if verbose:
                tex1 = '[B][COLOR %s]Mod actualizado: %s mod%s[/COLOR][/B]' % (color_avis, current_version, data_mod['mod_version'])
                platformtools.dialog_notification(config.__addon_name, tex1)
        else:
            filetools.write(last_fix_json, jsontools.dump(data))

            logger.info('Addon actualizado correctamente a a %s.fix%d' %  (current_version, data['fix_version']))

            if verbose:
                tex1 = '[B][COLOR %s]Fix actualizado: %s.fix%d[/COLOR][/B]' % (color_avis, current_version, data['fix_version'])
                platformtools.dialog_notification(config.__addon_name, tex1)

        time.sleep(3)
        
        if ADDON_UPDATES_ZIP == 'https://raw.githubusercontent.com/balandro-tk/addon_updates/main/updates-v2.1.0.zip':
            
            localfilename = os.path.join(config.get_data_path(), 'temp_mod_updates.zip')
            if os.path.exists(localfilename): os.remove(localfilename)
            
            down_stats = downloadtools.do_download(ADDON_UPDATES_MOD_ZIP, config.get_data_path(), 'temp_mod_updates.zip', silent=True, resume=False)
            
            if down_stats['downloadStatus'] != 2:
                logger.info('No se pudo descargar la actualización')
                if verbose:
                    platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]No se pudo descargar la actualización[/COLOR][/B]' % color_alert)
                
                return False
            
            try:
                import zipfile
                dir = zipfile.ZipFile(localfilename,'r')
                dir.extractall(config.get_runtime_path())
                dir.close()
            except:
                import xbmc
                xbmc.executebuiltin('Extract("%s", "%s")' % (localfilename, config.get_runtime_path()))
                time.sleep(2)
                
            os.remove(localfilename)
            
            filetools.write(last_fix_mod, jsontools.dump(data_mod))
                
            logger.info('Mod actualizado: %s fix%d mod%d' % (current_version, data['fix_version'], data_mod['mod_version']))
            
            if verbose:
                tex1 = '[B][COLOR %s]Mod actualizado: %s fix%d mod%d[/COLOR][/B]' % (color_avis, current_version, data['fix_version'], data_mod['mod_version'])
                platformtools.dialog_notification(config.__addon_name, tex1)

        return True
    except:
        logger.error('Error comprobación actualizaciones!')
        logger.error(traceback.format_exc())
        if verbose:
            platformtools.dialog_notification(config.__addon_name, '[B][COLOR %s]Error comprobación actualizaciones[/COLOR][/B]' % color_alert)
        return False


def get_last_chrome_list():
    logger.info()

    ver_stable_chrome = config.get_setting("ver_stable_chrome", default=True)

    if ver_stable_chrome:
        try:
           data = httptools.downloadpage('https://omahaproxy.appspot.com/all?csv=1').data
           web_last_ver_chrome = scrapertools.find_single_match(data, "win64,stable,([^,]+),")
        except:
           web_last_ver_chrome = ''

        if not web_last_ver_chrome == '':
            config.set_setting('chrome_last_version', web_last_ver_chrome)

def check_addon_version():
    logger.info()
    from xml.etree import ElementTree
    repo_url = 'https://raw.githubusercontent.com/balandro-tk/balandro/main/addons.xml'
    repo_data = httptools.downloadpage(repo_url, timeout=10).data
    xml = ElementTree.fromstring(repo_data)
    addon = list(filter(lambda x: x.get("id") == config.__addon_id, xml.findall('addon')))[0]

    if addon.get('version') <= config.get_addon_version(False):
        return True

    return False
