# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, tmdb


host = 'https://www.pelitorrent.com/'

def mainlist(item):
    return mainlist_pelis(item)


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_categ_search', 
                                url = host + 'torrents-peliculas/', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Más vistas', action = 'list_top', url = host, search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por años', action = 'anios', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por alfabeto', action = 'alfabeto', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    generos = {
        'accion': 'Acción',
        'animacion': 'Animación',
        'aventura': 'Aventura',
        'belica': 'Bélica',
        'ciencia-ficcion': 'Ciencia ficción',
        'comedia': 'Comedia',
        'crimen': 'Crimen',
        'documental': 'Documental',
        'drama': 'Drama',
        'familia': 'Familia',
        'fantasia': 'Fantasía',
        'guerra': 'Guerra',
        'historia': 'Historia',
        'misterio': 'Misterio',
        'musica': 'Música',
        'romance': 'Romance',
        'suspense': 'Suspense',
        'terror': 'Terror',
        'western': 'Western'
        }

    for gen in sorted(generos):
        itemlist.append(item.clone( title=generos[gen], url=host + 'peliculas/' + gen + '/', 
                                    action='list_categ_search' ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []

    url = host + 'peliculas/estrenos-'

    itemlist.append(item.clone( title='2021', url=url + '2021/', action='list_categ_search' ))
    itemlist.append(item.clone( title='2020', url=url + '2020/', action='list_categ_search' ))
    itemlist.append(item.clone( title='2019', url=url + '2019/', action='list_categ_search' ))
    itemlist.append(item.clone( title='2018', url=url + '2018/', action='list_categ_search' ))

    return itemlist


def alfabeto(item):
    logger.info()
    itemlist = []

    for letra in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        url = host + 'letters/%s/' % letra
        if letra == '#':
            url = host + 'letters/0-9/'

        itemlist.append(item.clone( title=letra, url=url , action='list_categ_search' ))

    return itemlist


def do_downloadpage(url, post=None, headers=None, raise_weberror=True):
    if not headers:
        headers = {'Referer': host}

    data = httptools.downloadpage(url, post=post, headers=headers, raise_weberror=raise_weberror).data
    
    return data


def detectar_idioma(langs):
    if 'spanish.png' in langs:
        return 'Esp'
    elif'mx.png' in langs:
        return 'Lat'
    else:
        return None


def limpiar_poster(thumbs):
    thumbs = re.sub(r"-[0-9]{3}x[0-9]{3}.jpg", ".jpg", thumbs)

    return thumbs

def list_top(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    patron = r'entry-header fg1">.*?"entry-title">([^<]+)<.*?class="year">([0-9]{4})</span>.*?' \
            '<figure>.*?width=".*?src="([^"]+).*?href="([^"]+)'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for title, year, thumbs, url in matches:
        title = title.strip()
        
        thumb = limpiar_poster(thumbs)

        itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, 
                                    contentType='movie', contentTitle=title, infoLabels={'year': year} ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def list_categ_search(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    patron = r'entry-header">.*?"entry-title">([^<]+).*?<.*?<figure>.*?width=".*?' \
            'src="([^"]+).*?/figure>(.*?)</div>.*?href="([^"]+)"'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for title, thumbs, comp, url in matches:
        title = title.strip()
        qlt = scrapertools.find_single_match(comp, r'class="Qlty">([^<]+)</span')
        langs = scrapertools.find_single_match(comp, r'class="lang"><img loading="lazy" src="([^"]+)"></span')
        year = scrapertools.find_single_match(comp, r'class="year">([0-9]{4})</span')
        
        thumb = limpiar_poster(thumbs)
        lang = detectar_idioma(langs)

        itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, 
                                    languages=lang, qualities=qlt, contentType='movie', 
                                    contentTitle=title, infoLabels={'year': year} ))

    tmdb.set_infoLabels(itemlist)

    next_page = scrapertools.find_single_match(data, 'href="([^"]+)" >SIGUIENTE</a')
    if next_page:
        itemlist.append(item.clone( title='>> Página siguiente', url=next_page, 
                                    action='list_categ_search', text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    patron = r'orrent</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span>.*?href="([^"]+)" class'
    
    matches = re.compile(patron, re.DOTALL).findall(data)

    for lang, qlt, url in matches:
        url = re.sub(r"&#038;|&amp;", "&", url)

        itemlist.append(Item( action = 'play', title = '', url = url, server = 'torrent',
                              type = 'server', language = lang, quality = qlt ))

    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + '?s=' + texto.replace(" ", "+")
        return list_categ_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
