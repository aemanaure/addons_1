# -*- coding: utf-8 -*-
from core.libs import *


class Cloudflare:
    def __init__(self, response):
        self.start_time = time.time()
        self.timeout = 5
        self.domain = urllib_parse.urlparse(response["url"])[1]
        self.protocol = urllib_parse.urlparse(response["url"])[0]
        self.http_data = response["data"]
        self.http_headers = response["headers"]
        self.http_code = response["code"]
        self.operations = None
        self.inital_value = None
        self.finish = None
        self.action = None
        self.params = None
        self.div = None
        self.method = None

    def get_cloudflare(self):
        try:
            self.inital_value = re.compile(r'setTimeout.*?:([^}]+)};', re.DOTALL).findall(self.http_data)[0]
            self.operations = list(map(list, re.compile(
                r'[a-zA-Z]+\.[a-zA-Z]+([*+\-/]=)([+*/-f][^;]+(?:;\s+[^;]+)?)').findall(self.http_data)))
            self.finish = re.compile(r'.value = [^.]+.[^.]+([^;]+)').findall(self.http_data)[0]
            self.action = re.compile(r'action="([^"]+)"', re.DOTALL).findall(self.http_data)[0]
            self.method = re.compile(r'method="([^"]+)"', re.DOTALL).findall(self.http_data)[0]
            self.params = self.get_params()
            self.div = re.compile(r'<div style="display:none;visibility:hidden;".*?>([^<]+)</div>', re.DOTALL).findall(
                self.http_data)[0]
        except IndexError:
            logger.debug(self.http_data)

    def get_params(self):
        params = {}
        pattern = '(<input type="hidden".*?/>)'
        for item in re.compile(pattern, re.DOTALL).findall(self.http_data):
            name = re.compile(r'name="([^"]+)"', re.DOTALL).findall(item)
            value = re.compile(r'value="([^"]+)"', re.DOTALL).findall(item)
            if name and value:
                params[name[0]] = value[0]
        return params

    @property
    def wait_time(self):
        return 4

    @property
    def is_cloudflare(self):
        if self.http_code in (503,):
            if re.compile(r'<span class="ray_id">Ray ID: <code>[0-f]+</code></span>').findall(self.http_data):
                return True
        return False

    def get_url(self):
        import js2py
        self.get_cloudflare()

        for operation in self.operations:
            operation[1] = re.sub(
                r'function\(p\){return.*?}\((.*?)\)\)\)$',
                lambda x: str(ord(self.domain[int(js2py.eval_js(x.group(1)))])) + '));',
                operation[1]
            )
            operation[1] = re.sub(
                r'function\(p\){var p =.*?}\(\)',
                self.div,
                operation[1]
            )

        js_code = """
        var start = %s;\n
        %s
        start%s;
        """ % (
            self.inital_value,
            ";\n".join(["start%s%s" % tuple(o) for o in self.operations]),
            self.finish
        )

        self.params["jschl_answer"] = js2py.eval_js(js_code)

        if self.method == 'POST':
            response = "%s://%s%s" % (
                self.protocol,
                self.domain,
                self.action
            ), self.params
        else:
            response = "%s://%s%s?%s" % (
                self.protocol,
                self.domain,
                self.action,
                urllib_parse.urlencode(self.params)
            ), False

        wait_time = 4 - (time.time() - self.start_time)
        time.sleep(max(wait_time, 0))

        return response


def get_cloudflare_headers(url):
    """
    Añade los headers para cloudflare
    :param url: Url
    :type url: str
    """
    domain_cookies = getattr(httptools.cj, '_cookies').get("." + urllib_parse.urlparse(url)[1], {}).get("/", {})

    if "cf_clearance" not in domain_cookies:
        return url

    headers = dict()
    headers["User-Agent"] = httptools.default_headers["User-Agent"]
    headers["Cookie"] = "; ".join(["%s=%s" % (c.name, c.value) for c in domain_cookies.values()])

    return url + '|%s' % '&'.join(['%s=%s' % (k, v) for k, v in headers.items()])


def retry_if_cloudflare(response, args):
    def clear_cookies():
        cf_cookies = getattr(httptools.cj, '_cookies').get('.' + urllib_parse.urlparse(args['url'])[1], {}).get('/', {})
        cf_cookies.pop('__cfduid', None)
        cf_cookies.pop('cf_clearance', None)
        cf_cookies.pop('__cf_bm', None)
        httptools.save_cookies()

    cf = Cloudflare(response)
    if cf.is_cloudflare:
        logger.info("cloudflare detectado, esperando %s segundos..." % cf.wait_time)
        clear_cookies()
        auth_url, post = cf.get_url()
        logger.info("Autorizando... url: %s" % auth_url)
        auth_args = args.copy()
        auth_args['url'] = auth_url
        auth_args['follow_redirects'] = False
        auth_args['bypass_cloudflare'] = False
        if not isinstance(auth_args['headers'], dict):
            auth_args['headers'] = {}
        auth_args['headers']['Referer'] = args['url']
        auth_args['post'] = post
        resp = httptools.downloadpage(**auth_args)
        if resp.sucess and 'cf_clearance' in resp.cookies:
            logger.info("Autorización correcta, descargando página")
            args['bypass_cloudflare'] = False
            return httptools.downloadpage(**args).__dict__
        elif resp.code == 403 and resp.headers.get('cf-chl-bypass'):
            logger.info('cloudflare solicita captcha...')
            if [a[3] for a in inspect.stack()].count('retry_if_cloudflare') > 1:
                logger.info("No se ha podido autorizar. Captcha requerido")
                return response
            logger.info("Reintentando...")
            # Eliminamos cookies
            clear_cookies()
            return httptools.downloadpage(**args).__dict__
        else:
            logger.info("No se ha podido autorizar")
    return response
