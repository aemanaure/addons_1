# -*- coding: utf-8 -*-
import base64
import gzip
from email.parser import Parser
from io import StringIO, BytesIO

from six.moves import http_client, urllib_request, urllib_error

from core.http.request import Request
from core.libs import *


class HTTPResponse:
    def __init__(self, response, host):
        self.msg = ''
        self.fp = None
        self._response = response
        self._raw_headers = six.ensure_text(str(self._response.headers))
        self._extract_cookies(host)
        self._modify_location()
        self._modify_data()
        self.msg = http_client.HTTPMessage(StringIO(self._raw_headers or None))

    def _modify_data(self):
        data = self._response.read()
        new_data = data
        if 'content-type: text/html' in self._raw_headers:
            if 'content-encoding: gzip' in self._raw_headers:
                data = gzip.GzipFile(fileobj=BytesIO(data)).read()
            new_data = re.sub(six.ensure_binary(r'<head><base __cpGenerated="1".*?\n'), b'<head>\n', data)
            if 'content-encoding: gzip' in self._raw_headers:
                enc = BytesIO()
                gzip.GzipFile(fileobj=enc, mode='wb').write(new_data)
                new_data = enc.getvalue()

            self._raw_headers = re.sub(r'content-length: \d+', r'content-length: %d' % len(new_data), self._raw_headers)

        self.fp = BytesIO(new_data)

    @staticmethod
    def extract_cpo_url(cpo):
        missing_padding = len(cpo) % 4
        if missing_padding:
            cpo += '=' * (4 - missing_padding)
        return base64.b64decode(cpo)

    def _modify_location(self):
        """
        En caso de una respuesta 30x el header location viene con la url modificada para que se abra mediante el proxy
        extraemos la url original y la modificamos para poder obtener el header location correcto en caso de no seguir
        las redirecciones
        :return:
        """
        location = re.compile(r'^(location: (.*?)\r\n)', re.MULTILINE).findall(self._raw_headers)
        if location:
            location_url = urllib_parse.urlparse(location[0][1])
            query = dict(urllib_parse.parse_qsl(location_url.query))
            cpo_url = urllib_parse.urlparse(self.extract_cpo_url(query.pop('__cpo')))
            new_url = urllib_parse.urlunparse((
                cpo_url.scheme,
                cpo_url.netloc,
                location_url.path,
                location_url.params,
                urllib_parse.urlencode(query),
                location_url.fragment
            ))

            self._raw_headers = self._raw_headers.replace(location[0][0], 'location: %s\r\n' % new_url)

    def _extract_cookies(self, host):
        """
        El proxy devuelve las cookies en formato:
            nombrecookie@dominio.xyz=valor, lo modificamos para que tenga un formato estander y se guarden en su sitio
            luego modificamos el valor Domain:... modificando hosteagle.club por el dominio correcto.
        :param host:
        :return:
        """
        cookies = re.compile(r'(^set-cookie: .*?\r\n)', re.MULTILINE).findall(self._raw_headers)
        for cookie in cookies:
            # Las cookies especificas de la url se modifican:
            # Se cambia el nombre y se cambia el dominio
            if '@%s' % host in cookie:
                new_cookie = cookie.replace('@%s' % host, '')
                new_cookie = re.sub(r'Domain=[^;\r\n]+', 'Domain=%s' % host, new_cookie)
                self._raw_headers = self._raw_headers.replace(cookie, new_cookie)
            # El resto de cookies se eliminan, pues no son de la url
            else:
                self._raw_headers = self._raw_headers.replace(cookie, '')

    def info(self):
        return Parser(_class=http_client.HTTPMessage).parsestr(self._raw_headers)

    def read(self, rbufsize=None):
        return self.fp.read(rbufsize)

    @property
    def headers(self):
        return self.info()

    def geturl(self):
        return self._response.geturl()

    @property
    def reason(self):
        return ''

    @property
    def status(self):
        return self._response.getcode()

    @property
    def code(self):
        return self._response.code

    def close(self):
        pass


class HTTPConnection(http_client.HTTPConnection):
    name = 'proxyscrape.com'
    proxy_url = 'https://hosteagle.club'

    def __init__(self, *args, **kwargs):
        self.proto = kwargs.pop('proto')
        self.proxy_response = None
        self.dest_host = None

        http_client.HTTPConnection.__init__(self, *args, **kwargs)

    def _enable_cpo(self):
        last_update = settings.get_setting('last_cpo', __file__) or 0
        cookies = httptools.get_cookies(urllib_parse.urlparse(self.proxy_url).netloc)
        if time.time() - last_update < 3600 and '__cpc' in cookies:
            return

        self._create_opener(True).open(
            Request('https://proxyscrape.com/proxyrequest'),
            six.ensure_binary('url=%s' % urllib_parse.quote('%s://%s' % (self.proto, self.dest_host)))
        )
        settings.set_setting('last_cpo', time.time(), __file__)

    @staticmethod
    def _create_opener(cookies, redirect=True):
        from core import httptools
        handlers = [
            HTTPHandler(),
            HTTPSHandler()
        ]
        if cookies:
            handlers.append(urllib_request.HTTPCookieProcessor(httptools.cj))
        if not redirect:
            handlers.append(NoRedirectHandler())
        return urllib_request.build_opener(*handlers)

    def _merge_cookies(self, headers):
        cookies = httptools.get_cookies(urllib_parse.urlparse(self.proxy_url)[1])
        ck = '; '.join('%s=%s' % (k, v) for k, v in cookies.items())

        if headers.get('Cookie'):
            headers['Cookie'] = re.sub(r'([^=]+)=([^;]+)', r'\1@%s=\2' % self.dest_host, headers['Cookie'])
            headers['Cookie'] += '; ' + ck
        else:
            headers['Cookie'] = ck

    def _create_url(self, url):
        if '?' in url:
            url, query = url.split('?')
        else:
            query = ''

        query = dict(
            [scrapertools.find_single_match(p, r'([^=])+=(.*)') if '=' in p else (p, '') for p in query.split('&') if
             p])
        _url = '%s://%s' % (self.proto, self.dest_host)
        query['__cpo'] = base64.b64encode(six.ensure_binary(_url)).replace(b'=', b'')

        return self.proxy_url + url + '?' + urllib_parse.urlencode(query)

    def _send_request(self, method, url, body, headers, retry=False, *_,  **__):
        orig_headers = headers.copy()
        self.dest_host = headers.pop('Host')
        self._enable_cpo()
        self._merge_cookies(headers)

        request_url = self._create_url(url)

        try:
            self.proxy_response = self._create_opener(False, False).open(
                Request(request_url, method=method, headers=headers),
                body
            )

        except urllib_error.HTTPError as e:
            if not retry:
                settings.pop_setting('last_server',  __file__)
                settings.pop_setting('last_cpo', __file__)
                return self._send_request(method, url, body, orig_headers, retry=True)
            self.proxy_response = e

    def getresponse(self, *args, **kwargs):
        return HTTPResponse(self.proxy_response, self.dest_host)
