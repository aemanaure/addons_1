# -*- coding: utf-8 -*-

import re, base64

from platformcode import logger
from core.item import Item
from core import httptools, scrapertools, tmdb
import unicodedata
import random

host = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
host_last = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/last'

perpage = 25

def mainlist(item):

    return mainlist_pelis(item)


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Últimas añadidas', action = 'selection', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Cine destacado', action = 'selection', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Cine de culto', action = 'selection', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Sagas', action = 'sagas', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Listado por años', action = 'anios', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Listado alfabético', action = 'movies', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Selección aleatoria', action = 'movies', search_type = 'movie' ))

    itemlist.append(item.clone( title = '[COLOR yellow]Buscar[/COLOR]', action = 'search', search_type = 'movie' ))

    return itemlist


def movies(item):
    logger.info()
    itemlist = []

    alea = "LA" if item.title == "Selección aleatoria" else "NO"

    if not item.page: item.page = 0
    
    url = host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<info>([^<]+)</'
    matches = re.compile(patron, re.DOTALL).findall(data)

    num_matches = len(matches)
    desde = item.page * perpage
    hasta = desde + perpage

    if alea == "LA":
        match = matches
    else:
        match = matches[desde:hasta]
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, plot in match:
        
        title = normalizar(tit)

        if 'PROMETHEUS' in tit:
            cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'
        
        if cal1 != 'NA':
            cal1 = 'MicroHD'
            cals = cal1
        if cal2 != 'NA':
            cal2 = 'FullHD'
            cals = cal2
            if cal1 == 'MicroHD':
                cals = cal2 + ', ' + cal1
        if cal3 != 'NA':
            cal3 = '3D'
            cals = cal3
            if cal2 == 'FullHD':
                cals = cal3 + ', ' + cal2
            if cal1 == 'MicroHD':
                cals = cals + ', ' + cal1
        if cal4 != 'NA':
            cal4 = '4K'
            cals = cal4
            if cal3 == '3D':
                cals = cal4 + ', ' + cal3
            if cal2 == 'FullHD':
                cals = cals + ', ' + cal2
            if cal1 == 'MicroHD':
                cals = cals + ', ' + cal1

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        
        if 'LA CENICIENTA. TRILOGIA' in tit:
            year = 'VARIOS'

        if alea == "LA":
            item.alea = "LA"
            if 'MARVEL' in tit or 'STAR WARS' in tit:
                title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                        tit else title.split(' -')[1].strip()
            if 'DEADPOOL' in tit and ':' in tit:
                title = title.split(': ')[1].strip()
            if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                title = title.split(': ')[1].strip()

        itemlist.append(item.clone(
            title=title,
            title2=title if not '¿' in tit else '00000000' + title,
            contentTitle=title,
            contentType='movie',
            lab=tit,
            thumbnail=poster,
            fanart=fanart,
            languages='Esp',
            infoLabels={'year': year, 'plot': plot},
            qualities=cals,
            action='findvideos'
        ))

    tmdb.set_infoLabels(itemlist)

    if num_matches > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='movies',
            text_color='coral'
        ))

    return random.sample(itemlist, k = 10) if item.alea == "LA" else sorted(itemlist, key=lambda i: i.title2) 


def normalizar(t):

    t = re.sub(r"0N", "ON", t)
    t = re.sub(r" PANTER", " PANTHER", t)

    if t == 'BABY':
        t = 'BABY (DEL TEMOR AL AMOR)'
    elif t == 'DESTINO FATAL II':
        t = 'DESTINO FINAL II'
    elif t == 'DESTINO FINAL V':
        t = 'DESTINO FINAL V (5)'
    elif t == 'ERASE UNA VEZ DEADPOOL':
        t = 'ÉRASE UNA VEZ UN DEADPOOL'
    elif t == 'WONDER':
        t = 'WONDER (EXTRAORDINARIO)'
    
    if "(SD)" in t or "( sd)" in t or "( sd )" in t or "( 1994 )" in t:
        t = re.sub(r"\(SD\)|\( sd\)|\( sd \)|\( 1994 \)", "", t)

    t = t.strip()

    t = bytes.decode(t.lower())

    return ''.join((c for c in unicodedata.normalize('NFD', t.title()) if unicodedata.category(c) != 'Mn'))


def year_saga_search(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    url = host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0

    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        tit2 = normalizar(tit)
        item.query = normalizar(item.query)

        if 'PROMETHEUS' in tit:
            cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'

        elif 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        
        if 'MEN IN BLACK' in tit or 'CICLO CLINT EASTWOOD' in tit or 'CLASICOS DE DISNEY' in tit \
            or 'CHARLOT' in tit or 'DEADPOOL' in tit or 'LA CENICIENTA. TRILOGIA' in tit \
            or 'WONDER WOMAN' in tit or 'TRANSFORMERS' in tit or 'EL REY LEON' in tit:
            genre = genre + ' Saga'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'

        if cal1 != 'NA':
            cal1 = 'MicroHD'
            cals = cal1
        if cal2 != 'NA':
            cal2 = 'FullHD'
            cals = cal2
            if cal1 == 'MicroHD':
                cals = cal2 + ', ' + cal1
        if cal3 != 'NA':
            cal3 = '3D'
            cals = cal3
            if cal2 == 'FullHD':
                cals = cal3 + ', ' + cal2
            if cal1 == 'MicroHD':
                cals = cals + ', ' + cal1
        if cal4 != 'NA':
            cal4 = '4K'
            cals = cal4
            if cal3 == '3D':
                cals = cal4 + ', ' + cal3
            if cal2 == 'FullHD':
                cals = cals + ', ' + cal2
            if cal1 == 'MicroHD':
                cals = cals + ', ' + cal1

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'

        if item.lab == 's':
            if 'Saga' in genre:
                item.query = re.sub(r"\s", "", item.query)
                tit2 = re.sub(r"\s", "", tit2)
                if item.query.lower() in tit2.lower():
                    ilist += 1
                    if  desde < ilist <= hasta:
                        if 'MARVEL' in tit or 'STAR WARS' in tit:
                            y = None
                        elif 'CLASICOS DE DISNEY' in tit:
                            y = tit
                        else:
                            y = year.upper()

                        itemlist.append(item.clone(
                            title=title,
                            type='movie',
                            contentTitle=title,
                            contentType='movie',
                            lab=tit,
                            y=y,
                            thumbnail=poster,
                            fanart=fanart,
                            languages='Esp',
                            infoLabels={'year': year, 'plot': plot},
                            qualities=cals,
                            action='findvideos'
                        ))

        elif item.lab == 'y':
            if item.query.upper() == year.upper():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        title2=title if not '¿' in tit else '00000000' + title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

        else:
            if item.query.lower() in title.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            y='Zzzzzzzzzzzz',
            page=next_page,
            action='year_saga_search',
            text_color='coral'
        ))

    if item.lab == 's':
        return sorted(itemlist, key=lambda i: i.y)
    elif item.lab == 'y':
        return sorted(itemlist, key=lambda i: i.title2)
    else:
        return itemlist


def search(item, query):
    logger.info()
    
    try:
        item.query = query
        return year_saga_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def selection(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    if item.title == 'Cine destacado':
        item.com = 'Estreno'
    elif item.title == 'Cine de culto':
        item.com = 'Culto'
    elif item.title == 'Últimas añadidas':
        item.com = 'last'
    
    url = host_last if item.title == 'Últimas añadidas' else host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, extra, plot in matches:
        if extra == item.com or item.com == 'last':
            ilist += 1
            if  desde < ilist <= hasta:
                title = normalizar(tit)

                if 'PROMETHEUS' in tit:
                    cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'

                if 'MARVEL' in tit or 'STAR WARS' in tit:
                    title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
                elif 'DEADPOOL' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()
                elif 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()

                if cal1 != 'NA':
                    cal1 = 'MicroHD'
                    cals = cal1
                if cal2 != 'NA':
                    cal2 = 'FullHD'
                    cals = cal2
                    if cal1 == 'MicroHD':
                        cals = cal2 + ', ' + cal1
                if cal3 != 'NA':
                    cal3 = '3D'
                    cals = cal3
                    if cal2 == 'FullHD':
                        cals = cal3 + ', ' + cal2
                    if cal1 == 'MicroHD':
                        cals = cals + ', ' + cal1
                if cal4 != 'NA':
                    cal4 = '4K'
                    cals = cal4
                    if cal3 == '3D':
                        cals = cal4 + ', ' + cal3
                    if cal2 == 'FullHD':
                        cals = cals + ', ' + cal2
                    if cal1 == 'MicroHD':
                        cals = cals + ', ' + cal1

                itemlist.append(item.clone(
                    title=title,
                    title2=title,
                    type='movie',
                    contentTitle=title,
                    contentType='movie',
                    lab=tit,
                    last='last' if item.title == 'Últimas añadidas' else 'NO',
                    thumbnail=poster,
                    fanart=fanart,
                    languages='Esp',
                    infoLabels={'year': year, 'plot': plot},
                    qualities=cals,
                    action='findvideos'
                ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='selection',
            text_color='coral'
        ))

    return sorted(itemlist, key=lambda i: i.title2)


def sagas(item):
    logger.info()
    itemlist = []

    sagas = ['ALIEN', 'BATMAN', 'BOURNE', 'CHARLOT', 'CICLO CLINT EASTWOOD', 'CINCUENTA SOMBRAS',
             'CLASICOS DE DISNEY', 'CUBE', 'DEADPOOL', 'DESTINO FINAL', 'DIVERGENTE',
             'EL CORREDOR DEL LABERINTO', 'EL PADRINO', 'EL PLANETA DE LOS SIMIOS', 'EL REY LEON',
             'EL SEÑOR DE LOS ANILLOS', 'EXPEDIENTE WARREN', 'FAST AND FURIOUS', 'FELIZ DIA DE TU MUERTE',
             'HARRY POTTER', 'ICE AGE', 'INSIDIOUS', 'JACK REACHER', 'JAMES BOND', 'JOHN WICK',
             'JURASSIC PARK', 'LA JUNGLA DE CRISTAL', 'LA NOCHE DE LAS BESTIAS', 'LA PROFECIA', 'LOS CROODS',
             'LOS MERCENARIOS', 'MAD MAX', 'MALEFICA', 'MARVEL', 'MATRIX', 'MEN IN BLACK',
             'MISION IMPOSIBLE', 'OBJETIVO', 'PACIFIC RIM', 'PADRE NO HAY MAS QUE UNO', 'PERDIENDO...',
             'PIRATAS DEL CARIBE', 'PSICOSIS', 'RAMBO', 'REGRESO AL FUTURO', 'RESIDENT EVIL', 'RIDDICK',
             'SHERLOCK HOLMES', 'SHREK', 'STAR TREK', 'STAR WARS', 'TERMINATOR', 'TRANSFORMERS',
             'TRILOGIA DEL BAZTAN', 'WONDER WOMAN', 'X-MEN', 'ZOMBIELAND']

    for s in sagas:
        r = s
        r = re.sub(r"\.\.\.", "", r)
        
        itemlist.append(item.clone(
            title=s,
            label=s,
            query=r,
            lab='s',
            action='year_saga_search'
        ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []
    aux = set()

    url = host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<date>([^<]+)</'

    for year in scrapertools.find_multiple_matches(data, patron):
        year = year.upper()
        if year == '1019':
            year = '1917'
        elif year == '1950 - 2007':
            year = 'VARIOS'
        
        if not year in aux:
            aux.add(year)
            itemlist.append(item.clone(
                label=year,
                title=year,
                query=year,
                lab='y',
                action='year_saga_search'
            ))

    return sorted(itemlist, key=lambda i: i.label, reverse=True)


def findvideos(item):
    logger.info()
    itemlist = []

    url = host if not item.last else host_last
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)
    item.lab =re.sub(r"\(|\)", "", item.lab)

    patron = r'<item.*?<title>%s</.*?tle>(.*?)<thumb' % item.lab

    cal = scrapertools.find_single_match(data, patron)

    matches = re.compile(r'<([^<]+)>([^<]+)</', re.DOTALL).findall(cal)
    
    for calidad, url in matches:
        if calidad == 'microhd' and 'Prometheus' in item.title:
            url = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'
        
        if url != 'NA':
            if calidad == 'microhd':
                calidad = 'MicroHD'
                level = 4
            elif calidad == 'fullhd':
                calidad = 'FullHD'
                level = 3
            elif calidad == 'tresd':
                calidad = '3D'
                level = 2
            elif calidad == 'cuatrok':
                calidad = '4K'
                level = 1
            
            if 'CLASICOS DE DISNEY' in item.lab or 'EL REY LEON 2' in item.lab or 'EL REY LEON 3' in item.lab:
                cal = 'SD'
                level = 5
            else:
                cal = calidad
            
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + url,
                title='',
                level=level,
                quality=cal,
                language='Esp',
                type='server',
                server='torrent'
            ))

    return sorted(itemlist, key=lambda i: i.level)

