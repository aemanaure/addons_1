from six.moves import urllib_request


def get_service(service, *args, **kwargs):
    klass = __import__('webproxy.services.%s' % service, fromlist=['services.%s' % service]).HTTPConnection
    return WebProxyHTTPHandler(klass, *args, **kwargs), WebProxyHTTPHandler(klass, *args, **kwargs)


class WebProxyHTTPHandler(urllib_request.HTTPHandler):
    handler_order = 100

    def __init__(self, service, *args, **kwargs):
        urllib_request.HTTPHandler.__init__(self, *args, **kwargs)
        self.service = service

    def http_open(self, req):
        return self.do_open(self.service, req, proto='http')


class WebProxyHTTPSHandler(urllib_request.HTTPSHandler):
    handler_order = 100

    def __init__(self, service, *args, **kwargs):
        urllib_request.HTTPSHandler.__init__(self, *args, **kwargs)
        self.service = service

    def https_open(self, req):
        return self.do_open(self.service, req, proto='https')
