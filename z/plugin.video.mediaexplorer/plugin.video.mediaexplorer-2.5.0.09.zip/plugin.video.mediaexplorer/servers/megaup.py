# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    yield ResolveProgress(40, 0)
    data = httptools.downloadpage(item.url).data

    """if "The video has been removed" in data:
        yield ResolveError(0)
        return"""

    sec = scrapertools.find_single_match(data, r'var seconds =\s(\d)+')
    url = scrapertools.find_single_match(data, r"<a class='btn btn-default' href='([^']+)")

    if sec:
        sec =int(sec)
        while sec != 0:
            yield ResolveProgress(60, 'Esperando %s segundos..' % sec)
            time.sleep(1)
            sec -= 1

    yield ResolveProgress(80, 1)
    headers = httptools.downloadpage(url, follow_redirects=False).headers
    if headers.get('location'):
        itemlist.append(Video(url=headers.get('location')))

    yield itemlist
