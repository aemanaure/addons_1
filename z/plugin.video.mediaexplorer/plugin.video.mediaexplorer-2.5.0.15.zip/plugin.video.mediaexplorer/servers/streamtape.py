# -*- coding: utf-8 -*-
from core.libs import *

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "Video not found!" in data or '<title>Streamtape - Error' in data:
        return ResolveError(0)

    url = scrapertools.find_single_match(data, r'<script>document.getElementById\([^)]+\).innerHTML = ([^;]+);</script>')
    url = url.replace('"', '').replace('+', '').replace(' ', '').replace("'", '') + '&stream=1'
    if url.startswith('//'): url = 'https:' + url
    url = httptools.downloadpage(url, follow_redirects=False).headers['location']

    itemlist.append(Video(url=url))

    return itemlist
