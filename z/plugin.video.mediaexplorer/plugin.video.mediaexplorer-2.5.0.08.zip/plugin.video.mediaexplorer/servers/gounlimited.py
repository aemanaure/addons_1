# -*- coding: utf-8 -*-
from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url,headers=item.headers).data

    if 'Video is processing now.' in data:
        return ResolveError(1)

    unpacked = js2py.eval_js(scrapertools.find_single_match(data, "<script type=.text/javascript.>eval(.*?)</script>"))

    for url, type, res in scrapertools.find_multiple_matches(unpacked, 'src:"([^"]+)",type:"([^"]+)",res:(\d+)'):
        itemlist.append(Video(url=url, type=type, res=res))

    return itemlist
