# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    
    if "File Not Found" in data:
        return ResolveError(0)
       
    packed = scrapertools.find_single_match(data, r'(eval\(function\(p,a,c,k,e,d\).*?)</script>')
    unpacked = jsbeautifier.beautify(packed)

    sources = jsontools.load_js(scrapertools.find_single_match(unpacked, r'sources: (\[.*?])'))
    tracks = scrapertools.find_single_match(unpacked, r'tracks: (\[.*?])')

    if tracks:
        tracks = jsontools.load_js(tracks)
        subs = [t['file'] for t in tracks]
    else:
        subs = None

    for source in sources:
        itemlist.append(Video(url=source['file'], subtitle=subs))

    return itemlist
