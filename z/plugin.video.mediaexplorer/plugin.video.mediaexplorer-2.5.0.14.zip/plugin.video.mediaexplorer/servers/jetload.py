# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    video_id = scrapertools.find_single_match(item.url, '/e/([0-9a-zA-Z]+)')
    token = platformtools.show_recaptcha(item.url, '6Lc90MkUAAAAAOrqIJqt4iXY_fkXb7j3zwgRGtUI', 'secure_url')

    response = httptools.downloadpage(
        "https://jetload.net/jet_secure",
        post=jsontools.dump_json({
            'stream_code': video_id,
            'token': token
        }),
        headers={
            'Content-Type': 'application/json;charset=utf-8',
            'Origin': 'https://jetload.net'
        },
        timeout=10
    )

    source = jsontools.load_json(response.data)
    if 'err' in source:
        return ResolveError(0)

    itemlist.append(Video(url=source['src']['src']))

    return itemlist
