# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "404 File not found!" in data:
        return ResolveError(0)

    sources = jsontools.load_js(scrapertools.find_single_match(data, r'sources: (\[.*?\])'))
    for source in sources:
        itemlist.append(Video(url=source['file'], res=source.get('label', '')))

    return itemlist
