# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier


def get_video_url(item):
    logger.trace()
    itemlist = list()

    response = httptools.downloadpage(item.url)

    # ddos-guard bypass
    if 'DDOS-GUARD' in response.data:
        # Obtenemos el token recaptcha
        token = platformtools.show_recaptcha(
            siteurl=item.url,
            sitekey=scrapertools.find_single_match(response.data, r'data-sitekey="([^"]+)">'),
            silent=True
        )

        # Obtenemos las cookie
        cookie = response.cookies.get('__ddg3')

        # Validamos
        httptools.downloadpage('https://upstream.to/.well-known/ddos-guard/rc?ddg3=%s&id=%s' % (cookie, token))

        # Recargamos la pagina
        response = httptools.downloadpage(item.url)

    data = response.data
    if 'Video is processing now.' in data:
        return ResolveError(1)

    packed = scrapertools.find_single_match(data, r"<script type='text/javascript'>(eval.*?)</script>")
    unpacked = jsbeautifier.beautify(packed)

    url = scrapertools.find_single_match(unpacked, 'file: "([^"]+)"')
    itemlist.append(Video(url=url, headers={
        'Referer': item.url
    }))

    return itemlist
