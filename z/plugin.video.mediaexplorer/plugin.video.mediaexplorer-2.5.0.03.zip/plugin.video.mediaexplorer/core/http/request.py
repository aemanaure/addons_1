# -*- coding: utf-8 -*-
from six.moves import urllib_request


class Request(urllib_request.Request):
    """
    Ampliación de Request que permite especificar el metódo a usar: GET, POST, UPDATE, etc...
    """
    def __init__(self, *args, **kwargs):
        if 'method' in kwargs:
            if kwargs.get('method'):
                self.method = kwargs.pop('method')
            else:
                kwargs.pop('method')

        urllib_request.Request.__init__(self, *args, **kwargs)

    def get_method(self):
        default_method = "POST" if self.data is not None else "GET"
        return getattr(self, 'method', default_method)