# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if 'Video not found' in data:
        yield ResolveError(0)
        return

    video_id = scrapertools.find_single_match(item.url, '/([^/]+)$')

    api_data = jsontools.load_json(httptools.downloadpage(
        "https://vev.io/api/serve/video/" + video_id,
        post={
            'g-recaptcha-verify': platformtools.show_recaptcha(
                'https://vev.io/' + video_id,
                '6Ld6RqIUAAAAAKjcjfIgh2TmF_HmAc5hvrQx_D9a',
                'serve',
                silent=True
            )
        }
    ).data)

    videos = api_data.get('qualities', [])
    if videos:
        for video in videos:
            itemlist.append(Video(url=video['src'], res='%sp' % video['size'][1]))

    elif api_data.get('code') == 400:
        yield ResolveError(0)
        return
    elif api_data.get('deleted'):
        yield ResolveError(0)
        return
    else:
        logger.debug(api_data)

    yield itemlist
