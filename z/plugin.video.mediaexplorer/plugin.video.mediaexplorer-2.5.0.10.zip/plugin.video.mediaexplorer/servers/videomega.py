# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    tnaketalikom = scrapertools.find_single_match(data, r'var tnaketalikom=document.getElementById\("([^"]+)"')
    bigbangass = scrapertools.find_single_match(data, r'bigbangass=document.getElementById\("([^"]+)')
    fuckoff = scrapertools.find_single_match(data, r'fuckoff=document.getElementById\("([^"]+)')

    tnaketalikom = scrapertools.find_single_match(data, r'<link href="([^"]+)" id="%s"' % tnaketalikom)
    bigbangass = scrapertools.find_single_match(data, r'<link href="([^"]+)" id="%s"' % bigbangass)
    fuckoff = scrapertools.find_single_match(data, r'<link href="([^"]+)" id="%s"' % fuckoff)

    url = httptools.downloadpage("https://www.videomega.co/streamurl/%s/" % bigbangass,
                                 post={'myreason': tnaketalikom, 'saveme': fuckoff}).data.strip()
    #logger.debug(url)

    data = httptools.downloadpage(url).data
    video_url = scrapertools.find_single_match(data, '<source src="([^"]+)" type=\'video/mp4\'/>')
    if video_url:
        itemlist.append(Video(url=video_url))

    return itemlist
