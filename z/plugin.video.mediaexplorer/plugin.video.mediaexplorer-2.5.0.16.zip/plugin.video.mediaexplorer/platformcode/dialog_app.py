# -*- coding: utf-8 -*-
from core.libs import *
import xbmcgui
from distutils.version import LooseVersion


class DialogAPP(xbmcgui.WindowXMLDialog):
    def __new__(cls, *args, **kwargs):
        def create():
            cls.instance = xbmcgui.WindowXMLDialog.__new__(cls, *args, **kwargs)
            cls.instance.doModal()

        t = Thread(target=create)
        t.setDaemon(True)
        t.start()
        platformtools.DialogProgress.hideall()
        while not hasattr(cls, 'instance'):
            time.sleep(0.2)

        return cls.instance

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        self.canceled = False
        self.retry = False
        self.change = False
        self.is_retry_enabled = False

    def close(self):
        platformtools.DialogProgress.showall()
        xbmcgui.WindowXMLDialog.close(self)

    def onInit(self):
        if LooseVersion(xbmcgui.__version__) <= LooseVersion('2.2.5'):
            self.setCoordinateResolution(5)

        # Fijamos el título
        self.getControl(10004).setLabel("APP MediaExplorer Tools")
        self.hide_retry()
        self.setFocusId(10008)

    def change_state(self, message):
        self.getControl(10005).setLabel(message)

    def show_retry(self):
        self.getControl(10007).setEnabled(True)
        self.is_retry_enabled = True

    def hide_retry(self):
        self.is_retry_enabled = False
        self.getControl(10007).setEnabled(False)
        if self.getFocusId() == 10007:
            self.setFocusId(10008)

    def show_qr(self, path):
        self.change_size(500, 490 + 180)
        self.getControl(10009).setImage(path)
        self.getControl(10009).setVisible(True)

    def hide_qr(self):
        self.getControl(10009).setVisible(False)
        self.change_size(500, 180)

    def set_qr_button(self, message):
        self.getControl(10006).setLabel(message)

    def change_size(self, width, height):
        self.getControl(10001).setWidth(width)
        self.getControl(10001).setHeight(height)
        self.getControl(10001).setPosition(int((1280 - width) / 2), int((720 - height) / 2))

        # Fondo
        self.getControl(10002).setWidth(width)
        self.getControl(10002).setHeight(height)

        # Heading
        self.getControl(10003).setWidth(width)
        self.getControl(10004).setWidth(width)

        pos_y = height - 45
        buttons = 3
        buttons_with = 500
        for x in range(buttons):
            pos_x = int(((buttons_with - (140 * buttons)) / (buttons + 1)) * (x + 1) + (140 * x))
            self.getControl(10006 + x).setPosition(pos_x, pos_y)

    def onClick(self, control):
        logger.trace()
        if control == 10006:
            self.change = True

        if control == 10007:
            self.retry = True

        if control == 10008:
            self.canceled = True
            self.close()

    def onAction(self, raw_action):
        xbmcgui.WindowXMLDialog.onAction(self, raw_action)
        if raw_action.getId() in [10, 92]:
            self.canceled = True
            self.close()

        # Accion 1: Flecha izquierda
        elif raw_action.getId() == 1:
            if self.getFocusId() == 10008 and self.is_retry_enabled:
                self.setFocusId(10007)
            else:
                self.setFocusId(10006)
        # Accion 1: Flecha derecha
        elif raw_action.getId() == 2:
            if self.getFocusId() == 10006 and self.is_retry_enabled:
                self.setFocusId(10007)
            else:
                self.setFocusId(10008)
