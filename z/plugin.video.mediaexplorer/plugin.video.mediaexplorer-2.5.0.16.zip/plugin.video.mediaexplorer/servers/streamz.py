# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    # Seguimos las redirecciones hasta la ultima
    item.url = httptools.downloadpage(item.url).url

    file_id = item.url.split("/")[-1][1:]

    # Habilitamos la IP
    httptools.downloadpage('https://streamz.vg/count.php?def=1')

    # Obtenemos la url
    url = httptools.downloadpage(
        urllib_parse.urljoin(item.url, '/getlink-%s.dll' % file_id),
        follow_redirects=False
    ).headers['location']

    itemlist.append(Video(url=url))

    return itemlist
