# -*- coding: utf-8 -*-
import socket
import ssl
from distutils.version import LooseVersion

from six.moves import http_client, urllib_request

from core.http.dns import Resolve
from core.libs import *

cipher_suite = [
    'ECDHE-ECDSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-CHACHA20-POLY1305',
    'ECDHE-RSA-CHACHA20-POLY1305',
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-AES256-SHA',
    'ECDHE-ECDSA-AES128-SHA',
    'ECDHE-RSA-AES256-SHA',
    'ECDH-ECDSA-AES128-GCM-SHA256',
    'ECDH-ECDSA-AES128-SHA',
    'ECDH-ECDSA-AES128-SHA256',
    'ECDH-ECDSA-AES256-GCM-SHA384',
    'ECDH-ECDSA-AES256-SHA',
    'ECDH-ECDSA-AES256-SHA384',
    'ECDH-ECDSA-DES-CBC3-SHA',
    'ECDH-ECDSA-RC4-SHA',
    'ECDH-RSA-AES128-GCM-SHA256',
    'ECDH-RSA-AES128-SHA',
    'ECDH-RSA-AES128-SHA256',
    'ECDH-RSA-AES256-GCM-SHA384',
    'ECDH-RSA-AES256-SHA',
    'ECDH-RSA-AES256-SHA384',
    'ECDH-RSA-DES-CBC3-SHA',
    'ECDH-RSA-RC4-SHA',
    'DES-CBC3-SHA',
    'DHE-DSS-AES128-GCM-SHA256',
    'DHE-DSS-AES128-SHA',
    'DHE-DSS-AES128-SHA256',
    'DHE-DSS-AES256-GCM-SHA384',
    'DHE-DSS-AES256-SHA',
    'DHE-DSS-AES256-SHA256',
    'DHE-DSS-CAMELLIA128-SHA',
    'DHE-DSS-CAMELLIA256-SHA',
    'DHE-DSS-SEED-SHA',
    'DHE-RSA-AES128-GCM-SHA256',
    'DHE-RSA-AES128-SHA256',
    'DHE-RSA-AES256-GCM-SHA384',
    'DHE-RSA-AES256-SHA256',
    'DHE-RSA-AES128-SHA',
    'DHE-RSA-AES256-SHA',
]


class HTTPSHandler(urllib_request.HTTPSHandler):
    """
    Clase HTTPSHandler modificada para poder modificar el protoclo TLS para que cloudflare no se queje
    """

    def https_open(self, req):
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.set_ciphers(':'.join(cipher_suite))

        if six.PY3 and LooseVersion('.'.join(str(a) for a in ssl.OPENSSL_VERSION_INFO[:3])) < LooseVersion('1.1.1'):
            context.set_alpn_protocols(['http/1.1'])
        context.options |= (ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1)

        return self.do_open(HTTPSConnection, req, context=context)


class HTTPSConnection(http_client.HTTPSConnection):
    """
    Clase HTTPSConnection modificada para permitir resolver las url mediante otro servidor DNS
    """

    def connect(self):
        if settings.get_setting('dns_mode', __file__):
            host = Resolve(self.host)
        else:
            host = self.host

        if isinstance(host, six.string_types):
            self.sock = socket.create_connection((host, self.port), self.timeout, self.source_address)
        else:
            for h in host:
                try:
                    self.sock = socket.create_connection((h, self.port), self.timeout, self.source_address)
                except Exception:
                    if host.index(h) == len(host) - 1:
                        raise
                else:
                    break

        if self._tunnel_host:
            server_hostname = self._tunnel_host
            if settings.get_setting('dns_proxy', __file__):  # Resolver DNS Local
                tunnel_host = Resolve(self._tunnel_host)
                if not isinstance(tunnel_host, six.string_types):
                    tunnel_host = tunnel_host[0]
                self._tunnel_host = tunnel_host
            self._tunnel()
        else:
            server_hostname = self.host

        self.sock = self._context.wrap_socket(self.sock, server_hostname=server_hostname)
