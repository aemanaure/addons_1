# -*- coding: utf-8 -*-
from .. import BaseSolver
from core.libs import *


class CaptchaSolver(BaseSolver):
    base_url = 'https://api.anti-captcha.com'

    def __init__(self, *args, **kwargs):
        BaseSolver.__init__(self, *args, **kwargs)
        self.api_key = settings.get_setting('api_key', __file__)
        self.task_id = None

    def is_enabled(self):
        if not settings.get_setting('enabled', __file__):
            return False

        if not self.api_key:
            return False

        if not self.get_balance():
            return False

        return True

    def get_balance(self):
        try:
            return self._api_request('/getBalance')['balance']
        except Exception:
            return 0.0

    def _api_request(self, url, post=None):
        if post is None:
            post = {}

        post['clientKey'] = self.api_key
        response = httptools.downloadpage(self.base_url + url, post=jsontools.dump_json(post))

        if response.sucess:
            data = jsontools.load_json(response.data)
            if data.get('errorId'):
                raise Exception(data['errorDescription'])
            return data
        else:
            raise Exception('Error al conectar con la api, error code: %s' % response.code)

    def solve_v3(self, site_url, site_key, action, min_score):
        self.estimated_time = self._api_request(
            '/getQueueStats',
            post={
                'queueId': 18
            }
        )['speed']

        self.task_id = self._api_request(
            '/createTask',
            post={
                'task': {
                    'type': 'RecaptchaV3TaskProxyless',
                    'websiteURL': site_url,
                    'websiteKey': site_key,
                    'minScore': min_score or '0.3',
                    'pageAction': action
                }
            }
        )['taskId']

    def solve_v2(self, site_url, site_key):
        self.estimated_time = self._api_request(
            '/getQueueStats',
            post={
                'queueId': 6
            }
        )['speed']

        self.task_id = self._api_request(
            '/createTask',
            post={
                'task': {
                    'type': 'NoCaptchaTaskProxyless',
                    'websiteURL': site_url,
                    'websiteKey': site_key
                }
            }
        )['taskId']

    def get_response(self):
        data = self._api_request(
            '/getTaskResult',
            post={
                'taskId': self.task_id
            }
        )
        if not data.get('solution'):
            for x in range(3):
                if self.canceled:
                    return
                time.sleep(1)
            if self.canceled:
                return
            self.get_response()
        else:
            self.result = data['solution']['gRecaptchaResponse']
