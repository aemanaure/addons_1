# -*- coding: utf-8 -*-
from core.libs import *
from jsbeautifier import beautify


def get_video_url(item):
    logger.trace()

    itemlist = list()

    data = httptools.downloadpage(item.url).data
    packed = scrapertools.find_single_match(
        data,
        r"<script type='text/javascript'>(eval\(function\(p,a,c,k,e,d\).*?)</script>"
    )

    sources = eval(scrapertools.find_single_match(beautify(packed), r'sources: (\[.*?\])'))
    for url in sources:
        itemlist.append(Video(url=url.strip()))

    return itemlist
