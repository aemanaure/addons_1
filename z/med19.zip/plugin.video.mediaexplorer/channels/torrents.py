# -*- coding: utf-8 -*-
from core.libs import *
import unicodedata
import random

LNG = Languages({
    Languages.es: ['es']
})

QLT = Qualities({
    Qualities.sd: ['sd'],
    Qualities.hd_full: ['microhd', 'fullhd'],
    Qualities.m3d: ['tresd'],
    Qualities.uhd: ['cuatrok']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Cine destacado",
        action="selection",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Cine de culto",
        action="selection",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Sagas",
        action="sagas",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Listado por años",
        action="years",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Listado alfabético",
        action="movies",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Selección aleatoria",
        action="movies",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()

    alea = "LA" if item.label == "Selección aleatoria" else "NO"
    
    url = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, 
        patron):
        
        title = normalizar(tit)

        if 'PROMETHEUS' in tit:
            cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'

        cals = set()
        
        if cal1 != 'NA':
                cals.add(QLT.get('microhd'))
        if cal2 != 'NA':
                cals.add(QLT.get('fullhd'))
        if cal3 != 'NA':
                cals.add(QLT.get('tresd'))
        if cal4 != 'NA':
                cals.add(QLT.get('cuatrok'))

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals.remove(QLT.get('fullhd'))
            cals.add(QLT.get('sd'))

        if 'PRIMER VENGADOR' in tit:
            year = '2011'
        if year == '1019':
            year = '1917'
        
        if 'LA CENICIENTA. TRILOGIA' in tit:
            year = 'VARIOS'
        
        if alea == "LA":
            item.alea = "LA"
            if 'MARVEL' in tit or 'STAR WARS' in tit:
                title = title.split('- ')[1].strip() if 'MARVEL' in tit else title.split(' -')[1].strip()
            if 'DEADPOOL' in tit and ':' in tit:
                title = title.split(': ')[1].strip()
            if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                title = title.split(': ')[1].strip()

        itemlist.append(item.clone(
            title=title,
            type='movie',
            lab=tit,
            poster=poster,
            fanart=fanart,
            plot=plot,
            lang=LNG.get('es'),
            year=year.upper(),
            action='findvideos',
            quality=sorted(list(cals), key=lambda i: i.level, reverse=True)
        ))

    return random.sample(itemlist, k = 10) if item.alea == "LA" else sorted(itemlist, key=lambda i: i.title)


def normalizar(t):

    t = re.sub(r"0N", "ON", t)
    t = re.sub(r" PANTER", " PANTHER", t)

    if t == 'BABY':
        t = 'BABY (DEL TEMOR AL AMOR)'
    elif t == 'DESTINO FATAL II':
        t = 'DESTINO FINAL 2'
    
    if "(SD)" in t or "( sd)" in t or "( sd )" in t or "( 1994 )" in t:
        t = re.sub(r"\(SD\)|\( sd\)|\( sd \)|\( 1994 \)", "", t)

    t = t.strip() #.capitalize()
    #t = re.sub(r"Ñ", "ñ", t)

    #return t
    t = six.ensure_text(t.lower())

    return ''.join((c for c in unicodedata.normalize('NFD', t.title()) if unicodedata.category(c) != 'Mn'))


@LimitResults
def search(item):
    logger.trace()
    itemlist = list()

    url = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, genre, plot in scrapertools.find_multiple_matches(
        data, patron):

        title = normalizar(tit)

        if 'PROMETHEUS' in tit:
            cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in tit else title.split(' -')[1].strip()
        if 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        
        tit2 = normalizar(tit)
        item.query = normalizar(item.query)
        
        if 'LA CENICIENTA. TRILOGIA' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        
        cals = set()

        if 'MEN IN BLACK' in tit or 'CICLO CLINT EASTWOOD' in tit or 'CLASICOS DE DISNEY' in tit \
            or 'CHARLOT' in tit or 'DEADPOOL' in tit or 'LA CENICIENTA. TRILOGIA' in tit \
            or 'WONDER WOMAN' in tit or 'TRANSFORMERS' in tit or 'EL REY LEON' in tit:
            genre = genre + ' Saga'
        if 'PRIMER VENGADOR' in tit:
            year = '2011'
        if year == '1019':
            year = '1917'

        if cal1 != 'NA':
            cals.add(QLT.get('microhd'))
        if cal2 != 'NA':
            cals.add(QLT.get('fullhd'))
        if cal3 != 'NA':
            cals.add(QLT.get('tresd'))
        if cal4 != 'NA':
            cals.add(QLT.get('cuatrok'))
        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals.remove(QLT.get('fullhd'))
            cals.add(QLT.get('sd'))

        if item.lab == 's':
            if 'Saga' in genre:
                item.query = re.sub(r"\s", "", item.query)
                tit2 = re.sub(r"\s", "", tit2)
                if item.query.lower() in tit2.lower():
                    if 'MARVEL' in tit or 'STAR WARS' in tit:
                        y = None
                    elif 'CLASICOS DE DISNEY' in tit:
                        y = tit
                    else:
                        y = year.upper()

                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        lab=tit,
                        y=y,
                        poster=poster,
                        fanart=fanart,
                        plot=plot,
                        lang=LNG.get('es'),
                        year=year.upper(),
                        action='findvideos',
                        quality=sorted(list(cals), key=lambda i: i.level, reverse=True)
                    ))

        elif item.lab == 'y':
            if item.query.upper() == year.upper():
                itemlist.append(item.clone(
                    title=title,
                    type='movie',
                    lab=tit,
                    poster=poster,
                    fanart=fanart,
                    plot=plot,
                    lang=LNG.get('es'),
                    year=year.upper(),
                    action='findvideos',
                    quality=sorted(list(cals), key=lambda i: i.level, reverse=True)
                ))

        else:
            if item.query.lower() in title.lower():
                itemlist.append(item.clone(
                    title=title,
                    type='movie',
                    lab=tit,
                    poster=poster,
                    fanart=fanart,
                    plot=plot,
                    lang=LNG.get('es'),
                    year=year.upper(),
                    action='findvideos',
                    quality=sorted(list(cals), key=lambda i: i.level, reverse=True)
                ))

    if item.lab == 's':
        return sorted(itemlist, key=lambda i: i.y)
    elif item.lab == 'y':
        return sorted(itemlist, key=lambda i: i.title)
    else:
        return itemlist


@LimitResults
def selection(item):
    logger.trace()
    itemlist = list()

    if item.label == 'Cine destacado':
        item.com = 'Estreno'
    elif item.label == 'Cine de culto':
        item.com = 'Culto'
    
    url = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, extra, plot in scrapertools.find_multiple_matches(
        data, patron):
        
        title = normalizar(tit)

        if 'PROMETHEUS' in tit:
            cal1 = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in tit else title.split(' -')[1].strip()
        if 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        
        cals = set()
        if cal1 != 'NA':
            cals.add(QLT.get('microhd'))
        if cal2 != 'NA':
            cals.add(QLT.get('fullhd'))
        if cal3 != 'NA':
            cals.add(QLT.get('tresd'))
        if cal4 != 'NA':
            cals.add(QLT.get('cuatrok'))
        
        if extra == item.com:
            itemlist.append(item.clone(
                title=title,
                type='movie',
                lab=tit,
                poster=poster,
                fanart=fanart,
                plot=plot,
                lang=LNG.get('es'),
                year=year.upper(),
                action='findvideos',
                quality=sorted(list(cals), key=lambda i: i.level, reverse=True)
            ))

    return sorted(itemlist, key=lambda i: i.title)


def sagas(item):
    logger.trace()
    itemlist = list()

    sagas = ['ALIEN', 'BATMAN', 'BOURNE', 'CHARLOT', 'CICLO CLINT EASTWOOD', 'CINCUENTA SOMBRAS',
             'CLASICOS DE DISNEY', 'CUBE', 'DEADPOOL', 'DESTINO FINAL', 'DIVERGENTE',
             'EL CORREDOR DEL LABERINTO', 'EL PADRINO', 'EL PLANETA DE LOS SIMIOS', 'EL REY LEON',
             'EL SEÑOR DE LOS ANILLOS', 'EXPEDIENTE WARREN', 'FAST AND FURIOUS', 'FELIZ DIA DE TU MUERTE',
             'HARRY POTTER', 'ICE AGE', 'INSIDIOUS', 'JACK REACHER', 'JAMES BOND', 'JOHN WICK',
             'JURASSIC PARK', 'LA JUNGLA DE CRISTAL', 'LA NOCHE DE LAS BESTIAS', 'LA PROFECIA', 'LOS CROODS',
             'LOS MERCENARIOS', 'MAD MAX', 'MALEFICA', 'MARVEL', 'MATRIX', 'MEN IN BLACK',
             'MISION IMPOSIBLE', 'OBJETIVO', 'PACIFIC RIM', 'PADRE NO HAY MAS QUE UNO', 'PERDIENDO...',
             'PIRATAS DEL CARIBE', 'PSICOSIS', 'RAMBO', 'REGRESO AL FUTURO', 'RESIDENT EVIL', 'RIDDICK',
             'SHERLOCK HOLMES', 'SHREK', 'STAR TREK', 'STAR WARS', 'TERMINATOR', 'TRANSFORMERS',
             'TRILOGIA DEL BAZTAN', 'WONDER WOMAN', 'X-MEN', 'ZOMBIELAND']

    for s in sagas:
        r = s
        r = re.sub(r"\.\.\.", "", r)
        
        itemlist.append(item.clone(
            label=s,
            query=r,
            lab='s',
            action='search'
        ))

    return itemlist


def years(item):
    logger.trace()
    itemlist = list()
    aux = set()

    url = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)

    for year in scrapertools.find_multiple_matches(data, r'<date>([^<]+)</'):
        year = year.upper()
        if year == '1019':
            year = '1917'
        elif year == '1950 - 2007':
            year = 'VARIOS'
        
        if not year in aux:
            aux.add(year)
            itemlist.append(item.clone(
                label=year,
                query=year,
                lab='y',
                action='search'
            ))

    return sorted(itemlist, key=lambda i: i.label, reverse=True)


def findvideos(item):
    logger.trace()
    itemlist = list()

    url = 'https://raw.githubusercontent.com/lamalanovela/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)
    item.lab =re.sub(r"\(|\)", "", item.lab)

    patron = r'<item.*?<title>%s</.*?tle>(.*?)<thumb' % item.lab

    cal = scrapertools.find_single_match(data, patron)
    
    for calidad, url in scrapertools.find_multiple_matches(cal, r'<([^<]+)>([^<]+)</'):
        if calidad == 'microhd' and 'Prometheus' in item.title:
            url = 'c5241dca7ad682371578d0cbda8ecc6a82d0dba2'
        if 'CLASICOS DE DISNEY' in item.lab:
            cal = QLT.get('sd')
        else:
            cal = QLT.get(calidad)
            
        if url != 'NA':
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + url,
                quality=cal,
                poster=item.poster,
                fanart=item.fanart,
                lang=item.lang,
                label_extra={"sublabel": " -MicroHD-",
                            "color": "yellow",
                            "value": "True"} if calidad == 'microhd' and cal != QLT.get('sd') else None,
                type='server',
                server='torrent'
            ))

    return servertools.get_servers_from_id(itemlist)

