# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://www.dospelis.online/'

LNG = Languages({
    Languages.es: ['ESPAñOL', 'CASTELLANO'],
    Languages.la: ['LATINO'],
    Languages.vos: ['SUBTITULADO', 'SUB', 'SUB ESPAñOL'],
})

QLT = Qualities({
    Qualities.rip: ['HDRIP', 'DVD RIP', 'HDTVRIP', 'HD 720PHDRIP', 'HD 1080PHDRIP'],
    Qualities.hd: ['HD 720P', 'WEB-DL 720P'],
    Qualities.sd: ['DVD RIPHD 1080P'],
    Qualities.hd_full: ['HD 1080P'],
    Qualities.scr: ['BRSCREENERHD 720P', 'SCREENER', 'TS-SCREENER']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="contents",
        label="Actualizadas",
        type="item",
        group=True,
        url=HOST + 'movies/',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="contents",
        label="Español",
        type="item",
        group=True,
        url=HOST + '/genre/castellano/',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="contents",
        label="Latino",
        type="item",
        group=True,
        url=HOST + '/genre/latino/',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        content_type='movies',
        group=True
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        type="item",
        group=True,
        url=HOST + 'episodes/',
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="contents",
        label="Nuevas series",
        type="item",
        group=True,
        url=HOST + 'tvshows/',
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        content_type='tvshows',
        group=True
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(HOST).data
    patron = '<li class="cat-item cat-item-.*?"><a href="([^"]+)"[^>]*>([^<]+)</a> <i>([^<]+)</i>'

    for url, genre, num in scrapertools.find_multiple_matches(data, patron):
        no_genre = ["Castellano", "Latino", "Destacadas", "Estrenos", "Youtube Peliculas", "Proximos estrenos"]

        if genre not in no_genre:
            itemlist.append(item.clone(
                action='contents',
                label="%s (%s)" % (genre, num),
                url=url,
                content_type='movies'
            ))

    return itemlist


def contents(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'<article id="post-\d+".*?src="([^"]+)(.*?)<div class="data">.*?href="([^"]+)">([^<]+).*?(\d{4})</span>'
    for poster, q, url, title, year in scrapertools.find_multiple_matches(data, patron):
        new_item = item.clone(
            title=title,
            url=url,
            poster=poster,
            year=year)

        if item.content_type == 'movies':
            new_item.type = 'movie'
            new_item.content_type = 'servers'
            new_item.action = 'findvideos'
            new_item.quality = QLT.get(
                scrapertools.find_single_match(q, r'<span class="quality">([^<]+)</span>').upper())

        if item.content_type == 'tvshows':
            new_item.type = 'tvshow'
            new_item.content_type = 'seasons'
            new_item.tvshowtitle = title
            new_item.action = 'seasons'

        itemlist.append(new_item)

    # Paginador
    next_url = scrapertools.find_single_match(
        data,
        r"""<div class="pagination">.*?<span class="current">\d+</span><a href='([^']+)'"""
    )
    if itemlist and next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r"<div class='se-q'><span class='[^']+'>(\d+)</span><span class='title'>([^<]+)<i>"

    for num_season, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            season=int(num_season),
            title=title,
            action="episodes",
            type='season',
            content_type='episodes'))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r"<div class='numerando'>([^<]+)</div><div class='episodiotitle'><a href='([^']+)'>([^<]+)</a>"

    for numerando, url, title in scrapertools.find_multiple_matches(data, patron):
        season, episode = scrapertools.get_season_and_episode(numerando.replace(' ', '').replace('-', 'x'))
        if item.season != season:
            continue

        itemlist.append(item.clone(
            title=title,
            action="findvideos",
            url=url,
            episode=episode,
            type='episode',
            content_type='servers'))

    return itemlist


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    for article in scrapertools.find_multiple_matches(data, r'<article class="item se episodes" [^>]+>\s*'
                                                            r'<div class="poster">(.*?)</article>'):
        thumb, season_episode = scrapertools.find_single_match(article, r'<img src="([^"]+)" alt="([^"]+)"')
        num_season, num_episode = scrapertools.get_season_and_episode(season_episode.replace('×', 'x'))
        tvshowtitle = scrapertools.find_single_match(article, r'<span class="serie">([^<]+)')

        itemlist.append(item.clone(
            tvshowtitle=tvshowtitle,
            label=tvshowtitle,
            thumb=thumb,
            url=scrapertools.find_single_match(article, '<a href="([^"]+)"'),
            action="findvideos",
            episode=num_episode,
            season=num_season,
            type='episode',
            quality=QLT.get(scrapertools.find_single_match(article, '<span class="quality">([^<]+)').upper()),
            content_type='servers'
        ))

    # Paginador
    next_url = scrapertools.find_single_match(
        data,
        r"""<div class="pagination">.*?<span class="current">\d+</span><a href='([^']+)'"""
    )
    if itemlist and next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def search(item):
    logger.trace()

    if item.content_type == 'movies':
        item.url = HOST + '?s=' + item.query.replace(" ", "+")
        return search_movies(item)
    else:
        item.url = HOST + 'page/%s/?s=' + item.query.replace(" ", "+")
        return search_tvshows(item)


def search_movies(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'<article>.*?<img src="([^"]+)".*?<span class="([^"]+)">.*?' \
             r'<a href="([^"]+)">([^<]+).*?<div class="meta">(.*?)</div>'

    for poster, type, url, title, info in scrapertools.find_multiple_matches(data, patron):
        if type == "movies":
            itemlist.append(item.clone(
                title=title,
                url=url,
                poster=poster.replace('-150x150', ''),
                year=scrapertools.find_single_match(info, r'<span class="year">(\d+)</span>'),
                type='movie',
                content_type='servers',
                action='findvideos'
            ))

    # Paginador
    next_url = scrapertools.find_single_match(
        data,
        r"""<div class="pagination">.*?<span class="current">\d+</span><a href='([^']+)'"""
    )
    if itemlist and next_url:
        itemlist.append(item.clone(url=next_url, type='next', action='result_search'))

    return itemlist


def search_tvshows(item):
    def pages(item, itemlist):
        data = httptools.downloadpage(item.url).data
        patron = r'<article>.*?<img src="([^"]+)".*?<span class="([^"]+)">.*?' \
                 r'<a href="([^"]+)">([^<]+).*?<div class="meta">(.*?)</div>'

        for poster, type, url, title, info in scrapertools.find_multiple_matches(data, patron):
            if type == "tvshows":
                itemlist.append(item.clone(
                    title=title,
                    url=url,
                    poster=poster.replace('-150x150', ''),
                    year=scrapertools.find_single_match(info, r'<span class="year">(\d+)</span>'),
                    type='tvshow',
                    content_type='seasons',
                    action='seasons'
                ))

    logger.trace()
    itemlist = list()
    threads = list()

    for i in range(1, 6):
        it = item.clone(
            page=i,
            url=item.url % i
        )

        t = Thread(target=pages, args=[it, itemlist])
        t.setDaemon(True)
        t.start()
        threads.append(t)

    while [t for t in threads if t.isAlive()]:
        time.sleep(0.5)

    return sorted(itemlist, key=lambda x: x.page)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r"<li id='player-option-\d+' class='dooplay_player_option' data-type='([^']+)' data-post='([^']+)' " \
             r"data-nume='([^']+)'>.*?<span class='title'>([^<\|]+).*?</span><span class='server'>([^<]+)"

    for data_type, data_post, data_nume, lng, server in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            data = {'action': 'doo_player_ajax',
                    'post': '%s' %data_post,
                    'nume': '%s' %data_nume,
                    'type': data_type},
            server = server.split('.')[0],
            type='server',
            action='play',
            lang=LNG.get(lng.upper())
        ))

    return servertools.get_servers_from_id(itemlist)

def play(item):
    data = httptools.downloadpage(HOST + "wp-admin/admin-ajax.php",post=item.data, add_referer=True).data
    item.url = scrapertools.find_single_match(data, r'"embed_url":"([^"]+)"').replace('\\', '')

    return servertools.normalize_url(item)