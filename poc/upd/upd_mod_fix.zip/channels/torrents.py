# -*- coding: utf-8 -*-

import re, base64

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, jsontools, filetools, downloadtools, scrapertools, tmdb
import unicodedata
import random

import filecmp
import os, time, traceback

#host = 'https://gitlab.com/stiletto1/s/-/raw/main/c'
source = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
host = scrapertools.find_single_match(source, r'<host>([^<]+)<')
try:
    actu_xml = os.path.join(config.get_runtime_path(), 'actu.xml')
    last_xml = os.path.join(config.get_runtime_path(), 'last.xml')
    las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
    
    if os.path.exists(actu_xml) == False:
        dat1 = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml', timeout=2).data
        filetools.write(actu_xml, dat1)

    if os.path.exists(last_xml) == False:
        dat2 = httptools.downloadpage(host, timeout=2).data
        filetools.write(last_xml, dat2)

    dat0 = httptools.downloadpage(host, timeout=2).data 
    filetools.write(las0_xml, dat0)
except:
    None

host_last = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/last2'

perpage = 25

def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'movie', text_color = 'yellow' ))
    itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis', text_color = 'deepskyblue' ))
    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        kudos = scrapertools.find_single_match(data, r'<kudos>([^<]+)<')
        if kudos:
            itemlist.append(item.clone( title = '[B]KUDOS: %s[/B]' % kudos, action = 'mainlist_pelis', text_color = 'coral' ))
    except:
        None

    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    '''try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        active = scrapertools.find_single_match(data, r'<active>([^<]+)<')
        if active == "0":
            itemlist.append(item.clone( title = 'Últimas añadidas', action = 'selection', search_type = 'movie' ))
    except:
        None'''

    try:
        data = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult').data
        active = scrapertools.find_single_match(data, r'<active>([^<]+)<')
        actu_xml = os.path.join(runtime_path, 'actu.xml')
        last_xml = os.path.join(runtime_path, 'las0.xml')
        if active == "0" and os.path.exists(actu_xml) == True and os.path.exists(las0_xml) == True:
            itemlist.append(item.clone( title = 'Últimas añadidas', action = 'last', search_type = 'movie' ))
    except:
        None

    #itemlist.append(item.clone( title = 'Última adición', action = 'last_added', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Cine destacado', action = 'selection', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Cine de culto', action = 'selection', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Sagas', action = 'sagas', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Géneros', action = 'generos', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Listado por años', action = 'anios', search_type = 'movie' ))
    
    #itemlist.append(item.clone( title = 'Listado alfabético', action = 'movies', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Listado alfabético', action = 'alfabeto', search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Selección aleatoria', action = 'movies', search_type = 'movie' ))

    return itemlist


def last(item):
    logger.info()
    itemlist = []
    auxlist = set()

    try:
        actu_xml = os.path.join(config.get_runtime_path(), 'actu.xml')
        last_xml = os.path.join(config.get_runtime_path(), 'last.xml')
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        
        if os.path.exists(actu_xml) == False:
            dat1 = httptools.downloadpage('https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml', timeout=2).data
            filetools.write(actu_xml, dat1)

        if os.path.exists(last_xml) == False:
            dat2 = httptools.downloadpage(host, timeout=2).data
            filetools.write(last_xml, dat2)

        if os.path.exists(las0_xml) == False:
            dat0 = httptools.downloadpage(host, timeout=2).data 
            filetools.write(las0_xml, dat0)

        diff = filecmp.cmp(las0_xml, last_xml, shallow=False)
        
        if diff == False:
            if os.path.exists(actu_xml):
                os.remove(actu_xml)
            data = open(last_xml).read()
            filetools.write(actu_xml, data)

            if os.path.exists(last_xml):
                os.remove(last_xml)
            data = open(las0_xml).read()
            filetools.write(last_xml, data)
    except:
        url = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml'
        data = httptools.downloadpage(url).data
        filetools.write(actu_xml, data)

    try:
        actu_xml = os.path.join(config.get_runtime_path(), 'actu.xml')
        dat1 = open(actu_xml).read()
    except:
        ur1 = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/actu.xml'
        dat1 = httptools.downloadpage(ur1).data

    dat1 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat1)
    patro1 = r'<title>([^<]+)</'
    
    for tit in scrapertools.find_multiple_matches(dat1, patro1):
        title = normalizar(tit)
        if not title in auxlist:
            auxlist.add(title)

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        dat2 = open(las0_xml).read()
    except:
        ur0 = 'https://gitlab.com/stiletto1/s/-/raw/main/c'
        dat2 = httptools.downloadpage(ur0).data

    dat2 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat2)
    patro2 = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

    for tit, calidades, poster, fanart, year, plot in scrapertools.find_multiple_matches(dat2, patro2):

        title = normalizar(tit)
        cals = qualities(calidades)

        if not title in auxlist:
            itemlist.append(item.clone(
                title=title,
                tit=tit,
                type='movie',
                languages='Esp',
                lab=tit,
                qualities=cals,
                thumbnail=poster,
                fanart=fanart,
                infoLabels={'year': year, 'plot': plot},
                contentTitle=title,
                contentType='movie',
                action='findvideos'
            ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


'''def last_added(item):
    logger.info()
    itemlist = []
    
    url = 'https://github.com/lamalanovela/tacones/commits/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'href="([^"]+)">Update nuevo</a>'
    commit = 'https://github.com' + scrapertools.find_single_match(data, patron)
    data = httptools.downloadpage(commit).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;|<span class=\"pl-ent\">|</span>", "", data)
    data = re.sub(r"&quot;|&#39;", "“", data)

    patron = r'marker="\+">&lt;item&gt;' \
             r'.*?marker="\+">&lt;title&gt;([^&]+)&lt;/title' \
             r'.*?marker="\+">&lt;micro(.*?)/cuatrok' \
             r'.*?marker="\+">&lt;thumbnail&gt;([^&]+)&lt;/thumbnail' \
             r'.*?marker="\+">&lt;fanart&gt;([^&]+)&lt;/fanart' \
             r'.*?marker="\+">&lt;date&gt;([^&]+)&lt;/date' \
             r'.*?marker="\+">&lt;info&gt;([^&]+)&lt;/info'

    for tit, calidades, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, patron):
        
        title = normalizar(tit)
        cals = qualities(calidades)

        itemlist.append(item.clone(
            title=title,
            tit=tit,
            type='movie',
            languages='Esp',
            lab=tit,
            qualities=cals,
            thumbnail=poster,
            fanart=fanart,
            infoLabels={'year': year, 'plot': plot},
            contentTitle=title,
            contentType='movie',
            action='findvideos'
        ))

    tmdb.set_infoLabels(itemlist)

    return itemlist'''


def movies(item):
    logger.info()
    itemlist = []

    alea = "LA" if item.title == "Selección aleatoria" else "NO"

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

    matches = re.compile(patron, re.DOTALL).findall(data)

    num_matches = len(matches)
    desde = item.page * perpage
    hasta = desde + perpage

    if alea == "LA":
        match = matches
    else:
        match = matches[desde:hasta]
    
    for tit, calidades, poster, fanart, year, plot in match:
        
        title = normalizar(tit)
        cals = qualities(calidades)

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'
        
        if 'LA CENICIENTA. TRILOGIA' in tit:
            year = 'VARIOS'

        if alea == "LA":
            item.alea = "LA"
            if 'MARVEL' in tit or 'STAR WARS' in tit:
                title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                        tit else title.split(' -')[1].strip()
            if 'DEADPOOL' in tit and ':' in tit:
                title = title.split(': ')[1].strip()
            if 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                title = title.split(': ')[1].strip()

        itemlist.append(item.clone(
            title=title,
            title2=title if not '¿' in tit else '00000000' + title,
            contentTitle=title,
            contentType='movie',
            lab=tit,
            thumbnail=poster,
            fanart=fanart,
            languages='Esp',
            infoLabels={'year': year, 'plot': plot},
            qualities=cals,
            action='findvideos'
        ))

    tmdb.set_infoLabels(itemlist)

    if num_matches > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='movies',
            text_color='coral'
        ))

    return random.sample(itemlist, k = 10) if item.alea == "LA" else sorted(itemlist, key=lambda i: i.title2) 


def qualities(calidades):

    if not '&gt;' in calidades:
        cal1 = scrapertools.find_single_match(calidades, r'hd>([^<]+)</')
        cal2 = scrapertools.find_single_match(calidades, r'<fullhd>([^<]+)</')
        cal3 = scrapertools.find_single_match(calidades, r'<tresd>([^<]+)</')
        cal4 = scrapertools.find_single_match(calidades, r'<cuatrok>([^<]+)<')
    else:
        cal1 = scrapertools.find_single_match(calidades, r'hd&gt;([^&]+)&lt;/')
        cal2 = scrapertools.find_single_match(calidades, r'&lt;fullhd&gt;([^&]+)&lt;/')
        cal3 = scrapertools.find_single_match(calidades, r'&lt;tresd&gt;([^&]+)&lt;/')
        cal4 = scrapertools.find_single_match(calidades, r'&lt;cuatrok&gt;([^&]+)&lt;')

    if cal1 != 'NA':
        cal1 = 'MicroHD'
        cals = cal1
    if cal2 != 'NA':
        cal2 = 'FullHD'
        cals = cal2
        if cal1 == 'MicroHD':
            cals = cal2 + ', ' + cal1
    if cal3 != 'NA':
        cal3 = '3D'
        cals = cal3
        if cal2 == 'FullHD':
            cals = cal3 + ', ' + cal2
        if cal1 == 'MicroHD':
            cals = cals + ', ' + cal1
    if cal4 != 'NA':
        cal4 = '4K'
        cals = cal4
        if cal3 == '3D':
            cals = cal4 + ', ' + cal3
        if cal2 == 'FullHD':
            cals = cals + ', ' + cal2
        if cal1 == 'MicroHD':
            cals = cals + ', ' + cal1

    return cals


def normalizar(t):

    t = re.sub(r"0N", "ON", t)
    t = re.sub(r" PANTER", " PANTHER", t)

    if t == 'BABY':
        t = 'BABY (DEL TEMOR AL AMOR)'
    elif t == 'DESTINO FATAL II':
        t = 'DESTINO FINAL II'
    elif t == 'DESTINO FINAL V':
        t = 'DESTINO FINAL V (5)'
    elif t == 'ERASE UNA VEZ DEADPOOL':
        t = 'ÉRASE UNA VEZ UN DEADPOOL'
    elif t == 'OLD BOY':
        t = 'OLDBOY'
    elif t == 'WONDER':
        t = 'WONDER (EXTRAORDINARIO)'
    
    if "(SD)" in t or "( sd)" in t or "( sd )" in t or "( 1994 )" in t:
        t = re.sub(r"\(SD\)|\( sd\)|\( sd \)|\( 1994 \)", "", t)

    t = t.strip()

    t = bytes.decode(t.lower())

    return ''.join((c for c in unicodedata.normalize('NFD', t.title()) if unicodedata.category(c) != 'Mn'))


def generos(item):
    logger.info()
    itemlist = []

    generos = {
        'Accion': 'Acción',
        'Infantil': 'Animación y Familiar',
        'Aventura': 'Aventura',
        'Belico': 'Bélico',
        'Ciencia Ficcion': 'Ciencia ficción',
        'Comedia': 'Comedia',
        'Drama': 'Drama',
        'Fantastico': 'Fantástico',
        'Intriga': 'Intriga',
        'Musical': 'Musical',
        'Romance': 'Romance',
        'Terror': 'Terror',
        'Thriller': 'Thriller'
        }

    for gen in sorted(generos):
        itemlist.append(item.clone( title=generos[gen], query=gen, lab='g', action='year_saga_search' ))

    return sorted(itemlist, key=lambda i: i.title)


'''def genres(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0

    for tit, calidades, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        cals = qualities(calidades)

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            year = 'VARIOS'
        elif 'LA SIRENITA ( TRILOGIA )' in tit:
            year = 'VARIOS'
        
        if 'MEN IN BLACK' in tit or 'CICLO CLINT EASTWOOD' in tit or 'CLASICOS DE DISNEY' in tit \
            or 'CHARLOT' in tit or 'DEADPOOL' in tit or 'LA CENICIENTA. TRILOGIA' in tit \
            or 'WONDER WOMAN' in tit or 'TRANSFORMERS' in tit or 'EL REY LEON' in tit \
            or 'LA SIRENITA ( TRILOGIA )' in tit or 'LA PURGA' in tit or 'HOTEL TRANSILVANIA' in tit \
            or 'RESIDENT EVIL' in tit:
            genre = genre + ' Saga'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'

        if item.query.lower() in genre.lower():
            ilist += 1
            if  desde < ilist <= hasta:
                itemlist.append(item.clone(
                    title=title,
                    type='movie',
                    contentTitle=title,
                    contentType='movie',
                    lab=tit,
                    thumbnail=poster,
                    fanart=fanart,
                    languages='Esp',
                    infoLabels={'year': year, 'plot': plot},
                    qualities=cals,
                    action='findvideos'
                ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            page=next_page,
            action='genres',
            text_color='coral'
        ))

    return itemlist'''


def alfabeto(item):
    logger.info()
    itemlist = []

    for letra in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        if letra == '#':
            let = r"{0,1,2,3,4,5,6,7,8,9}"
        else:
            let = letra

        itemlist.append(item.clone( title=letra, query=let, lab='a', action='year_saga_search' ))

    return itemlist


'''def alphabet(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0

    for tit, calidades, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        #tit2 = normalizar(tit)
        #item.query = normalizar(item.query)
        cals = qualities(calidades)

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            #tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        elif 'LA SIRENITA ( TRILOGIA )' in tit:
            #tit2 = normalizar('CLASICOS DE DISNEY LA SIRENITA ( TRILOGIA )')
            year = 'VARIOS'
        
        if 'MEN IN BLACK' in tit or 'CICLO CLINT EASTWOOD' in tit or 'CLASICOS DE DISNEY' in tit \
            or 'CHARLOT' in tit or 'DEADPOOL' in tit or 'LA CENICIENTA. TRILOGIA' in tit \
            or 'WONDER WOMAN' in tit or 'TRANSFORMERS' in tit or 'EL REY LEON' in tit \
            or 'LA SIRENITA ( TRILOGIA )' in tit or 'LA PURGA' in tit or 'HOTEL TRANSILVANIA' in tit \
            or 'RESIDENT EVIL' in tit:
            genre = genre + ' Saga'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'

        if title[0].lower() in item.query.lower():
            ilist += 1
            if  desde < ilist <= hasta:
                itemlist.append(item.clone(
                    title=title,
                    type='movie',
                    contentTitle=title,
                    contentType='movie',
                    lab=tit,
                    thumbnail=poster,
                    fanart=fanart,
                    languages='Esp',
                    infoLabels={'year': year, 'plot': plot},
                    qualities=cals,
                    action='findvideos'
                ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            page=next_page,
            action='alphabet',
            text_color='coral'
        ))

    return itemlist'''


def year_saga_search(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0

    for tit, calidades, poster, fanart, year, genre, plot in matches:

        title = normalizar(tit)
        tit2 = normalizar(tit)
        item.query = normalizar(item.query)
        cals = qualities(calidades)

        if 'MARVEL' in tit or 'STAR WARS' in tit:
            title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
        elif 'DEADPOOL' in tit and ':' in tit:
            title = title.split(': ')[1].strip()
        if 'ANIMALES FANTASTICOS' in tit and ':' in tit and item.lab == 's':
            title = title.split(': ')[1].strip()
        
        elif 'LA CENICIENTA. TRILOGIA' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA CENICIENTA. TRILOGIA')
            year = 'VARIOS'
        elif 'LA SIRENITA ( TRILOGIA )' in tit:
            tit2 = normalizar('CLASICOS DE DISNEY LA SIRENITA ( TRILOGIA )')
            year = 'VARIOS'
        
        if 'MEN IN BLACK' in tit or 'CICLO CLINT EASTWOOD' in tit or 'CLASICOS DE DISNEY' in tit \
            or 'CHARLOT' in tit or 'DEADPOOL' in tit or 'LA CENICIENTA. TRILOGIA' in tit \
            or 'WONDER WOMAN' in tit or 'TRANSFORMERS' in tit or 'EL REY LEON' in tit \
            or 'LA SIRENITA ( TRILOGIA )' in tit or 'LA PURGA' in tit or 'HOTEL TRANSILVANIA' in tit \
            or 'RESIDENT EVIL' in tit:
            genre = genre + ' Saga'
        elif 'PRIMER VENGADOR' in tit:
            year = '2011'
        elif tit == 'SEVEN':
            title = 'Seven (Se7en)'
        if year == '1019':
            year = '1917'
        elif year == '2031':
            year = '2013'

        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals = 'SD'

        if item.lab == 's':
            if 'Saga' in genre:
                item.query = re.sub(r"\s", "", item.query)
                tit2 = re.sub(r"\s", "", tit2)
                if item.query.lower() in tit2.lower():
                    ilist += 1
                    if  desde < ilist <= hasta:
                        if 'MARVEL' in tit or 'STAR WARS' in tit:
                            if item.label == 'SPIDER-MAN':
                                y = year.upper()
                            else:
                                y = None
                        elif 'CLASICOS DE DISNEY' in tit:
                            y = tit
                        else:
                            y = year.upper()

                        itemlist.append(item.clone(
                            title=title,
                            type='movie',
                            contentTitle=title,
                            contentType='movie',
                            lab=tit,
                            y=y,
                            thumbnail=poster,
                            fanart=fanart,
                            languages='Esp',
                            infoLabels={'year': year, 'plot': plot},
                            qualities=cals,
                            action='findvideos'
                        ))

        elif item.lab == 'y':
            if item.query.upper() == year.upper():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        title2=title if not '¿' in tit else '00000000' + title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

        elif item.lab == 'g':
            if item.query.lower() in genre.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

        elif item.lab == 'a':
            if title[0].lower() in item.query.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

        else:
            if item.query.lower() in title.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        contentTitle=title,
                        contentType='movie',
                        lab=tit,
                        thumbnail=poster,
                        fanart=fanart,
                        languages='Esp',
                        infoLabels={'year': year, 'plot': plot},
                        qualities=cals,
                        action='findvideos'
                    ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            y='Zzzzzzzzzzzz',
            page=next_page,
            action='year_saga_search',
            text_color='coral'
        ))

    if item.lab == 's':
        return sorted(itemlist, key=lambda i: i.y)
    elif item.lab == 'y':
        return sorted(itemlist, key=lambda i: i.title2)
    else:
        return itemlist


def search(item, query):
    logger.info()
    
    try:
        item.query = query
        return year_saga_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def selection(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    if item.title == 'Cine destacado':
        item.com = 'Estreno'
    elif item.title == 'Cine de culto':
        item.com = 'Culto'
    elif item.title == 'Últimas añadidas':
        item.com = 'last'
    
    #url = host_last if item.title == 'Últimas añadidas' or item.title2 == '0Aaaaaaaaa' else host
    #data = httptools.downloadpage(url).data

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)/cuatrok>.*?<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    matches = scrapertools.find_multiple_matches(data, patron)

    desde = item.page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, calidades, poster, fanart, year, extra, plot in matches:
        if extra == item.com or item.com == 'last':
            ilist += 1
            if  desde < ilist <= hasta:
                title = normalizar(tit)

                cals = qualities(calidades)

                if 'MARVEL' in tit or 'STAR WARS' in tit:
                    title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                    tit else title.split(' -')[1].strip()
                elif 'DEADPOOL' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()
                elif 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()

                total = scrapertools.find_single_match(calidades, r'hd>([^<]+)</')
                if total == '1' or total == '+1':
                    new = 'nueva'
                else:
                    new = 'nuevas'

                itemlist.append(item.clone(
                    title=title if tit != 'ÚLTIMAS AÑADIDAS' else '[B][COLOR yellow]•Última '\
                                        'actualización[/COLOR][/B]',
                    title2=title if tit != 'ÚLTIMAS AÑADIDAS' else '0Aaaaaaaaa',
                    type='movie',
                    contentTitle=title,
                    contentType='movie',
                    lab=tit,
                    last='last' if item.title == 'Últimas añadidas' or tit == 'ÚLTIMAS AÑADIDAS' else 'NO',
                    thumbnail=poster,
                    fanart=fanart,
                    languages='Esp' if tit != 'ÚLTIMAS AÑADIDAS' else None,
                    infoLabels={'year': year, 'plot': plot},
                    qualities=cals if tit != 'ÚLTIMAS AÑADIDAS' else '%s %s' % (total, new),
                    action='findvideos' if tit != 'ÚLTIMAS AÑADIDAS' else 'selection'
                ))

    tmdb.set_infoLabels(itemlist)

    if ilist > hasta:
        next_page = item.page + 1
        itemlist.append(item.clone(
            title='>> Página siguiente',
            title2='Zzzzzzzzzzzz',
            page=next_page,
            action='selection',
            text_color='coral'
        ))

    return sorted(itemlist, key=lambda i: i.title2)


def sagas(item):
    logger.info()
    itemlist = []

    url = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/sag'
    data = httptools.downloadpage(url).data

    for s in scrapertools.find_multiple_matches(data, r" '(.*?)',"):
        r = s
        r = re.sub(r"\.\.\.", "", r)
        if r == 'SPIDER-MAN':
            r = 'SPIDER'
        
        itemlist.append(item.clone(
            title=s,
            label=s,
            query=r,
            lab='s',
            action='year_saga_search'
        ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []
    aux = set()

    url = host
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<date>([^<]+)</'

    for year in scrapertools.find_multiple_matches(data, patron):
        year = year.upper()
        if year == '1019':
            year = '1917'
        elif year == '1950 - 2007':
            year = 'VARIOS'
        elif year == '2031':
            year = '2013'
        
        if not year in aux:
            aux.add(year)
            itemlist.append(item.clone(
                label=year,
                title=year,
                query=year,
                lab='y',
                action='year_saga_search'
            ))

    return sorted(itemlist, key=lambda i: i.label, reverse=True)


def findvideos(item):
    logger.info()
    itemlist = []

    #url = host_last if item.last == 'last' else host
    #data = httptools.downloadpage(url).data

    try:
        las0_xml = os.path.join(config.get_runtime_path(), 'las0.xml')
        data = open(las0_xml).read()
    except:
        url = host
        data = httptools.downloadpage(url).data

    data = re.sub(r"\n|\r|\t|\(|\)|\¿|\?|<b>|\s{2}|&nbsp;", "", data)
    item.lab =re.sub(r"\(|\)|\¿|\?", "", item.lab)

    patron = r'<item.*?<title>%s</.*?tle>(.*?)<thumb' % item.lab

    cal = scrapertools.find_single_match(data, patron)

    matches = re.compile(r'<([^<]+)>([^<]+)</', re.DOTALL).findall(cal)
    
    for calidad, url in matches:
        if url != 'NA':
            if calidad == 'microhd':
                calidad = 'MicroHD'
                level = 4
            elif calidad == 'fullhd':
                calidad = 'FullHD'
                level = 3
            elif calidad == 'tresd':
                calidad = '3D'
                level = 2
            elif calidad == 'cuatrok':
                calidad = '4K'
                level = 1
            
            if 'CLASICOS DE DISNEY' in item.lab or 'EL REY LEON 2' in item.lab or 'EL REY LEON 3' in item.lab:
                cal = 'SD'
                level = 5
            else:
                cal = calidad
            
            itemlist.append(item.clone(
                action="play",
                url='magnet:?xt=urn:btih:' + url,
                title='',
                level=level,
                quality=cal,
                language='Esp',
                type='server',
                server='torrent'
            ))

    return sorted(itemlist, key=lambda i: i.level)

