# -*- coding: utf-8 -*-

import os, xbmc, time, traceback, hashlib
import platform, sys
from platformcode import config, logger, platformtools
from core import httptools, jsontools, filetools, downloadtools, scrapertools


ADDON_UPDATES_MOD_JSON = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/upd/upd_mod_fix.json'
ADDON_UPDATES_MOD_ZIP  = 'https://raw.githubusercontent.com/pepemebe/mag/main/poc/upd/upd_mod_fix.zip'


addon_update_verbose = config.get_setting('addon_update_verbose', default=False)

color_alert = config.get_setting('notification_alert_color', default='red')
color_infor = config.get_setting('notification_infor_color', default='pink')
color_adver = config.get_setting('notification_adver_color', default='violet')
color_avis = config.get_setting('notification_avis_color', default='yellow')
color_exec = config.get_setting('notification_exec_color', default='cyan')


def patches(verbose=False, force=False, onlypatch=False):
    logger.info()

    if onlypatch == False:
        time.sleep(4)
        if verbose:
            info = '[B][COLOR %s]Aplicando modificaciones[/COLOR][/B]' % color_infor
            platformtools.dialog_notification(config.__addon_name + ' MOD', info)
            time.sleep(2)
    else:
        '''#logger.info('\n\n-------------------------OS.NAME---------------------------> \n%s\n' % os.name)
        #logger.info('\n\n-------------------------OS.UNAME---------------------------> \n%s\n' % os.uname)
        logger.info('\n\n-------------------------SYS.VERSION_INFO---------------------------> \n%s\n' % sys.version_info[0])
        ###logger.info('\n\n-------------------------SYS.PLATFORM---------------------------> \n%s\n' % sys.platform)
        #logger.info('\n\n-------------------------PLATFORM.PLATFORM---------------------------> \n%s\n' % platform.platform())
        logger.info('\n\n-------------------------PLATFORM.SYSTEM---------------------------> \n%s\n' % platform.system())
        logger.info('\n\n-------------------------PLATFORM.RELEASE---------------------------> \n%s\n' % platform.release())
        logger.info('\n\n-------------------------PLATFORM.VERSION---------------------------> \n%s\n' % platform.version())
        
        from modules import helper
        helper.get_plataforma('')
        '''
        kodi_ver = str(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        
        try:
            if xbmc.getCondVisibility("System.Platform.Android"): plat = 'Android'
            elif xbmc.getCondVisibility("System.Platform.Windows"): plat = 'Windows'
            elif xbmc.getCondVisibility("System.Platform.UWP"): plat = 'Windows'
            elif xbmc.getCondVisibility("System.Platform.Linux"): plat = 'Linux'
            elif xbmc.getCondVisibility("system.platform.Linux.RaspberryPi"): plat = 'Raspberry'
            elif xbmc.getCondVisibility("System.Platform.OSX"): plat = 'Osx'
            elif xbmc.getCondVisibility("System.Platform.IOS"): plat = 'Ios'
            elif xbmc.getCondVisibility("System.Platform.Darwin"): plat = 'Darwin'
            elif xbmc.getCondVisibility("System.Platform.Xbox"): plat = 'Xbox'
            elif xbmc.getCondVisibility("System.Platform.Tvos"): plat = 'Tvos'
            elif xbmc.getCondVisibility("System.Platform.Atv2"): plat = 'Atv2'
            else: plat = 'Desconocida'
        except:
            plat = '?'
        plataforma = plat

        release = str(platform.release())

        machine = str(platform.machine())

        lang = str(xbmc.getInfoLabel('System.Language'))

        system = platform.uname()
        sistema = str(system[1]) + ' - ' + str(system[3]).split(' ')[0]

        python_ver = str(sys.version_info[0])
        
        proof = str(xbmc.getInfoLabel('System.FriendlyName'))

        info = 'Kodi %s, Plataforma %s, Release %s, CPU %s, Sistema %s, Python %s, Lang %s' % (kodi_ver, plataforma, release, machine, sistema, python_ver, lang) 

        logger.info('\n\n---------------------------------------------------------------------\n\n')
        logger.info('\n%s\n%s\n%s\n%s\n%s\n%s\n%s' % (kodi_ver, plataforma, release, machine, lang, sistema, python_ver))
        logger.info('\n\n---------------------------------------------------------------------\n\n')
        logger.info('\n\n%s\n\n' % info)
        logger.info('\n\n---------------------------------------------------------------------\n\n')
        logger.info('\n\n---------------------PROOF---------------------------------> \n\n%s\n\n' % proof)
        logger.info('\n\n---------------------------------------------------------------------\n\n')
    
    path_updat = os.path.join(filetools.translatePath("special://home/addons/plugin.video.balandro/platformcode/updater.py"))
    if os.path.isfile(path_updat) == True:
        with open(path_updat, 'r') as p_updat:
            upd = p_updat.read()

            upd = upd.replace("config.__addon_name,", "config.__addon_name + ' MOD',")
            upd = upd.replace("if current_version != data['addon_version']:", "if current_version < data['addon_version']:")
            upd = upd.replace("if addon.get('version') == config.get_addon_version(False): return True", "if addon.get('version') <= config.get_addon_version(False): return True")
            
            with open(path_updat, 'w') as p_updat:
                p_updat.write(upd)

    path_menu = os.path.join(filetools.translatePath("special://home/addons/plugin.video.balandro/modules/mainmenu.py"))
    if os.path.isfile(path_menu) == True:
        with open(path_menu, 'r') as p_menu:
            mnu = p_menu.read()
            mnu = mnu.replace('from core import channeltools\n\n\n', 'from core import channeltools, jsontools, filetools\n\n\n')
            mnu = mnu.replace("else: last_ver = ''\n\n    context_ayuda = []", "else: last_ver = ''\n\n    try:\n        last_fix_mod = os.path.join(config.get_runtime_path(), 'last_fix_mod.json')\n        lastfixmod = jsontools.load(filetools.read(last_fix_mod))\n    except: lastfixmod = True\n\n    if not lastfixmod:\n        lastfixmod = 'mod desfasado'\n    else:\n        if lastfixmod['mod_version'] > 0:\n            lastfixmod = 'mod%s' % lastfixmod['mod_version']\n        else:\n            lastfixmod = 'mod'\n\n    context_ayuda = []")
            mnu = mnu.replace("title = '[B]Ayuda[/B] (%s)  %s' % (config.get_addon_version(), last_ver)", "title = '[B]Ayuda[/B] (%s %s)  %s' % (config.get_addon_version(), lastfixmod, last_ver)")
            with open(path_menu, 'w') as p_menu:
                p_menu.write(mnu)

    path_acti = os.path.join(filetools.translatePath("special://home/addons/plugin.video.balandro/modules/actions.py"))
    if os.path.isfile(path_acti) == True:
        with open(path_acti, 'r') as p_acti:
            acti = p_acti.read()
            acti = acti.replace('from platformcode import updater\n', 'from platformcode import updater, patchmod\n')
            acti = acti.replace("updater.check_addon_updates(verbose=True)\n\n", "updater.check_addon_updates(verbose=True)\n    patchmod.patches(verbose=True)\n\n")
            acti = acti.replace('updater.check_addon_updates(verbose=True, force=True)\n\n', 'updater.check_addon_updates(verbose=True, force=True)\n    patchmod.patches(verbose=True, force=True)\n\n')
            with open(path_acti, 'w') as p_acti:
                p_acti.write(acti)

    time.sleep(2)
    if onlypatch == False:
        check_addon_mod() if not force else check_addon_mod(force=True)


def check_addon_mod(verbose=False, force=False):
    logger.info()

    try:
        last_fix_mod = os.path.join(config.get_runtime_path(), 'last_fix_mod.json')
        last_fix_json = os.path.join(config.get_runtime_path(), 'last_fix.json')

        if force and os.path.exists(last_fix_mod): os.remove(last_fix_mod)

        data = httptools.downloadpage(ADDON_UPDATES_MOD_JSON, timeout=2).data
        data = jsontools.load(data)

        if os.path.exists(last_fix_mod):
            lastfix = jsontools.load(filetools.read(last_fix_mod))
            if os.path.exists(last_fix_json):
                lastfixjson = jsontools.load(filetools.read(last_fix_json))
                fixjson = lastfixjson['fix_version']
            else:
                fixjson = 0
            if fixjson == 0:
                fix = ''
            else:
                fix = 'fix%s' % fixjson
            if data['mod_version'] < 1:
                mod = ''
            else:
                mod = data['mod_version']

            if lastfix['mod_version'] == data['mod_version']:
                logger.info('Mod aplicado: %s.%s mod%s' % (data['addon_version'], fix, mod))

                #if verbose:
                time.sleep(2)
                tex = '[B][COLOR %s]Mod aplicado: %s.%s mod%s[/COLOR][/B]' % (color_adver, data['addon_version'], fix, mod)
                platformtools.dialog_notification(config.__addon_name + ' MOD', tex)
                if not force:
                    platformtools.itemlist_refresh()

                return False

        localfilename = os.path.join(config.get_data_path(), 'temp_updates.zip')

        if os.path.exists(localfilename): os.remove(localfilename)

        down_stats = downloadtools.do_download(ADDON_UPDATES_MOD_ZIP, config.get_data_path(), 'temp_updates.zip', silent=True, resume=False)

        if down_stats['downloadStatus'] != 2:
            logger.error('No se pudo descargar el mod')

            if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]No se pudo descargar el mod[/COLOR][/B]' % color_alert)
            return False

        itt = 0

        hash_localfilename = check_zip_hash(localfilename)

        while not data['hash'] == hash_localfilename:
            if itt == 0:
                if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]Acreditando mod... Espere...[/COLOR][/B]' % color_avis)

            itt += 1

            time.sleep(60)

            data = httptools.downloadpage(ADDON_UPDATES_MOD_JSON, timeout=2).data

            data = jsontools.load(data)

            localfilename = os.path.join(config.get_data_path(), 'temp_updates.zip')
            if os.path.exists(localfilename): os.remove(localfilename)

            down_stats = downloadtools.do_download(ADDON_UPDATES_MOD_ZIP, config.get_data_path(), 'temp_updates.zip', silent=True, resume=False)

            if down_stats['downloadStatus'] != 2:
                logger.info('No se pudo descargar el mod')
                if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]No se pudo descargar el mod[/COLOR][/B]' % color_alert)
                return False

            if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]Acreditando mod (itt %s)[/COLOR][/B]' % (color_avis, itt))

            hash_localfilename = check_zip_hash(localfilename)
            time.sleep(5)

            if itt == 5 and not data['hash'] == hash_localfilename: 
                logger.info('No se pudo Acreditar el mod')
                if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]No se pudo acreditar el mod[/COLOR][/B]' % color_alert)
                return False

        if data['hash'] == hash_localfilename:
            try:
                import zipfile
                dir = zipfile.ZipFile(localfilename, 'r')
                dir.extractall(config.get_runtime_path())
                dir.close()
            except:
                xbmc.executebuiltin('Extract("%s", "%s")' % (localfilename, config.get_runtime_path()))

            time.sleep(2)

            os.remove(localfilename)

            filetools.write(last_fix_mod, jsontools.dump(data))
            if os.path.exists(last_fix_json):
                lastfixjson = jsontools.load(filetools.read(last_fix_json))
                fixjson = lastfixjson['fix_version']
            else:
                fixjson = 0
            if fixjson == 0:
                fix = ''
            else:
                fix = 'fix%s' % fixjson
            if data['mod_version'] < 1:
                mod = ''
            else:
                mod = data['mod_version']

            logger.info('Mod actualizado correctamente a %s.%s mod%s' % (data['addon_version'], fix, mod))

            #if addon_update_verbose:
            show_last_fix_mod('')

            #if verbose:
            tex = '[B][COLOR %s]Actualizado %s.%s mod%s[/COLOR][/B]' % (color_avis, data['addon_version'], fix, mod)
            platformtools.dialog_notification(config.__addon_name + ' MOD', tex)

            if not force:
                platformtools.itemlist_refresh()

            return True

    except:
        logger.error('Error comprobación mod!')
        logger.error(traceback.format_exc())

        if verbose: platformtools.dialog_notification(config.__addon_name + ' MOD', '[B][COLOR %s]Error comprobación mod[/COLOR][/B]' % color_alert)
        return False


def check_zip_hash(localfilename):
    logger.info()

    with open(localfilename, 'rb') as filezip:
        md5 = hashlib.md5()

        for chunk in iter(lambda: filezip.read(4096), b""):
            md5.update(chunk)

        check_zip_hash = md5.hexdigest()

    return check_zip_hash


def show_last_fix_mod(item):
    logger.info()

    #path = os.path.join(config.get_runtime_path(), "last_fix_mod.json")
    path = os.path.join(config.get_runtime_path(), "info_mod.json")

    existe = filetools.exists(path)
    if existe == False:
        platformtools.dialog_notification(config.__addon_name + ' MOD', "[B][COLOR %s]No hay fichero Mod[/COLOR][/B]" % color_infor)
        return

    txt = ""

    try:
        with open(path, "r") as f: txt=f.read(); f.close()
    except:
        try: txt = open(path, encoding="utf8").read()
        except: pass

    if txt:
        txt = txt.replace('{', '').replace('}', '').replace('[', '').replace(']', '').replace(',', '').replace('"', '').replace("'", '').strip()

        txt = txt.replace('addon_version:', '[COLOR cyan][B]Version:[/B][/COLOR]')
        txt = txt.replace('files:', '[COLOR yellowgreen][B]Ficheros:[/B][/COLOR]')
        
        txt = txt.replace('información:', '[COLOR yellowgreen][B]Información:[/B][/COLOR]')

        txt = txt.replace('channels:', '[COLOR yellow][B]Canales:[/B][/COLOR]')
        txt = txt.replace('core:', '[COLOR yellow][B]Core:[/B][/COLOR]')
        txt = txt.replace('lib:', '[COLOR yellow][B]Lib:[/B][/COLOR]')
        txt = txt.replace('modules:', '[COLOR yellow][B]Modules:[/B][/COLOR]')
        txt = txt.replace('platformcode:', '[COLOR yellow][B]Platformcode:[/B][/COLOR]')
        txt = txt.replace('resources:', '[COLOR yellow][B]Resources:[/B][/COLOR]')
        txt = txt.replace('root dir:', '[COLOR yellow][B]Root:[/B][/COLOR]')
        txt = txt.replace('servers:', '[COLOR yellow][B]Servidores:[/B][/COLOR]')

        txt = txt.replace('fix_version:', '[COLOR cyan][B]Numero de Fix:[/B][/COLOR]')
        txt = txt.replace('hash:', '[COLOR slateblue][B]Control Hash:[/B][/COLOR]')
        txt = txt.replace('mod_version:', '[COLOR cyan][B]Numero de Mod:[/B][/COLOR]')

        platformtools.dialog_textviewer('Información del último Mod instalado', txt)

